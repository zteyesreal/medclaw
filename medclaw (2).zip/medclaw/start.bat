﻿@echo off
chcp 65001 >nul
echo ================================================
echo MedClaw Medical Assistant - Auto Start
echo ================================================
echo.

echo [1/5] Installing dependencies...
pip install -r requirements.txt
echo.
echo [2/5] Initializing database...
python scripts/init_db.py
echo.
echo [3/5] Testing MCP connection...
python scripts/test_mcp.py
echo.
echo [4/5] Running module tests...
python tests/test_modules.py
echo.
echo [5/5] Starting MedClaw Web UI...
start "MedClaw WebUI" cmd /k "python start_webui.py"
echo.
echo ================================================
echo MedClaw is running!
echo.
echo WebUI:        http://localhost:8003
echo Swagger Docs: http://localhost:8003/docs
echo ================================================
echo.
pause
