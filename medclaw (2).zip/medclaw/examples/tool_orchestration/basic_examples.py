"""
MedClaw 工具编排示例
展示如何使用 ToolOrchestrator 实现复杂工具调用场景
"""

import asyncio
import json
import os
from datetime import datetime


async def mock_file_read(file_path: str) -> dict:
    """模拟文件读取工具"""
    await asyncio.sleep(0.1)
    return {
        "success": True,
        "content": f"这是文件 {file_path} 的内容",
        "lines": 10,
        "size": 1024
    }


async def mock_parse_content(content: str) -> dict:
    """模拟内容解析工具"""
    await asyncio.sleep(0.1)
    return {
        "success": True,
        "parsed_data": {"items": ["item1", "item2", "item3"]},
        "format": "json"
    }


async def mock_store_data(data: dict) -> dict:
    """模拟数据存储工具"""
    await asyncio.sleep(0.1)
    return {
        "success": True,
        "stored_id": "data_123",
        "timestamp": datetime.now().isoformat()
    }


async def example_file_processing_chain():
    """示例1：文件处理链（读取 → 解析 → 存储）"""
    print("\n" + "="*60)
    print("示例1：文件处理链")
    print("="*60)
    
    from medclaw.core.mcp_client import MCPClient
    from medclaw.core.tool_orchestrator import ToolOrchestrator, ToolChain
    
    mcp_client = MCPClient()
    
    mcp_client.register_tool(
        name="read_file",
        description="读取文件内容",
        input_schema={"type": "object", "properties": {"file_path": {"type": "string"}}},
        handler=mock_file_read
    )
    
    mcp_client.register_tool(
        name="parse_content",
        description="解析内容为结构化数据",
        input_schema={"type": "object", "properties": {"content": {"type": "string"}}},
        handler=mock_parse_content
    )
    
    mcp_client.register_tool(
        name="store_data",
        description="存储数据到数据库",
        input_schema={"type": "object", "properties": {"data": {"type": "object"}}},
        handler=mock_store_data
    )
    
    orchestrator = ToolOrchestrator(mcp_client)
    await orchestrator.initialize()
    
    chain = ToolChain()
    chain.add_step(
        tool_name="read_file",
        params={"file_path": "/data/input.txt"}
    )
    chain.add_step(
        tool_name="parse_content",
        output_mapping="content"
    )
    chain.add_step(
        tool_name="store_data",
        output_mapping="data"
    )
    
    results = await orchestrator.execute_chain(chain)
    
    print(f"\n执行结果：")
    for i, result in enumerate(results):
        print(f"  步骤 {i+1}: {result}")
    
    stats = orchestrator.get_stats()
    print(f"\n编排器统计：{json.dumps(stats, indent=2, ensure_ascii=False)}")
    
    await orchestrator.cleanup()
    
    print("\n✓ 文件处理链示例完成")


async def example_parallel_data_collection():
    """示例2：并行数据收集（多个 API → 合并结果）"""
    print("\n" + "="*60)
    print("示例2：并行数据收集")
    print("="*60)
    
    from medclaw.core.mcp_client import MCPClient
    from medclaw.core.tool_orchestrator import ToolOrchestrator
    
    mcp_client = MCPClient()
    
    async def mock_api_call(api_name: str, endpoint: str) -> dict:
        await asyncio.sleep(0.2)
        return {
            "success": True,
            "api": api_name,
            "endpoint": endpoint,
            "data": [f"item_{api_name}_{i}" for i in range(3)]
        }
    
    mcp_client.register_tool(
        name="call_user_api",
        description="调用用户 API",
        input_schema={"type": "object", "properties": {"endpoint": {"type": "string"}}},
        handler=lambda **kwargs: mock_api_call("user", kwargs.get("endpoint", "/users"))
    )
    
    mcp_client.register_tool(
        name="call_order_api",
        description="调用订单 API",
        input_schema={"type": "object", "properties": {"endpoint": {"type": "string"}}},
        handler=lambda **kwargs: mock_api_call("order", kwargs.get("endpoint", "/orders"))
    )
    
    mcp_client.register_tool(
        name="call_product_api",
        description="调用产品 API",
        input_schema={"type": "object", "properties": {"endpoint": {"type": "string"}}},
        handler=lambda **kwargs: mock_api_call("product", kwargs.get("endpoint", "/products"))
    )
    
    orchestrator = ToolOrchestrator(mcp_client)
    await orchestrator.initialize()
    
    import time
    start_time = time.time()
    
    tool_calls = [
        ("call_user_api", {"endpoint": "/users"}),
        ("call_order_api", {"endpoint": "/orders"}),
        ("call_product_api", {"endpoint": "/products"}),
    ]
    
    results = await orchestrator.execute_parallel(tool_calls)
    
    elapsed = time.time() - start_time
    
    print(f"\n并行执行 {len(results)} 个 API 调用")
    print(f"总耗时：{elapsed:.3f} 秒")
    print(f"\n收集的数据：")
    for i, result in enumerate(results):
        print(f"  API {i+1}: {result.get('api')}")
    
    merged_data = []
    for result in results:
        merged_data.extend(result.get("data", []))
    print(f"\n合并结果：{len(merged_data)} 条数据")
    
    await orchestrator.cleanup()
    
    print("\n✓ 并行数据收集示例完成")


async def example_cached_queries():
    """示例3：带缓存的重复查询"""
    print("\n" + "="*60)
    print("示例3：带缓存的重复查询")
    print("="*60)
    
    from medclaw.core.mcp_client import MCPClient
    from medclaw.core.tool_orchestrator import ToolOrchestrator
    
    mcp_client = MCPClient()
    
    call_count = {"count": 0}
    
    async def mock_db_query(query: str) -> dict:
        call_count["count"] += 1
        await asyncio.sleep(0.2)
        return {
            "success": True,
            "query": query,
            "result": [{"id": 1, "name": "Test"}],
            "rows": 1
        }
    
    mcp_client.register_tool(
        name="db_query",
        description="执行数据库查询",
        input_schema={"type": "object", "properties": {"query": {"type": "string"}}},
        handler=lambda **kwargs: mock_db_query(kwargs.get("query", ""))
    )
    
    orchestrator = ToolOrchestrator(
        mcp_client,
        cache_enabled=True,
        cache_config={"type": "memory", "default_ttl": 60}
    )
    await orchestrator.initialize()
    
    query = "SELECT * FROM users WHERE id = 1"
    
    print(f"\n第一次查询（无缓存）：")
    result1 = await orchestrator.execute("db_query", {"query": query})
    print(f"  结果：{result1.get('rows')} 行")
    print(f"  工具实际调用次数：{call_count['count']}")
    
    print(f"\n第二次查询（应命中缓存）：")
    result2 = await orchestrator.execute("db_query", {"query": query})
    print(f"  结果：{result2.get('rows')} 行")
    print(f"  工具实际调用次数：{call_count['count']}")
    
    print(f"\n第三次查询（绕过缓存）：")
    result3 = await orchestrator.execute("db_query", {"query": query}, bypass_cache=True)
    print(f"  结果：{result3.get('rows')} 行")
    print(f"  工具实际调用次数：{call_count['count']}")
    
    stats = orchestrator.get_stats()
    print(f"\n缓存统计：")
    print(f"  总调用次数：{stats.get('total_calls')}")
    print(f"  缓存命中次数：{stats.get('cache_hits')}")
    cache_stats = stats.get("cache", {})
    print(f"  缓存命中率：{cache_stats.get('hit_rate', 'N/A')}")
    
    await orchestrator.cleanup()
    
    print("\n✓ 带缓存的重复查询示例完成")


async def main():
    """运行所有示例"""
    print("\n" + "="*60)
    print("MedClaw 工具编排示例")
    print("="*60)
    
    try:
        await example_file_processing_chain()
        await example_parallel_data_collection()
        await example_cached_queries()
        
        print("\n" + "="*60)
        print("所有示例执行完成！")
        print("="*60)
        
    except Exception as e:
        print(f"\n执行出错：{e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    asyncio.run(main())
