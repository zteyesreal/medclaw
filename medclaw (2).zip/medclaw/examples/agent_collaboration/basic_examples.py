"""
MedClaw Agent 协作示例
展示多 Agent 协同完成复杂任务
"""

import asyncio
import sys
from pathlib import Path
from datetime import datetime
import logging

# 添加路径
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from medclaw.core.agents import (
    AgentCoordinator,
    ComputerUseAgent,
    OfficeAutomationAgent,
    TaskPlannerAgent,
    AgentStatus,
)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# ========== 示例 1: Computer-Use + Office Automation 协作 ==========
async def example1_browser_and_download():
    """
    示例 1: Computer-Use 打开 Chrome + Office 下载文件
    
    场景：打开浏览器，搜索文件，然后整理下载的文件
    """
    print("\n" + "="*70)
    print("示例 1: Computer-Use + Office Automation 协作")
    print("="*70)
    
    coordinator = AgentCoordinator()
    
    # 创建并注册 Agent
    computer_agent = ComputerUseAgent()
    office_agent = OfficeAutomationAgent()
    
    coordinator.register_agent(computer_agent)
    coordinator.register_agent(office_agent)
    
    await computer_agent.initialize()
    await office_agent.initialize()
    
    try:
        # 步骤 1: 获取当前鼠标位置
        print("\n【步骤 1】获取鼠标位置")
        mouse_result = await coordinator.execute_task(
            {"action": "get_mouse_position", "params": {}},
            "mouse_control"
        )
        print(f"鼠标位置：({mouse_result.get('x', 'N/A')}, {mouse_result.get('y', 'N/A')})")
        
        # 步骤 2: 获取活动窗口信息
        print("\n【步骤 2】获取活动窗口")
        window_result = await coordinator.execute_task(
            {"action": "get_active_window", "params": {}},
            "window_management"
        )
        if window_result.get('success'):
            print(f"活动窗口：{window_result.get('title', 'N/A')}")
        
        # 步骤 3: 搜索 Python 文件
        print("\n【步骤 3】搜索项目中的 Python 文件")
        search_result = await coordinator.execute_task(
            {
                "action": "search_files",
                "params": {
                    "pattern": "*.py",
                    "search_dir": str(Path(__file__).parent.parent.parent / "medclaw"),
                    "recursive": False
                }
            },
            "file_search"
        )
        print(f"找到 {search_result.get('count', 0)} 个 Python 文件")
        if search_result.get('count', 0) > 0:
            print(f"第一个文件：{search_result['files'][0]['name']}")
        
        # 步骤 4: 获取文件信息
        print("\n【步骤 4】获取 README.md 文件信息")
        readme_path = str(Path(__file__).parent.parent.parent / "README.md")
        file_info = await coordinator.execute_task(
            {"action": "get_file_info", "params": {"file_path": readme_path}},
            "file_organization"
        )
        if file_info.get('success'):
            print(f"文件名：{file_info['name']}")
            print(f"大小：{file_info['size_kb']} KB")
        
        print("\n✅ 示例 1 完成")
        
    except Exception as e:
        print(f"❌ 示例 1 执行失败：{e}")
        import traceback
        traceback.print_exc()
    
    finally:
        await coordinator.stop()


# ========== 示例 2: Task Planner 拆解复杂目标 ==========
async def example2_task_planning():
    """
    示例 2: Task Planner 拆解"晨间例行" + 多 Agent 执行
    
    场景：规划一个晨间例行任务，包括打开应用、查看文件等
    """
    print("\n" + "="*70)
    print("示例 2: Task Planner 拆解复杂目标")
    print("="*70)
    
    coordinator = AgentCoordinator()
    
    # 创建并注册 Agent
    planner_agent = TaskPlannerAgent()
    computer_agent = ComputerUseAgent()
    office_agent = OfficeAutomationAgent()
    
    coordinator.register_agent(planner_agent)
    coordinator.register_agent(computer_agent)
    coordinator.register_agent(office_agent)
    
    await planner_agent.initialize()
    await computer_agent.initialize()
    await office_agent.initialize()
    
    try:
        # 步骤 1: 拆解目标
        print("\n【步骤 1】拆解目标：打开浏览器并搜索文档")
        goal = "打开 Chrome 浏览器，搜索 Python 文档，然后截图保存"
        
        plan = await planner_agent.decompose_goal(
            goal=goal,
            context={"user": "developer", "time": "morning"}
        )
        
        print(f"\n计划 ID: {plan.plan_id}")
        print(f"目标：{plan.goal}")
        print(f"子任务数量：{len(plan.subtasks)}")
        
        for i, subtask in enumerate(plan.subtasks, 1):
            print(f"\n  子任务 {i}:")
            print(f"    ID: {subtask.task_id}")
            print(f"    描述：{subtask.description}")
            print(f"    所需能力：{subtask.required_capability}")
            print(f"    优先级：{subtask.priority}")
            print(f"    依赖：{subtask.dependencies}")
        
        # 步骤 2: 获取执行顺序
        print("\n【步骤 2】获取执行顺序")
        execution_order = plan.get_execution_order()
        for i, task in enumerate(execution_order, 1):
            print(f"  {i}. {task.description}")
        
        # 步骤 3: 模拟执行子任务
        print("\n【步骤 3】模拟执行子任务")
        for subtask in execution_order:
            print(f"\n  执行：{subtask.description}")
            
            # 更新任务状态
            await planner_agent.update_subtask(
                plan_id=plan.plan_id,
                task_id=subtask.task_id,
                status="running"
            )
            
            # 根据能力执行（这里简化处理，不实际执行）
            try:
                if subtask.required_capability == "screen_capture":
                    # 实际截图
                    result = await computer_agent.screenshot(
                        filename=str(Path(__file__).parent / f"screenshot_{subtask.task_id}.png")
                    )
                    await planner_agent.update_subtask(
                        plan_id=plan.plan_id,
                        task_id=subtask.task_id,
                        status="completed",
                        result=result
                    )
                    print(f"    ✅ 完成")
                else:
                    # 其他任务模拟完成
                    await asyncio.sleep(0.1)
                    await planner_agent.update_subtask(
                        plan_id=plan.plan_id,
                        task_id=subtask.task_id,
                        status="completed",
                        result={"simulated": True}
                    )
                    print(f"    ✅ 完成（模拟）")
                    
            except Exception as e:
                await planner_agent.update_subtask(
                    plan_id=plan.plan_id,
                    task_id=subtask.task_id,
                    status="failed",
                    error=str(e)
                )
                print(f"    ❌ 失败：{e}")
        
        # 步骤 4: 查看计划状态
        print("\n【步骤 4】查看计划状态")
        plan_status = await planner_agent.get_plan_status(plan.plan_id)
        print(f"计划状态：{plan_status['status']}")
        print(f"子任务总数：{len(plan_status['subtasks'])}")
        
        completed = sum(1 for t in plan_status['subtasks'] if t['status'] == 'completed')
        failed = sum(1 for t in plan_status['subtasks'] if t['status'] == 'failed')
        print(f"已完成：{completed}, 失败：{failed}")
        
        print("\n✅ 示例 2 完成")
        
    except Exception as e:
        print(f"❌ 示例 2 执行失败：{e}")
        import traceback
        traceback.print_exc()
    
    finally:
        await coordinator.stop()


# ========== 示例 3: 文件处理工作流 ==========
async def example3_file_processing_workflow():
    """
    示例 3: 完整的文件处理工作流
    
    场景：搜索特定类型的文件，读取内容，整理归档
    """
    print("\n" + "="*70)
    print("示例 3: 文件处理工作流")
    print("="*70)
    
    coordinator = AgentCoordinator()
    office_agent = OfficeAutomationAgent()
    
    coordinator.register_agent(office_agent)
    await office_agent.initialize()
    
    try:
        # 步骤 1: 搜索所有 Markdown 文件
        print("\n【步骤 1】搜索 Markdown 文件")
        search_dir = str(Path(__file__).parent.parent.parent)
        md_files = await office_agent.search_files(
            pattern="*.md",
            search_dir=search_dir,
            recursive=False
        )
        print(f"找到 {md_files.get('count', 0)} 个 Markdown 文件")
        
        # 步骤 2: 读取第一个 Markdown 文件
        if md_files.get('count', 0) > 0:
            print("\n【步骤 2】读取 README.md 内容")
            first_file = md_files['files'][0]['path']
            content = await office_agent.read_txt(
                file_path=first_file,
                encoding='utf-8'
            )
            if content.get('success'):
                print(f"文件：{content['file']}")
                print(f"行数：{content['line_count']}")
                print(f"内容预览：{content['content'][:200]}...")
        
        # 步骤 3: 获取文件详细信息
        print("\n【步骤 3】获取文件统计信息")
        if md_files.get('count', 0) > 0:
            total_size = sum(f['size'] for f in md_files['files'])
            print(f"文件总数：{md_files['count']}")
            print(f"总大小：{total_size / 1024:.2f} KB")
        
        print("\n✅ 示例 3 完成")
        
    except Exception as e:
        print(f"❌ 示例 3 执行失败：{e}")
        import traceback
        traceback.print_exc()
    
    finally:
        await coordinator.stop()


# ========== 示例 4: 屏幕操作自动化 ==========
async def example4_screen_automation():
    """
    示例 4: 屏幕操作自动化
    
    场景：模拟简单的屏幕操作流程
    """
    print("\n" + "="*70)
    print("示例 4: 屏幕操作自动化")
    print("="*70)
    
    coordinator = AgentCoordinator()
    computer_agent = ComputerUseAgent()
    
    coordinator.register_agent(computer_agent)
    await computer_agent.initialize()
    
    try:
        # 步骤 1: 获取屏幕信息
        print("\n【步骤 1】获取屏幕信息")
        print(f"屏幕尺寸：{computer_agent.screen_width}x{computer_agent.screen_height}")
        
        # 步骤 2: 获取鼠标位置
        print("\n【步骤 2】获取鼠标位置")
        mouse_pos = await computer_agent.get_mouse_position()
        print(f"当前鼠标位置：({mouse_pos['x']}, {mouse_pos['y']})")
        
        # 步骤 3: 截图
        print("\n【步骤 3】屏幕截图")
        screenshot_path = str(Path(__file__).parent / "example4_screenshot.png")
        screenshot = await computer_agent.screenshot(filename=screenshot_path)
        if screenshot.get('success'):
            print(f"截图已保存：{screenshot_path}")
            print(f"截图尺寸：{screenshot['size']}")
        
        # 步骤 4: 获取活动窗口
        print("\n【步骤 4】获取活动窗口")
        active_window = await computer_agent.get_active_window()
        if active_window.get('success'):
            print(f"活动窗口：{active_window.get('title', 'N/A')}")
            print(f"窗口位置：({active_window.get('left', 0)}, {active_window.get('top', 0)})")
            print(f"窗口大小：{active_window.get('width', 0)}x{active_window.get('height', 0)}")
        
        print("\n✅ 示例 4 完成")
        
    except Exception as e:
        print(f"❌ 示例 4 执行失败：{e}")
        import traceback
        traceback.print_exc()
    
    finally:
        await coordinator.stop()


# ========== 主函数 ==========
async def main():
    """运行所有示例"""
    print("\n" + "="*70)
    print("MedClaw Agent 协作示例")
    print("="*70)
    
    # 运行示例
    await example1_browser_and_download()
    await example2_task_planning()
    await example3_file_processing_workflow()
    await example4_screen_automation()
    
    print("\n" + "="*70)
    print("所有示例运行完成！")
    print("="*70)
    print("""
已展示的 Agent 协作能力:
  ✅ Computer-Use Agent: 屏幕截图、鼠标控制、窗口管理
  ✅ Office Automation Agent: 文件搜索、读取、整理
  ✅ Task Planner Agent: 目标拆解、任务规划、执行跟踪
  ✅ Agent Coordinator: 多 Agent 协调、任务分配

实际应用场景:
  1. 自动化办公流程
  2. 智能文件管理
  3. 屏幕操作自动化
  4. 复杂任务规划与执行
""")
    print("="*70)


if __name__ == "__main__":
    asyncio.run(main())
