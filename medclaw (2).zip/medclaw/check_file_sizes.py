#!/usr/bin/env python3
"""Check all Python files for line count compliance (max 600 lines)"""

import os
from pathlib import Path

def count_lines(file_path):
    """Count non-empty lines in a file"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
            non_empty = len([l for l in lines if l.strip()])
            return len(lines), non_empty
    except Exception as e:
        return 0, 0

def main():
    root = Path(r'c:\Users\zt_ey\Downloads\medclaw')
    py_files = list(root.rglob('*.py'))
    
    print(f"{'File':<80} {'Total':>8} {'Non-empty':>12} {'Status':>10}")
    print('=' * 115)
    
    over_limit = []
    
    for file_path in sorted(py_files):
        rel_path = file_path.relative_to(root)
        total, non_empty = count_lines(file_path)
        status = '✓' if total <= 600 else '✗ OVER'
        
        if total > 600:
            over_limit.append((str(rel_path), total, non_empty))
        
        print(f"{str(rel_path):<80} {total:>8} {non_empty:>12} {status:>10}")
    
    print('=' * 115)
    print(f"Total files: {len(py_files)}")
    print(f"Files over 600 lines: {len(over_limit)}")
    
    if over_limit:
        print("\n⚠️  Files exceeding 600 lines:")
        for path, total, non_empty in over_limit:
            print(f"  - {path} ({total} lines)")
    else:
        print("\n✓ All files comply with 600 line limit!")

if __name__ == '__main__':
    main()
