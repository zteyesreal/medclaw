"""
测试 MCP 连接脚本
"""

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from medclaw.core import MCPClient


async def test_mcp():
    """测试 MCP 连接"""
    print("正在测试 MCP 连接...")
    
    client = MCPClient(
        server_url="http://localhost:8001",
        api_key="your-mcp-api-key",
        timeout=30
    )
    
    try:
        connected = await client.connect()
        
        if connected:
            print("\n✅ MCP 连接成功!")
            
            health = await client.health_check()
            print(f"健康检查：{'通过' if health else '失败'}")
            
            response = await client.query("你好，请简单介绍一下你自己。")
            if response:
                print(f"\n测试查询响应:\n{response[:200]}...")
            
            await client.disconnect()
            print("\n连接已关闭。")
        else:
            print("\n❌ MCP 连接失败!")
            print("请检查:")
            print("  1. MCP 服务端是否运行在 http://localhost:8001")
            print("  2. 配置文件 config.yaml 中的 mcp.server_url 是否正确")
            print("  3. 防火墙设置是否允许连接")
            
    except Exception as e:
        print(f"\n❌ 测试失败：{e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    asyncio.run(test_mcp())
