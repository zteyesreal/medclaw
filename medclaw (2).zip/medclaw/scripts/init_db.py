"""
数据库初始化脚本
创建必要的数据库表结构
"""

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from sqlalchemy import create_engine, Column, Integer, String, DateTime, Text, Float, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime

Base = declarative_base()


class TaskRecord(Base):
    """任务记录表"""
    __tablename__ = 'task_records'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    task_id = Column(String(100), unique=True, nullable=False)
    module_name = Column(String(50), nullable=False)
    status = Column(String(20), default='pending')
    input_data = Column(JSON)
    result = Column(JSON)
    error_message = Column(Text)
    created_at = Column(DateTime, default=datetime.now)
    started_at = Column(DateTime)
    completed_at = Column(DateTime)


class MedicalRecord(Base):
    """病历记录表"""
    __tablename__ = 'medical_records'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    record_id = Column(String(100), unique=True, nullable=False)
    patient_name = Column(String(100))
    patient_gender = Column(String(10))
    patient_age = Column(Integer)
    chief_complaint = Column(Text)
    present_illness = Column(Text)
    diagnosis = Column(Text)
    quality_score = Column(Float)
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)


class InsuranceAnalysis(Base):
    """医保分析记录表"""
    __tablename__ = 'insurance_analyses'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    record_id = Column(String(100), nullable=False)
    drg_code = Column(String(20))
    drg_name = Column(String(200))
    estimated_cost = Column(Float)
    actual_cost = Column(Float)
    violations = Column(JSON)
    risk_level = Column(String(20))
    analyzed_at = Column(DateTime, default=datetime.now)


class PredictionResult(Base):
    """预测结果表"""
    __tablename__ = 'prediction_results'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    patient_id = Column(String(100))
    model_name = Column(String(50), nullable=False)
    risk_score = Column(Float)
    risk_level = Column(String(20))
    feature_data = Column(JSON)
    prediction_at = Column(DateTime, default=datetime.now)


def init_database(database_url: str = "sqlite:///./medclaw.db"):
    """初始化数据库"""
    print(f"正在初始化数据库：{database_url}")
    
    engine = create_engine(database_url, echo=False)
    
    Base.metadata.create_all(engine)
    
    print("✅ 数据库表创建成功!")
    print("\n创建的表:")
    for table in Base.metadata.sorted_tables:
        print(f"  - {table.name}")
    
    print("\n数据库初始化完成。")


if __name__ == "__main__":
    import yaml
    from pathlib import Path
    
    config_path = Path(__file__).parent.parent / "config.yaml"
    
    if config_path.exists():
        with open(config_path, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)
            database_url = config.get('database', {}).get('url', "sqlite:///./medclaw.db")
    else:
        database_url = "sqlite:///./medclaw.db"
    
    init_database(database_url)
