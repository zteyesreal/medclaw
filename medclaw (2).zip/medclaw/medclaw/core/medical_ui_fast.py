"""
MedClaw Web UI - 优化版
精简代码，提升加载速度
"""

from fastapi import FastAPI, WebSocket
from fastapi.responses import HTMLResponse
from .config_api import router as config_router

app = FastAPI()
app.include_router(config_router)

class ConnectionManager:
    def __init__(self):
        self.connections = []
    async def connect(self, ws):
        await ws.accept()
        self.connections.append(ws)
    def disconnect(self, ws):
        self.connections.remove(ws)

manager = ConnectionManager()

@app.get("/", response_class=HTMLResponse)
async def index():
    return get_html()

@app.websocket("/ws")
async def ws_endpoint(ws):
    await manager.connect(ws)
    try:
        while True:
            await ws.receive_json()
    except:
        manager.disconnect(ws)

def get_html():
    return '''<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MedClaw 医疗专用界面</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .gradient-bg{background:linear-gradient(135deg,#667eea 0%,#764ba2 100%)}
        .step-active{border-color:#10B981;background:#D1FAE5}
        .step-done{border-color:#3B82F6;background:#DBEAFE}
        .step-wait{border-color:#E5E7EB}
        .card:hover{transform:translateY(-3px);box-shadow:0 10px 20px rgba(0,0,0,0.1)}
    </style>
</head>
<body class="bg-gray-50">
    <div id="app" class="min-h-screen">
        <!-- 顶部导航 -->
        <header class="gradient-bg text-white shadow-lg py-6">
            <div class="container mx-auto px-4 flex justify-between items-center">
                <div>
                    <h1 class="text-3xl font-bold">🏥 MedClaw</h1>
                    <p class="text-blue-100 mt-1">医疗专业版 AI 助手</p>
                </div>
                <button @click="page='home'" class="px-5 py-2 rounded-lg font-semibold bg-white text-purple-600">
                    <i class="fas fa-home mr-2"></i>首页
                </button>
            </div>
        </header>

        <!-- 主内容 -->
        <main class="container mx-auto px-4 py-8">
            <!-- 模块选择 -->
            <div v-if="page==='home' && !module">
                <h2 class="text-2xl font-bold text-gray-800 mb-6">📋 选择模块</h2>
                <div class="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    <div v-for="m in modules" :key="m.id" @click="select(m)"
                         class="bg-white rounded-xl shadow-md p-6 cursor-pointer card transition-all"
                         :style="{borderTop:'4px solid '+m.color}">
                        <div class="text-5xl mb-3">{{m.icon}}</div>
                        <h3 class="text-xl font-bold text-gray-800 mb-2">{{m.name}}</h3>
                        <p class="text-gray-600 text-sm">{{m.desc}}</p>
                    </div>
                </div>
            </div>

            <!-- 任务界面 -->
            <div v-if="module">
                <button @click="module=null;step=0;form={}" class="mb-6 text-blue-600 hover:text-blue-800 font-semibold">
                    <i class="fas fa-arrow-left mr-2"></i>返回
                </button>
                
                <!-- 标题和进度 -->
                <div class="bg-white rounded-xl shadow-lg p-8 mb-6">
                    <div class="flex items-center gap-4 mb-6">
                        <span class="text-5xl">{{module.icon}}</span>
                        <div>
                            <h2 class="text-3xl font-bold text-gray-800">{{module.name}}</h2>
                            <p class="text-gray-600">{{module.desc}}</p>
                        </div>
                    </div>
                    <div class="flex gap-2 overflow-x-auto">
                        <div v-for="(s,i) in module.steps" :key="i"
                             :class="['flex items-center px-4 py-3 rounded-lg border-2 whitespace-nowrap',
                                      i===step?'step-active':i<step?'step-done':'step-wait']">
                            <div :class="['w-8 h-8 rounded-full flex items-center justify-center mr-2 font-bold text-sm',
                                          i===step?'bg-green-500 text-white':i<step?'bg-blue-500 text-white':'bg-gray-300']">
                                <i v-if="i<step" class="fas fa-check text-xs"></i>
                                <span v-else>{{i+1}}</span>
                            </div>
                            <span class="font-semibold">{{s}}</span>
                        </div>
                    </div>
                </div>

                <!-- 动态表单 -->
                <div class="bg-white rounded-xl shadow-lg p-8">
                    <!-- 病历书写 -->
                    <div v-if="module.id==='medical_record'">
                        <div v-if="step===0">
                            <h3 class="text-2xl font-bold text-gray-800 mb-6"><i class="fas fa-user-injured mr-2 text-green-500"></i>患者信息</h3>
                            <div class="grid md:grid-cols-2 gap-6">
                                <div><label class="block text-sm font-semibold text-gray-700 mb-2">姓名 *</label><input v-model="form.name" class="w-full border-2 border-gray-300 rounded-lg px-4 py-3 focus:border-green-500"></div>
                                <div><label class="block text-sm font-semibold text-gray-700 mb-2">性别 *</label><select v-model="form.gender" class="w-full border-2 border-gray-300 rounded-lg px-4 py-3"><option value="">请选择</option><option value="男">男</option><option value="女">女</option></select></div>
                                <div><label class="block text-sm font-semibold text-gray-700 mb-2">年龄 *</label><input v-model.number="form.age" type="number" class="w-full border-2 border-gray-300 rounded-lg px-4 py-3"></div>
                                <div><label class="block text-sm font-semibold text-gray-700 mb-2">职业</label><input v-model="form.occupation" class="w-full border-2 border-gray-300 rounded-lg px-4 py-3"></div>
                            </div>
                        </div>
                        <div v-if="step===1">
                            <h3 class="text-2xl font-bold text-gray-800 mb-6"><i class="fas fa-file-medical mr-2 text-blue-500"></i>主诉</h3>
                            <div><label class="block text-sm font-semibold text-gray-700 mb-2">主诉 *</label><input v-model="form.complaint" placeholder="例：头痛三天，加重伴恶心一天" class="w-full border-2 border-gray-300 rounded-lg px-4 py-3 text-lg"></div>
                        </div>
                        <div v-if="step===2">
                            <h3 class="text-2xl font-bold text-gray-800 mb-6"><i class="fas fa-notes-medical mr-2 text-purple-500"></i>现病史</h3>
                            <div><label class="block text-sm font-semibold text-gray-700 mb-2">详细描述 *</label><textarea v-model="form.illness" rows="6" class="w-full border-2 border-gray-300 rounded-lg px-4 py-3"></textarea></div>
                        </div>
                        <div v-if="step===3">
                            <h3 class="text-2xl font-bold text-gray-800 mb-6"><i class="fas fa-history mr-2 text-orange-500"></i>既往史</h3>
                            <div class="space-y-4">
                                <div><label class="block text-sm font-semibold text-gray-700 mb-2">既往疾病</label><textarea v-model="form.past" rows="2" class="w-full border-2 border-gray-300 rounded-lg px-4 py-3"></textarea></div>
                                <div><label class="block text-sm font-semibold text-gray-700 mb-2">过敏史 *</label><input v-model="form.allergy" class="w-full border-2 border-gray-300 rounded-lg px-4 py-3"></div>
                            </div>
                        </div>
                        <div v-if="step===4">
                            <h3 class="text-2xl font-bold text-gray-800 mb-6"><i class="fas fa-stethoscope mr-2 text-red-500"></i>体格检查</h3>
                            <div class="grid md:grid-cols-4 gap-4 mb-4">
                                <div><label class="block text-sm font-semibold text-gray-700 mb-2">体温</label><input v-model.number="form.temp" type="number" step="0.1" class="w-full border-2 border-gray-300 rounded-lg px-4 py-3"></div>
                                <div><label class="block text-sm font-semibold text-gray-700 mb-2">脉搏</label><input v-model.number="form.pulse" type="number" class="w-full border-2 border-gray-300 rounded-lg px-4 py-3"></div>
                                <div><label class="block text-sm font-semibold text-gray-700 mb-2">呼吸</label><input v-model.number="form.resp" type="number" class="w-full border-2 border-gray-300 rounded-lg px-4 py-3"></div>
                                <div><label class="block text-sm font-semibold text-gray-700 mb-2">血压</label><input v-model="form.bp" class="w-full border-2 border-gray-300 rounded-lg px-4 py-3"></div>
                            </div>
                        </div>
                        <div v-if="step===5">
                            <h3 class="text-2xl font-bold text-gray-800 mb-6"><i class="fas fa-user-md mr-2 text-green-500"></i>诊断治疗</h3>
                            <div class="space-y-4">
                                <div><label class="block text-sm font-semibold text-gray-700 mb-2">诊断 *</label><input v-model="form.diagnosis" class="w-full border-2 border-gray-300 rounded-lg px-4 py-3 text-lg"></div>
                                <div><label class="block text-sm font-semibold text-gray-700 mb-2">治疗方案 *</label><textarea v-model="form.treatment" rows="4" class="w-full border-2 border-gray-300 rounded-lg px-4 py-3"></textarea></div>
                            </div>
                        </div>
                    </div>

                    <!-- 病历质控 -->
                    <div v-if="module.id==='medical_quality'">
                        <div v-if="step===0"><h3 class="text-2xl font-bold mb-6"><i class="fas fa-folder-open mr-2 text-blue-500"></i>选择病历</h3><input v-model="form.recordId" placeholder="病历 ID 或患者姓名" class="w-full border-2 border-gray-300 rounded-lg px-4 py-3"></div>
                        <div v-if="step===1"><h3 class="text-2xl font-bold mb-6"><i class="fas fa-clipboard-check mr-2 text-green-500"></i>完整性检查</h3><p class="text-gray-600">正在分析病历完整性...</p></div>
                    </div>

                    <!-- 医保分析 -->
                    <div v-if="module.id==='insurance_analysis'">
                        <div v-if="step===0"><h3 class="text-2xl font-bold mb-6"><i class="fas fa-file-invoice-dollar mr-2 text-orange-500"></i>选择病历</h3><input v-model="form.recordId" class="w-full border-2 border-gray-300 rounded-lg px-4 py-3"></div>
                        <div v-if="step===1"><h3 class="text-2xl font-bold mb-6"><i class="fas fa-calculator mr-2 text-green-500"></i>费用录入</h3><div class="grid md:grid-cols-2 gap-4"><div><label class="block text-sm font-semibold text-gray-700 mb-2">药品费</label><input v-model.number="form.drugCost" type="number" class="w-full border-2 border-gray-300 rounded-lg px-4 py-3"></div><div><label class="block text-sm font-semibold text-gray-700 mb-2">检查费</label><input v-model.number="form.examCost" type="number" class="w-full border-2 border-gray-300 rounded-lg px-4 py-3"></div></div></div>
                    </div>

                    <!-- 临床预测 -->
                    <div v-if="module.id==='clinical_prediction'">
                        <div v-if="step===0"><h3 class="text-2xl font-bold mb-6"><i class="fas fa-brain mr-2 text-purple-500"></i>选择模型</h3><div class="space-y-3"><div @click="form.model='sepsis'" :class="['p-4 rounded-lg border-2 cursor-pointer',form.model==='sepsis'?'border-purple-500 bg-purple-50':'border-gray-300']"><p class="font-bold">败血症风险预测</p></div><div @click="form.model='complication'" :class="['p-4 rounded-lg border-2 cursor-pointer',form.model==='complication'?'border-purple-500 bg-purple-50':'border-gray-300']"><p class="font-bold">术后并发症预测</p></div></div></div>
                        <div v-if="step===1"><h3 class="text-2xl font-bold mb-6"><i class="fas fa-heartbeat mr-2 text-red-500"></i>生命体征</h3><div class="grid md:grid-cols-2 gap-4"><div><label class="block text-sm font-semibold text-gray-700 mb-2">体温</label><input v-model.number="form.temp" type="number" step="0.1" class="w-full border-2 border-gray-300 rounded-lg px-4 py-3"></div><div><label class="block text-sm font-semibold text-gray-700 mb-2">心率</label><input v-model.number="form.hr" type="number" class="w-full border-2 border-gray-300 rounded-lg px-4 py-3"></div></div></div>
                    </div>

                    <!-- AI 阅片 -->
                    <div v-if="module.id==='ai_reading'">
                        <div v-if="step===0"><h3 class="text-2xl font-bold mb-6"><i class="fas fa-upload mr-2 text-blue-500"></i>上传影像</h3><div class="border-2 border-dashed border-gray-300 rounded-lg p-12 text-center"><i class="fas fa-cloud-upload-alt text-6xl text-gray-400 mb-4"></i><p class="text-gray-600">拖拽文件到此处</p></div></div>
                        <div v-if="step===1"><h3 class="text-2xl font-bold mb-6"><i class="fas fa-tags mr-2 text-green-500"></i>选择类型</h3><div class="grid md:grid-cols-3 gap-4"><div @click="form.type='ct'" :class="['p-4 rounded-lg border-2 cursor-pointer text-center',form.type==='ct'?'border-blue-500 bg-blue-50':'border-gray-300']"><p class="font-bold">CT</p></div><div @click="form.type='xray'" :class="['p-4 rounded-lg border-2 cursor-pointer text-center',form.type==='xray'?'border-blue-500 bg-blue-50':'border-gray-300']"><p class="font-bold">X 光</p></div><div @click="form.type='mri'" :class="['p-4 rounded-lg border-2 cursor-pointer text-center',form.type==='mri'?'border-blue-500 bg-blue-50':'border-gray-300']"><p class="font-bold">MRI</p></div></div></div>
                    </div>

                    <!-- 科研分析 -->
                    <div v-if="module.id==='research_analysis'">
                        <div v-if="step===0"><h3 class="text-2xl font-bold mb-6"><i class="fas fa-database mr-2 text-cyan-500"></i>数据导入</h3><select v-model="form.dataType" class="w-full border-2 border-gray-300 rounded-lg px-4 py-3"><option value="">请选择</option><option value="csv">CSV</option><option value="excel">Excel</option></select></div>
                        <div v-if="step===1"><h3 class="text-2xl font-bold mb-6"><i class="fas fa-chart-bar mr-2 text-purple-500"></i>分析方法</h3><div class="space-y-3"><div @click="form.analysis='descriptive'" :class="['p-4 rounded-lg border-2 cursor-pointer',form.analysis==='descriptive'?'border-purple-500 bg-purple-50':'border-gray-300']"><p class="font-bold">描述性统计</p></div></div></div>
                    </div>

                    <!-- 论文分析 -->
                    <div v-if="module.id==='paper_analysis'">
                        <div v-if="step===0"><h3 class="text-2xl font-bold mb-6"><i class="fas fa-file-upload mr-2 text-yellow-500"></i>上传论文</h3><select v-model="form.inputType" class="w-full border-2 border-gray-300 rounded-lg px-4 py-3"><option value="file">PDF 文件</option><option value="url">DOI/URL</option></select></div>
                        <div v-if="step===1"><h3 class="text-2xl font-bold mb-6"><i class="fas fa-search mr-2 text-blue-500"></i>信息提取</h3><p class="text-gray-600">正在分析论文...</p></div>
                    </div>

                    <!-- 导航按钮 -->
                    <div class="mt-8 flex justify-between gap-4">
                        <button v-if="step>0" @click="step--" class="px-6 py-3 border-2 border-gray-300 rounded-lg hover:bg-gray-50 font-semibold"><i class="fas fa-chevron-left mr-2"></i>上一步</button>
                        <button v-if="step<module.steps.length-1" @click="step++" class="flex-1 px-6 py-3 bg-blue-500 hover:bg-blue-600 text-white rounded-lg font-semibold">下一步 <i class="fas fa-chevron-right ml-2"></i></button>
                        <button v-if="step===module.steps.length-1" @click="execute" class="flex-1 px-6 py-3 bg-gradient-to-r from-green-500 to-blue-500 text-white rounded-lg font-semibold shadow-lg"><i class="fas fa-check-circle mr-2"></i>完成</button>
                    </div>
                </div>

                <!-- 结果 -->
                <div v-if="loading" class="mt-6 bg-white rounded-xl shadow-lg p-8 text-center"><div class="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto"></div><p class="mt-4 text-gray-600">处理中...</p></div>
                <div v-if="result" class="mt-6 bg-white rounded-xl shadow-lg p-8"><h3 class="text-xl font-bold mb-4">📊 结果</h3><pre class="bg-gray-50 rounded-lg p-4 overflow-auto text-sm">{{JSON.stringify(result,null,2)}}</pre></div>
            </div>
        </main>

        <footer class="bg-gray-800 text-white py-6 mt-8"><div class="container mx-auto px-4 text-center"><p>MedClaw v1.0.0</p></div></footer>
    </div>

    <script>
        const {createApp}=Vue
        createApp({
            data(){return{
                page:'home',
                module:null,
                step:0,
                loading:false,
                result:null,
                form:{},
                modules:[
                    {id:'medical_record',name:'病历书写',desc:'结构化病历生成',icon:'📝',color:'green',steps:['患者信息','主诉','现病史','既往史','体格检查','诊断治疗']},
                    {id:'medical_quality',name:'病历质控',desc:'完整性合理性检查',icon:'✅',color:'blue',steps:['选择病历','完整性检查','合理性分析','ICD 编码','质控报告']},
                    {id:'insurance_analysis',name:'医保分析',desc:'DRG/DIP 分组',icon:'💰',color:'orange',steps:['选择病历','费用录入','DRG 分组','合理性分析','风险评估']},
                    {id:'clinical_prediction',name:'临床预测',desc:'AI 风险预测',icon:'🔮',color:'purple',steps:['选择模型','生命体征','实验室检查','风险评估','干预建议']},
                    {id:'ai_reading',name:'AI 阅片',desc:'智能影像分析',icon:'🖼️',color:'red',steps:['上传影像','选择类型','AI 分析','病灶标注','报告生成']},
                    {id:'research_analysis',name:'科研分析',desc:'统计分析',icon:'📊',color:'cyan',steps:['数据导入','选择方法','统计分析','结果解读','图表生成']},
                    {id:'paper_analysis',name:'论文分析',desc:'PDF 解析',icon:'📄',color:'yellow',steps:['上传论文','信息提取','关键发现','质量评估','综述生成']}
                ]
            }},
            methods:{
                select(m){this.module=m;this.step=0;this.form={}},
                async execute(){
                    this.loading=true
                    setTimeout(()=>{this.loading=false;this.result={success:true,data:this.form}},1500)
                }
            }
        }).mount('#app')
    </script>
</body>
</html>'''
