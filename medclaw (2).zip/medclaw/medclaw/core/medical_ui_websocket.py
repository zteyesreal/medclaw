"""
MedClaw 医疗专用 UI WebSocket 管理器
负责 WebSocket 连接管理和实时消息推送
"""

from fastapi import WebSocket
from typing import List, Any
import logging
from datetime import datetime

logger = logging.getLogger(__name__)


class MedicalConnectionManager:
    """医疗 WebSocket 连接管理器"""
    
    def __init__(self):
        self.active_connections: List[WebSocket] = []
    
    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)
        logger.info(f"医疗 WebSocket 连接：{len(self.active_connections)}")
    
    def disconnect(self, websocket: WebSocket):
        self.active_connections.remove(websocket)
        logger.info(f"医疗 WebSocket 断开：{len(self.active_connections)}")
    
    async def broadcast(self, message: dict):
        """广播消息到所有连接"""
        for connection in self.active_connections:
            try:
                await connection.send_json(message)
            except Exception as e:
                logger.error(f"广播消息失败：{e}")
    
    async def notify_task_update(self, task_id: str, status: str, data: Any = None):
        """通知任务更新"""
        await self.broadcast({
            "type": "task_update",
            "task_id": task_id,
            "status": status,
            "data": data,
            "timestamp": datetime.now().isoformat()
        })


manager = MedicalConnectionManager()
