"""
MedClaw 增强版 Web UI - 七个模块的专业任务引导界面（精简版）
每个模块都有符合现实世界医疗工作流程的完整任务界面
"""

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from typing import Dict, List, Optional, Any
from datetime import datetime
import logging

from .config_api import router as config_router

logger = logging.getLogger(__name__)
app = FastAPI(title="MedClaw 医疗专用界面（完整版）")
app.include_router(config_router)


class MedicalConnectionManager:
    """WebSocket 连接管理器"""
    def __init__(self):
        self.active_connections: List[WebSocket] = []
    
    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)
    
    def disconnect(self, websocket: WebSocket):
        self.active_connections.remove(websocket)


manager = MedicalConnectionManager()


class MedicalRecordRequest(BaseModel):
    patient_info: Dict[str, Any]
    chief_complaint: str
    present_illness: str = ""


class QualityCheckRequest(BaseModel):
    medical_record_id: str
    medical_record: Dict[str, Any]


class InsuranceAnalysisRequest(BaseModel):
    medical_record_id: str
    medical_record: Dict[str, Any]


class PredictionRequest(BaseModel):
    model_name: str
    patient_data: Dict[str, Any]


class AIReadingRequest(BaseModel):
    image_path: str
    image_type: str


class ResearchAnalysisRequest(BaseModel):
    analysis_type: str
    data: Dict[str, Any]


class PaperAnalysisRequest(BaseModel):
    paper_input: str
    input_type: str


@app.get("/", response_class=HTMLResponse)
async def get_index():
    """获取完整版主界面"""
    return get_complete_html_template()


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """WebSocket 端点"""
    await manager.connect(websocket)
    try:
        while True:
            await websocket.receive_json()
    except WebSocketDisconnect:
        manager.disconnect(websocket)


@app.get("/api/modules")
async def get_modules():
    """获取可用医疗模块列表"""
    return {
        "modules": [
            {"id": "medical_record", "name": "智能病历生成引擎", "description": "基于多模态数据融合", "icon": "🧠", "color": "#6366F1"},
            {"id": "medical_quality", "name": "医疗质量智能审计系统", "description": "知识图谱技术", "icon": "🛡️", "color": "#EC4899"},
            {"id": "insurance_analysis", "name": "医保合规性智能评估平台", "description": "DRG/DIP 分组", "icon": "💎", "color": "#8B5CF6"},
            {"id": "clinical_prediction", "name": "临床风险预测", "description": "深度学习与循证医学", "icon": "🔮", "color": "#F59E0B"},
            {"id": "ai_reading", "name": "医学影像 AI", "description": "计算机视觉", "icon": "👁️", "color": "#10B981"},
            {"id": "research_analysis", "name": "临床科研数据分析", "description": "统计分析平台", "icon": "📈", "color": "#3B82F6"},
            {"id": "paper_analysis", "name": "医学文献解读", "description": "NLP 技术", "icon": "📚", "color": "#EF4444"}
        ]
    }


def get_complete_html_template():
    """获取完整版 HTML 模板（精简版）"""
    return """<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>MedClaw - 完整版</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>.gradient-bg{background:linear-gradient(135deg,#667eea 0%,#764ba2 100%)}.card-hover:hover{transform:translateY(-5px)}</style>
</head>
<body class="bg-gray-100">
    <div id="app" class="min-h-screen">
        <header class="gradient-bg text-white shadow-lg py-6">
            <div class="container mx-auto px-4">
                <h1 class="text-3xl font-bold">🏥 MedClaw 完整版</h1>
                <p class="text-blue-100 mt-1">七个专业模块完整实现</p>
            </div>
        </header>
        <main class="container mx-auto px-4 py-8">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div v-for="module in modules" :key="module.id" @click="selectModule(module)"
                     class="bg-white rounded-xl shadow-md p-6 cursor-pointer card-hover"
                     :style="{borderTop:`4px solid ${module.color}`}">
                    <div class="text-4xl mb-3">{{module.icon}}</div>
                    <h3 class="text-xl font-bold">{{module.name}}</h3>
                    <p class="text-gray-600 text-sm">{{module.description}}</p>
                </div>
            </div>
        </main>
    </div>
    <script>
        const{createApp}=Vue
        createApp({
            data(){return{modules:[],selectedModule:null}},
            async mounted(){const r=await fetch('/api/modules');const d=await r.json();this.modules=d.modules},
            methods:{selectModule(m){this.selectedModule=m;alert('选择:'+m.name)}}
        }).mount('#app')
    </script>
</body>
</html>
"""
