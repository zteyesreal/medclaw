"""
MedClaw 病历书写模块 API 路由
"""

from fastapi import APIRouter
from typing import Dict, List, Any, Optional
import asyncio
from datetime import datetime
import logging

from .medical_ui_models import MedicalRecordRequest
from .medical_ui_websocket import manager

logger = logging.getLogger(__name__)

router = APIRouter()


@router.post("/api/medical_record")
async def medical_record(request: MedicalRecordRequest):
    """
    病历书写 - 智能生成电子病历（支持动态调整）
    
    执行步骤：
    1. 查看患者信息 - 获取患者基本信息、既往病史
    2. 记录主要症状 - 整理患者主诉
    3. 分析病情发展 - 生成现病史
    4. 查看过往病史 - 整理既往史、个人史、家族史
    5. 体格检查 - 生成体格检查记录
    6. 查看检验结果 - 分析血常规、生化等检验数据
    7. 查看检查结果 - 分析 CT、MRI、超声等影像学检查
    8. 开检查单 - 建议补充检查
    9. 做出诊断 - 生成初步诊断（结合检验检查结果）
    10. 制定治疗方案 - 生成治疗计划
    11. 写病历 - 生成完整电子病历（包含检验检查结果引用）
    """
    try:
        base_steps = [
            {"action": "get_patient_info", "name": "查看患者信息", "status": "pending", "details": {}, "original_index": 0},
            {"action": "collect_chief_complaint", "name": "记录主要症状", "status": "pending", "details": {}, "original_index": 1},
            {"action": "analyze_present_illness", "name": "分析病情发展", "status": "pending", "details": {}, "original_index": 2},
            {"action": "review_past_history", "name": "查看过往病史", "status": "pending", "details": {}, "original_index": 3},
            {"action": "perform_physical_exam", "name": "体格检查", "status": "pending", "details": {}, "original_index": 4},
            {"action": "review_lab_results", "name": "查看检验结果", "status": "pending", "details": {}, "original_index": 5},
            {"action": "review_exam_results", "name": "查看检查结果", "status": "pending", "details": {}, "original_index": 6},
            {"action": "order_labs", "name": "开检查单", "status": "pending", "details": {}, "original_index": 7},
            {"action": "make_diagnosis", "name": "做出诊断", "status": "pending", "details": {}, "original_index": 8},
            {"action": "create_treatment_plan", "name": "制定治疗方案", "status": "pending", "details": {}, "original_index": 9},
            {"action": "generate_medical_record", "name": "写病历", "status": "pending", "details": {}, "original_index": 10}
        ]
        
        adjustment_log = []
        
        if request.allow_dynamic_adjustment and request.additional_steps:
            for idx, new_step in enumerate(request.additional_steps):
                insert_position = new_step.get("insert_after", 0)
                actual_step = {
                    "action": new_step["action"],
                    "name": new_step["name"],
                    "status": "pending",
                    "details": {},
                    "original_index": 100 + idx,
                    "is_additional": True,
                    "inserted_at": datetime.now().isoformat()
                }
                base_steps.insert(insert_position + idx, actual_step)
                adjustment_log.append({
                    "type": "insert",
                    "step": new_step,
                    "position": insert_position + idx,
                    "timestamp": datetime.now().isoformat()
                })
        
        for i, step in enumerate(base_steps):
            step["step_index"] = i
        
        if request.step_modifications:
            for step_idx, modification in request.step_modifications.items():
                if 0 <= step_idx < len(base_steps):
                    base_steps[step_idx]["modified"] = True
                    base_steps[step_idx]["modification"] = modification
                    adjustment_log.append({
                        "type": "modify",
                        "step_index": step_idx,
                        "modification": modification,
                        "timestamp": datetime.now().isoformat()
                    })
        
        current_step = 0
        total_steps = len(base_steps)
        
        while current_step < total_steps:
            step = base_steps[current_step]
            step["status"] = "doing"
            
            step_details = {}
            if step["action"] == "review_lab_results" and request.lab_results:
                step_details = {
                    "lab_results": request.lab_results,
                    "abnormal_items": []
                }
                if "blood_routine" in request.lab_results:
                    for item, value in request.lab_results["blood_routine"].items():
                        if isinstance(value, dict) and value.get("abnormal", False):
                            step_details["abnormal_items"].append({
                                "name": item,
                                "value": value.get("value"),
                                "unit": value.get("unit"),
                                "flag": value.get("flag")
                            })
            
            if step["action"] == "review_exam_results" and request.exam_results:
                step_details = {
                    "exam_results": request.exam_results,
                    "findings": []
                }
                if "ct" in request.exam_results:
                    step_details["findings"].append({
                        "type": "CT",
                        "body_part": request.exam_results["ct"].get("body_part"),
                        "findings": request.exam_results["ct"].get("findings", [])
                    })
            
            if step.get("modified") and step.get("modification"):
                mod = step["modification"]
                if "new_action" in mod:
                    step["action"] = mod["new_action"]
                if "new_name" in mod:
                    step["name"] = mod["new_name"]
                step_details["modification_applied"] = mod
            
            step["details"] = step_details
            
            await manager.broadcast({
                "type": "step_update",
                "module": "medical_record",
                "current_step": current_step,
                "total_steps": total_steps,
                "step": {
                    "action": step["action"],
                    "name": step["name"],
                    "status": step["status"],
                    "details": step_details,
                    "is_additional": step.get("is_additional", False),
                    "modified": step.get("modified", False)
                },
                "adjustment_log": adjustment_log
            })
            
            await asyncio.sleep(0.3)
            step["status"] = "done"
            current_step += 1
        
        medical_record_text = f"""
【主诉】{request.chief_complaint}

【现病史】{request.present_illness or "患者无明显诱因出现症状..."}

【既往史】{request.patient_info.get('past_history', '无特殊')}

【体格检查】T: 36.5℃ P: 80 次/分 R: 18 次/分 BP: 120/80mmHg

【检验结果】"""
        
        if request.lab_results:
            if "blood_routine" in request.lab_results:
                medical_record_text += "\n  血常规："
                for item, value in request.lab_results["blood_routine"].items():
                    if isinstance(value, dict):
                        medical_record_text += f"{item} {value.get('value')} {value.get('unit')} {value.get('flag', '')} "
        
        medical_record_text += "\n\n【检查结果】"
        if request.exam_results:
            if "ct" in request.exam_results:
                medical_record_text += f"\n  CT 检查：{request.exam_results['ct'].get('findings', '未见明显异常')}"
        
        medical_record_text += f"""

【初步诊断】待补充

【治疗计划】待补充

【记录时间】{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

【动态调整记录】共 {len(adjustment_log)} 次调整
"""
        
        result = {
            "success": True,
            "data": {
                "medical_record_id": f"MR{datetime.now().strftime('%Y%m%d%H%M%S')}",
                "patient_info": request.patient_info,
                "chief_complaint": request.chief_complaint,
                "present_illness": request.present_illness or "患者无明显诱因出现症状...",
                "lab_results": request.lab_results,
                "exam_results": request.exam_results,
                "medical_record_text": medical_record_text,
                "diagnosis": "待补充",
                "treatment_plan": "待补充",
                "generated_at": datetime.now().isoformat(),
                "dynamic_adjustment": {
                    "enabled": request.allow_dynamic_adjustment,
                    "adjustment_count": len(adjustment_log),
                    "adjustments": adjustment_log,
                    "final_step_count": total_steps,
                    "additional_steps_count": len([s for s in base_steps if s.get("is_additional")])
                }
            },
            "progress": {
                "current_step": total_steps,
                "total_steps": total_steps,
                "percentage": 100
            }
        }
        
        await manager.notify_task_update("medical_record", "completed", result)
        return result
    except Exception as e:
        logger.error(f"病历书写失败：{e}")
        return {"success": False, "error": str(e)}


@router.get("/api/demo/medical_record_with_results")
async def demo_medical_record_with_results():
    """演示：病历书写时传递检验检查结果"""
    lab_results = {
        "blood_routine": {
            "WBC": {"value": 12.5, "unit": "×10^9/L", "flag": "↑", "abnormal": True, "normal_range": "4-10"},
            "RBC": {"value": 4.2, "unit": "×10^12/L", "flag": "", "abnormal": False, "normal_range": "4-5.5"},
            "HGB": {"value": 135, "unit": "g/L", "flag": "", "abnormal": False, "normal_range": "120-160"},
            "PLT": {"value": 280, "unit": "×10^9/L", "flag": "", "abnormal": False, "normal_range": "100-300"},
            "NEUT%": {"value": 78.5, "unit": "%", "flag": "↑", "abnormal": True, "normal_range": "50-70"}
        },
        "biochemistry": {
            "ALT": {"value": 45, "unit": "U/L", "flag": "↑", "abnormal": True, "normal_range": "0-40"},
            "AST": {"value": 38, "unit": "U/L", "flag": "", "abnormal": False, "normal_range": "0-40"},
            "GLU": {"value": 5.6, "unit": "mmol/L", "flag": "", "abnormal": False, "normal_range": "3.9-6.1"},
            "CREA": {"value": 85, "unit": "μmol/L", "flag": "", "abnormal": False, "normal_range": "44-133"}
        }
    }
    
    exam_results = {
        "ct": {
            "body_part": "胸部",
            "findings": [
                "右肺上叶见片状高密度影，边界模糊",
                "纵隔淋巴结未见明显肿大",
                "双侧胸腔未见积液"
            ],
            "impression": "右肺上叶炎症，建议抗炎治疗后复查"
        },
        "ultrasound": {
            "body_part": "腹部",
            "findings": [
                "肝脏大小形态正常，实质回声均匀",
                "胆囊大小正常，壁不厚",
                "胰腺、脾脏未见明显异常"
            ],
            "impression": "肝胆胰脾未见明显异常"
        }
    }
    
    return {
        "success": True,
        "message": "检验检查结果示例数据",
        "lab_results": lab_results,
        "exam_results": exam_results,
        "usage": "将这些数据作为 lab_results 和 exam_results 参数传递给 /api/medical_record 接口"
    }


@router.get("/api/demo/dynamic_adjustment_example")
async def demo_dynamic_adjustment_example():
    """演示：动态任务调整示例"""
    return {
        "success": True,
        "message": "动态任务调整示例",
        "examples": {
            "example_1_insert": {
                "description": "在第 5 步后插入'请上级医师会诊'步骤",
                "additional_steps": [
                    {
                        "action": "consult_senior_physician",
                        "name": "请上级医师会诊",
                        "insert_after": 5,
                        "required": True,
                        "reason": "患者病情复杂，需要上级医师指导"
                    }
                ]
            },
            "example_2_modify": {
                "description": "修改第 9 步的名称",
                "step_modifications": {
                    "9": {
                        "new_name": "初步诊断（待完善）",
                        "new_action": "make_preliminary_diagnosis",
                        "note": "需要等待更多检查结果"
                    }
                }
            },
            "example_3_combined": {
                "description": "综合调整：插入 + 修改",
                "additional_steps": [
                    {
                        "action": "review_medication_history",
                        "name": "回顾用药史",
                        "insert_after": 3,
                        "reason": "患者有多种基础疾病，需要详细回顾用药史"
                    },
                    {
                        "action": "check_drug_interactions",
                        "name": "检查药物相互作用",
                        "insert_after": 9,
                        "reason": "新开具药物可能与既往用药有相互作用"
                    }
                ],
                "step_modifications": {
                    "5": {
                        "new_name": "详细体格检查（重点检查肺部）",
                        "emphasis": "肺部听诊"
                    }
                }
            }
        },
        "usage": "将这些配置作为 additional_steps 和 step_modifications 参数传递给 /api/medical_record 接口"
    }
