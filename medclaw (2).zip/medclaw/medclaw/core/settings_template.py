"""
设置管理 HTML 模板
"""

def get_settings_html_template():
    """获取设置管理页面 HTML"""
    return """<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MedClaw - 统一设置</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .tab-content { display: none; }
        .tab-content.active { display: block; }
        .tab-button.active { 
            background-color: #3b82f6; 
            color: white; 
        }
    </style>
</head>
<body class="bg-gray-100">
    <div class="min-h-screen">
        <!-- 顶部导航 -->
        <nav class="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-4 shadow-lg">
            <div class="container mx-auto flex justify-between items-center">
                <h1 class="text-2xl font-bold">
                    <i class="fas fa-cog mr-2"></i>MedClaw 统一设置
                </h1>
                <a href="/" class="text-white hover:text-gray-200">
                    <i class="fas fa-home mr-1"></i>返回首页
                </a>
            </div>
        </nav>

        <!-- 主内容区 -->
        <div class="container mx-auto p-6">
            <!-- 选项卡按钮 -->
            <div class="bg-white rounded-lg shadow-md p-4 mb-6">
                <div class="flex space-x-4 border-b">
                    <button class="tab-button active px-4 py-2 rounded-t" onclick="switchTab('api')">
                        <i class="fas fa-plug mr-2"></i>API 接口设置
                    </button>
                    <button class="tab-button px-4 py-2 rounded-t" onclick="switchTab('database')">
                        <i class="fas fa-database mr-2"></i>数据库设置
                    </button>
                    <button class="tab-button px-4 py-2 rounded-t" onclick="switchTab('module')">
                        <i class="fas fa-puzzle-piece mr-2"></i>模块设置
                    </button>
                    <button class="tab-button px-4 py-2 rounded-t" onclick="switchTab('global')">
                        <i class="fas fa-globe mr-2"></i>全局设置
                    </button>
                </div>
            </div>

            <!-- API 接口设置 -->
            <div id="api-tab" class="tab-content active">
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-xl font-bold mb-4 text-blue-600">
                        <i class="fas fa-plug mr-2"></i>API 接口设置
                    </h2>
                    <form id="api-form" class="space-y-4">
                        <div>
                            <label class="block text-gray-700 font-medium mb-2">API 基础 URL</label>
                            <input type="text" id="api-base-url" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500" 
                                   placeholder="http://localhost:8000">
                        </div>
                        <div>
                            <label class="block text-gray-700 font-medium mb-2">请求超时时间（秒）</label>
                            <input type="number" id="api-timeout" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500" 
                                   value="30">
                        </div>
                        <div>
                            <label class="block text-gray-700 font-medium mb-2">重试次数</label>
                            <input type="number" id="api-retry-count" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500" 
                                   value="3">
                        </div>
                        <div>
                            <label class="block text-gray-700 font-medium mb-2">API 密钥</label>
                            <input type="password" id="api-key" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500" 
                                   placeholder="留空表示不使用认证">
                        </div>
                        <div class="flex items-center">
                            <input type="checkbox" id="api-enable-auth" class="mr-2">
                            <label class="text-gray-700">启用认证</label>
                        </div>
                        <button type="button" onclick="saveAPISettings()" 
                                class="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700">
                            <i class="fas fa-save mr-2"></i>保存设置
                        </button>
                        <button type="button" onclick="loadAPISettings()" 
                                class="bg-gray-600 text-white px-6 py-2 rounded-lg hover:bg-gray-700">
                            <i class="fas fa-redo mr-2"></i>重新加载
                        </button>
                    </form>
                </div>
            </div>

            <!-- 数据库设置 -->
            <div id="database-tab" class="tab-content">
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-xl font-bold mb-4 text-green-600">
                        <i class="fas fa-database mr-2"></i>数据库设置
                    </h2>
                    <form id="database-form" class="space-y-4">
                        <div>
                            <label class="block text-gray-700 font-medium mb-2">数据库驱动</label>
                            <select id="db-driver" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-green-500">
                                <option value="sqlite">SQLite</option>
                                <option value="mysql">MySQL</option>
                                <option value="postgresql">PostgreSQL</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-gray-700 font-medium mb-2">数据库主机</label>
                            <input type="text" id="db-host" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-green-500" 
                                   value="localhost">
                        </div>
                        <div>
                            <label class="block text-gray-700 font-medium mb-2">数据库端口</label>
                            <input type="number" id="db-port" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-green-500" 
                                   value="3306">
                        </div>
                        <div>
                            <label class="block text-gray-700 font-medium mb-2">数据库名</label>
                            <input type="text" id="db-database" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-green-500" 
                                   value="medclaw">
                        </div>
                        <div>
                            <label class="block text-gray-700 font-medium mb-2">用户名</label>
                            <input type="text" id="db-username" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-green-500">
                        </div>
                        <div>
                            <label class="block text-gray-700 font-medium mb-2">密码</label>
                            <input type="password" id="db-password" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-green-500">
                        </div>
                        <div>
                            <label class="block text-gray-700 font-medium mb-2">连接池大小</label>
                            <input type="number" id="db-pool-size" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-green-500" 
                                   value="5">
                        </div>
                        <button type="button" onclick="saveDatabaseSettings()" 
                                class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700">
                            <i class="fas fa-save mr-2"></i>保存设置
                        </button>
                        <button type="button" onclick="loadDatabaseSettings()" 
                                class="bg-gray-600 text-white px-6 py-2 rounded-lg hover:bg-gray-700">
                            <i class="fas fa-redo mr-2"></i>重新加载
                        </button>
                    </form>
                </div>
            </div>

            <!-- 模块设置 -->
            <div id="module-tab" class="tab-content">
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-xl font-bold mb-4 text-purple-600">
                        <i class="fas fa-puzzle-piece mr-2"></i>模块设置
                    </h2>
                    <form id="module-form" class="space-y-4">
                        <div class="flex items-center">
                            <input type="checkbox" id="module-enabled" class="mr-2" checked>
                            <label class="text-gray-700 font-medium">启用所有模块</label>
                        </div>
                        <div>
                            <label class="block text-gray-700 font-medium mb-2">日志级别</label>
                            <select id="module-log-level" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500">
                                <option value="DEBUG">DEBUG</option>
                                <option value="INFO" selected>INFO</option>
                                <option value="WARNING">WARNING</option>
                                <option value="ERROR">ERROR</option>
                            </select>
                        </div>
                        <div class="flex items-center">
                            <input type="checkbox" id="module-cache-enabled" class="mr-2" checked>
                            <label class="text-gray-700">启用缓存</label>
                        </div>
                        <div>
                            <label class="block text-gray-700 font-medium mb-2">缓存过期时间（秒）</label>
                            <input type="number" id="module-cache-ttl" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500" 
                                   value="300">
                        </div>
                        <div>
                            <label class="block text-gray-700 font-medium mb-2">最大并发任务数</label>
                            <input type="number" id="module-max-concurrent" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500" 
                                   value="5">
                        </div>
                        <button type="button" onclick="saveModuleSettings()" 
                                class="bg-purple-600 text-white px-6 py-2 rounded-lg hover:bg-purple-700">
                            <i class="fas fa-save mr-2"></i>保存设置
                        </button>
                        <button type="button" onclick="loadModuleSettings()" 
                                class="bg-gray-600 text-white px-6 py-2 rounded-lg hover:bg-gray-700">
                            <i class="fas fa-redo mr-2"></i>重新加载
                        </button>
                    </form>
                </div>
            </div>

            <!-- 全局设置 -->
            <div id="global-tab" class="tab-content">
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-xl font-bold mb-4 text-orange-600">
                        <i class="fas fa-globe mr-2"></i>全局设置
                    </h2>
                    <form id="global-form" class="space-y-4">
                        <div>
                            <label class="block text-gray-700 font-medium mb-2">应用名称</label>
                            <input type="text" id="global-app-name" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-orange-500" 
                                   value="MedClaw">
                        </div>
                        <div>
                            <label class="block text-gray-700 font-medium mb-2">版本号</label>
                            <input type="text" id="global-version" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-orange-500" 
                                   value="1.0.0">
                        </div>
                        <div class="flex items-center">
                            <input type="checkbox" id="global-debug" class="mr-2">
                            <label class="text-gray-700">调试模式</label>
                        </div>
                        <div>
                            <label class="block text-gray-700 font-medium mb-2">语言</label>
                            <select id="global-language" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-orange-500">
                                <option value="zh-CN" selected>简体中文</option>
                                <option value="en-US">English</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-gray-700 font-medium mb-2">时区</label>
                            <input type="text" id="global-timezone" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-orange-500" 
                                   value="Asia/Shanghai">
                        </div>
                        <button type="button" onclick="saveGlobalSettings()" 
                                class="bg-orange-600 text-white px-6 py-2 rounded-lg hover:bg-orange-700">
                            <i class="fas fa-save mr-2"></i>保存设置
                        </button>
                        <button type="button" onclick="loadGlobalSettings()" 
                                class="bg-gray-600 text-white px-6 py-2 rounded-lg hover:bg-gray-700">
                            <i class="fas fa-redo mr-2"></i>重新加载
                        </button>
                        <button type="button" onclick="resetSettings()" 
                                class="bg-red-600 text-white px-6 py-2 rounded-lg hover:bg-red-700">
                            <i class="fas fa-trash mr-2"></i>重置为默认
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        const API_BASE = window.location.origin;

        // 切换选项卡
        function switchTab(tabName) {
            document.querySelectorAll('.tab-content').forEach(tab => {
                tab.classList.remove('active');
            });
            document.querySelectorAll('.tab-button').forEach(btn => {
                btn.classList.remove('active');
            });
            
            document.getElementById(tabName + '-tab').classList.add('active');
            event.target.classList.add('active');
        }

        // 加载 API 设置
        async function loadAPISettings() {
            try {
                const response = await fetch(`${API_BASE}/api/settings/api`);
                const data = await response.json();
                if (data.success) {
                    document.getElementById('api-base-url').value = data.data.base_url;
                    document.getElementById('api-timeout').value = data.data.timeout;
                    document.getElementById('api-retry-count').value = data.data.retry_count;
                    document.getElementById('api-key').value = data.data.api_key || '';
                    document.getElementById('api-enable-auth').checked = data.data.enable_auth;
                    alert('API 设置加载成功！');
                }
            } catch (error) {
                alert('加载失败：' + error.message);
            }
        }

        // 保存 API 设置
        async function saveAPISettings() {
            try {
                const settings = {
                    base_url: document.getElementById('api-base-url').value,
                    timeout: parseInt(document.getElementById('api-timeout').value),
                    retry_count: parseInt(document.getElementById('api-retry-count').value),
                    api_key: document.getElementById('api-key').value,
                    enable_auth: document.getElementById('api-enable-auth').checked
                };
                
                const response = await fetch(`${API_BASE}/api/settings/api`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(settings)
                });
                
                const data = await response.json();
                if (data.success) {
                    alert('API 设置保存成功！');
                } else {
                    alert('保存失败：' + data.message);
                }
            } catch (error) {
                alert('保存失败：' + error.message);
            }
        }

        // 加载数据库设置
        async function loadDatabaseSettings() {
            try {
                const response = await fetch(`${API_BASE}/api/settings/database`);
                const data = await response.json();
                if (data.success) {
                    document.getElementById('db-driver').value = data.data.driver;
                    document.getElementById('db-host').value = data.data.host;
                    document.getElementById('db-port').value = data.data.port;
                    document.getElementById('db-database').value = data.data.database;
                    document.getElementById('db-username').value = data.data.username || '';
                    document.getElementById('db-password').value = data.data.password || '';
                    document.getElementById('db-pool-size').value = data.data.pool_size;
                    alert('数据库设置加载成功！');
                }
            } catch (error) {
                alert('加载失败：' + error.message);
            }
        }

        // 保存数据库设置
        async function saveDatabaseSettings() {
            try {
                const settings = {
                    driver: document.getElementById('db-driver').value,
                    host: document.getElementById('db-host').value,
                    port: parseInt(document.getElementById('db-port').value),
                    database: document.getElementById('db-database').value,
                    username: document.getElementById('db-username').value,
                    password: document.getElementById('db-password').value,
                    pool_size: parseInt(document.getElementById('db-pool-size').value)
                };
                
                const response = await fetch(`${API_BASE}/api/settings/database`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(settings)
                });
                
                const data = await response.json();
                if (data.success) {
                    alert('数据库设置保存成功！');
                } else {
                    alert('保存失败：' + data.message);
                }
            } catch (error) {
                alert('保存失败：' + error.message);
            }
        }

        // 加载模块设置
        async function loadModuleSettings() {
            try {
                const response = await fetch(`${API_BASE}/api/settings/module`);
                const data = await response.json();
                if (data.success) {
                    document.getElementById('module-enabled').checked = data.data.enabled;
                    document.getElementById('module-log-level').value = data.data.log_level;
                    document.getElementById('module-cache-enabled').checked = data.data.cache_enabled;
                    document.getElementById('module-cache-ttl').value = data.data.cache_ttl;
                    document.getElementById('module-max-concurrent').value = data.data.max_concurrent_tasks;
                    alert('模块设置加载成功！');
                }
            } catch (error) {
                alert('加载失败：' + error.message);
            }
        }

        // 保存模块设置
        async function saveModuleSettings() {
            try {
                const settings = {
                    enabled: document.getElementById('module-enabled').checked,
                    log_level: document.getElementById('module-log-level').value,
                    cache_enabled: document.getElementById('module-cache-enabled').checked,
                    cache_ttl: parseInt(document.getElementById('module-cache-ttl').value),
                    max_concurrent_tasks: parseInt(document.getElementById('module-max-concurrent').value)
                };
                
                const response = await fetch(`${API_BASE}/api/settings/module`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(settings)
                });
                
                const data = await response.json();
                if (data.success) {
                    alert('模块设置保存成功！');
                } else {
                    alert('保存失败：' + data.message);
                }
            } catch (error) {
                alert('保存失败：' + error.message);
            }
        }

        // 加载全局设置
        async function loadGlobalSettings() {
            try {
                const response = await fetch(`${API_BASE}/api/settings`);
                const data = await response.json();
                if (data.success) {
                    document.getElementById('global-app-name').value = data.data.app_name;
                    document.getElementById('global-version').value = data.data.version;
                    document.getElementById('global-debug').checked = data.data.debug;
                    document.getElementById('global-language').value = data.data.language;
                    document.getElementById('global-timezone').value = data.data.timezone;
                    alert('全局设置加载成功！');
                }
            } catch (error) {
                alert('加载失败：' + error.message);
            }
        }

        // 保存全局设置
        async function saveGlobalSettings() {
            try {
                const response = await fetch(`${API_BASE}/api/settings`);
                const currentData = await response.json();
                
                const settings = {
                    ...currentData.data,
                    app_name: document.getElementById('global-app-name').value,
                    version: document.getElementById('global-version').value,
                    debug: document.getElementById('global-debug').checked,
                    language: document.getElementById('global-language').value,
                    timezone: document.getElementById('global-timezone').value
                };
                
                const res = await fetch(`${API_BASE}/api/settings`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(settings)
                });
                
                const data = await res.json();
                if (data.success) {
                    alert('全局设置保存成功！');
                } else {
                    alert('保存失败：' + data.message);
                }
            } catch (error) {
                alert('保存失败：' + error.message);
            }
        }

        // 重置设置
        async function resetSettings() {
            if (!confirm('确定要重置为默认设置吗？')) return;
            
            try {
                const response = await fetch(`${API_BASE}/api/settings/reset`, {
                    method: 'POST'
                });
                
                const data = await response.json();
                if (data.success) {
                    alert('设置已重置为默认值！');
                    location.reload();
                } else {
                    alert('重置失败：' + data.message);
                }
            } catch (error) {
                alert('重置失败：' + error.message);
            }
        }

        // 页面加载时自动加载设置
        window.onload = function() {
            loadAPISettings();
            loadDatabaseSettings();
            loadModuleSettings();
            loadGlobalSettings();
        };
    </script>
</body>
</html>
"""

__all__ = ["get_settings_html_template"]
