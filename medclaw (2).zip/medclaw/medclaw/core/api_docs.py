"""
MedClaw API 文档模块
生成 OpenAPI 文档并提供 Swagger UI 支持
"""

import json
from fastapi import APIRouter, Response
from fastapi.responses import JSONResponse
from typing import Dict, Any

from .web_ui import app

app.title = "MedClaw 医疗 AI 助手 API"
app.version = "1.0.0"
app.description = """
## MedClaw API 文档

MedClaw 是一个医疗专用 AI 助手系统，提供以下核心功能：

### 主要功能模块
- 病历质控：自动检查病历完整性、规范性
- 医保分析：DRG 分组、费用分析
- 临床预测：败血症风险、术后并发症预测
- AI 阅片：CT/X 光/MRI 影像智能分析
- 科研分析：临床数据分析与可视化
- 论文分析：医学文献智能解读

### 认证说明
当前版本无需认证即可使用所有 API。

### 错误处理
所有 API 响应遵循统一的错误格式：
```json
{
  "success": true/false,
  "message": "错误信息",
  "detail": "详细错误描述"
}
```
"""

app.tags_metadata = [
    {"name": "任务管理", "description": "任务创建、查询、状态管理相关 API"},
    {"name": "WebSocket", "description": "实时通信相关 API"},
    {"name": "系统", "description": "系统级 API，包括文档、状态等"},
]

router = APIRouter(prefix="/api/docs", tags=["系统"])


@router.get("/openapi.json", summary="获取 OpenAPI JSON 文档")
async def get_openapi_json() -> JSONResponse:
    return JSONResponse(content=app.openapi())


@router.get("", summary="获取 API 文档信息")
async def get_api_docs_info() -> Dict[str, Any]:
    return {
        "name": app.title,
        "version": app.version,
        "description": "MedClaw 医疗 AI 助手 API",
        "openapi_url": "/api/docs/openapi.json",
        "swagger_ui_url": "/docs",
        "redoc_url": "/redoc",
        "endpoints": {
            "tasks": {"create": "POST /api/tasks", "list": "GET /api/tasks"},
            "websocket": "WebSocket /ws",
        },
    }


app.include_router(router)


def get_enhanced_docstrings() -> Dict[str, Dict[str, str]]:
    return {
        "POST /api/tasks": {
            "summary": "创建新任务",
            "description": "创建一个新的 AI 任务并开始执行",
            "tags": ["任务管理"],
        },
        "GET /api/tasks": {
            "summary": "获取任务列表",
            "description": "获取当前所有任务列表及其状态",
            "tags": ["任务管理"],
        },
        "WebSocket /ws": {
            "summary": "WebSocket 实时通信",
            "description": "建立 WebSocket 连接用于实时双向通信",
            "tags": ["WebSocket"],
        },
    }


__all__ = ["app", "router", "get_openapi_json", "get_api_docs_info", "get_enhanced_docstrings"]
