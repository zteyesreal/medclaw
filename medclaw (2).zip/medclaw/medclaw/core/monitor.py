"""
系统监控模块
监控系统资源、模块状态、请求处理等
"""

import psutil
import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, Any, List
import logging

logger = logging.getLogger(__name__)


class SystemMonitor:
    """系统监控器"""
    
    def __init__(self, log_dir: str = "logs"):
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(exist_ok=True)
        self.start_time = datetime.now()
        self.request_count = 0
        self.error_count = 0
        self.module_stats = {}
    
    def get_system_info(self) -> Dict[str, Any]:
        """获取系统信息"""
        return {
            "cpu_percent": psutil.cpu_percent(interval=1),
            "memory_percent": psutil.virtual_memory().percent,
            "memory_used_gb": psutil.virtual_memory().used / (1024**3),
            "memory_total_gb": psutil.virtual_memory().total / (1024**3),
            "disk_percent": psutil.disk_usage('/').percent if psutil.disk_usage('/') else 0,
        }
    
    def get_uptime(self) -> str:
        """获取运行时长"""
        delta = datetime.now() - self.start_time
        days = delta.days
        hours = delta.seconds // 3600
        minutes = (delta.seconds % 3600) // 60
        return f"{days}天 {hours}小时 {minutes}分钟"
    
    def record_request(self, module_name: str, success: bool = True):
        """记录请求"""
        self.request_count += 1
        
        if module_name not in self.module_stats:
            self.module_stats[module_name] = {
                "requests": 0,
                "errors": 0,
                "last_request": None
            }
        
        self.module_stats[module_name]["requests"] += 1
        self.module_stats[module_name]["last_request"] = datetime.now().isoformat()
        
        if not success:
            self.error_count += 1
            self.module_stats[module_name]["errors"] += 1
    
    def get_status_report(self) -> Dict[str, Any]:
        """获取状态报告"""
        system_info = self.get_system_info()
        
        return {
            "uptime": self.get_uptime(),
            "start_time": self.start_time.isoformat(),
            "system": system_info,
            "requests": {
                "total": self.request_count,
                "errors": self.error_count,
                "success_rate": f"{(1 - self.error_count/max(self.request_count, 1)) * 100:.2f}%"
            },
            "modules": self.module_stats,
            "timestamp": datetime.now().isoformat()
        }
    
    def check_health(self) -> Dict[str, Any]:
        """健康检查"""
        system_info = self.get_system_info()
        
        alerts = []
        
        # CPU 检查
        if system_info["cpu_percent"] > 90:
            alerts.append({
                "level": "warning",
                "type": "cpu_high",
                "message": f"CPU 使用率过高：{system_info['cpu_percent']}%"
            })
        
        # 内存检查
        if system_info["memory_percent"] > 90:
            alerts.append({
                "level": "warning",
                "type": "memory_high",
                "message": f"内存使用率过高：{system_info['memory_percent']}%"
            })
        
        # 磁盘检查
        if system_info["disk_percent"] > 90:
            alerts.append({
                "level": "critical",
                "type": "disk_full",
                "message": f"磁盘空间不足：{system_info['disk_percent']}%"
            })
        
        # 错误率检查
        error_rate = self.error_count / max(self.request_count, 1)
        if error_rate > 0.1:
            alerts.append({
                "level": "warning",
                "type": "high_error_rate",
                "message": f"错误率过高：{error_rate * 100:.2f}%"
            })
        
        return {
            "healthy": len(alerts) == 0,
            "alerts": alerts,
            "timestamp": datetime.now().isoformat()
        }
    
    def save_report(self, filename: str = None):
        """保存状态报告"""
        if not filename:
            filename = f"status_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        filepath = self.log_dir / filename
        report = self.get_status_report()
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        
        logger.info(f"状态报告已保存到：{filepath}")
        return filepath
    
    def print_status(self):
        """打印状态"""
        report = self.get_status_report()
        health = self.check_health()
        
        print("\n" + "=" * 60)
        print("MedClaw 系统状态")
        print("=" * 60)
        print(f"运行时长：{report['uptime']}")
        print(f"启动时间：{report['start_time']}")
        print()
        print("系统资源:")
        print(f"  CPU:    {report['system']['cpu_percent']:.1f}%")
        print(f"  内存：  {report['system']['memory_percent']:.1f}% ({report['system']['memory_used_gb']:.2f}GB / {report['system']['memory_total_gb']:.2f}GB)")
        print(f"  磁盘：  {report['system']['disk_percent']:.1f}%")
        print()
        print("请求统计:")
        print(f"  总请求：{report['requests']['total']}")
        print(f"  错误数：{report['requests']['errors']}")
        print(f"  成功率：{report['requests']['success_rate']}")
        print()
        
        if report['modules']:
            print("模块统计:")
            for module_name, stats in report['modules'].items():
                print(f"  {module_name}:")
                print(f"    请求数：{stats['requests']}")
                print(f"    错误数：{stats['errors']}")
                print(f"    最后请求：{stats['last_request']}")
        
        print()
        print("健康状态:")
        if health['healthy']:
            print("  ✅ 系统健康")
        else:
            for alert in health['alerts']:
                level = "⚠️" if alert['level'] == 'warning' else "❌"
                print(f"  {level} [{alert['level'].upper()}] {alert['message']}")
        
        print("=" * 60 + "\n")


# 全局监控实例
monitor = SystemMonitor()


def get_monitor() -> SystemMonitor:
    """获取监控实例"""
    return monitor
