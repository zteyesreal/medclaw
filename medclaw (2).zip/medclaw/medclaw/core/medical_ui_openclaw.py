"""
MedClaw Web UI - OpenClaw 任务执行模式（精简版）
基于真实医疗职业场景的任务框架

模板已拆分为独立文件:
- medical_ui_openclaw_styles.py: CSS 样式
- medical_ui_openclaw_scripts.py: JavaScript 脚本  
- medical_ui_openclaw_templates.py: HTML 模板
"""

from fastapi import FastAPI, WebSocket
from fastapi.responses import HTMLResponse
import sys
sys.path.append('c:/Users/zt_ey/Downloads/medclaw')
from medclaw.task_framework import PROFESSION_TASK_TEMPLATES, TaskExecutor

from .medical_ui_openclaw_templates import get_openclaw_html_template

app = FastAPI()
executor = TaskExecutor()


class ConnectionManager:
    """WebSocket 连接管理器"""
    def __init__(self):
        self.connections = []
    
    async def connect(self, ws):
        await ws.accept()
        self.connections.append(ws)
    
    def disconnect(self, ws):
        self.connections.remove(ws)


manager = ConnectionManager()


@app.get("/", response_class=HTMLResponse)
async def index():
    """获取 OpenClaw 模式首页"""
    return get_openclaw_html_template()


@app.websocket("/ws")
async def ws_endpoint(ws):
    """WebSocket 端点"""
    await manager.connect(ws)
    try:
        while True:
            await ws.receive_json()
    except Exception:
        manager.disconnect(ws)


@app.get("/api/tasks")
async def get_tasks():
    """获取所有任务模板"""
    return {"templates": PROFESSION_TASK_TEMPLATES}


@app.get("/api/modules")
async def get_modules():
    """获取可用医疗模块列表"""
    return {
        "modules": [
            {
                "id": "clinician",
                "name": "智能病历生成引擎",
                "description": "基于多模态数据融合的病历自动构建系统，支持实时语义理解与临床推理",
                "icon": "🧠",
                "color": "#6366F1"
            },
            {
                "id": "quality_controller",
                "name": "医疗质量智能审计系统",
                "description": "运用知识图谱技术的病历质控引擎，实现全方位医疗质量监控与风险预警",
                "icon": "🛡️",
                "color": "#EC4899"
            },
            {
                "id": "insurance_auditor",
                "name": "医保合规性智能评估平台",
                "description": "基于 DRG/DIP 分组的费用优化与风险管控系统，精准识别医保违规行为",
                "icon": "💎",
                "color": "#8B5CF6"
            },
            {
                "id": "radiologist",
                "name": "医学影像 AI 辅助诊断平台",
                "description": "基于计算机视觉的影像智能分析系统，支持多模态影像识别与病灶自动检测",
                "icon": "👁️",
                "color": "#10B981"
            },
            {
                "id": "clinical_pharmacist",
                "name": "临床风险预测与决策支持系统",
                "description": "融合深度学习与循证医学的智能预测引擎，提供精准风险评估与临床决策建议",
                "icon": "🔮",
                "color": "#F59E0B"
            },
            {
                "id": "researcher",
                "name": "临床科研数据分析工作台",
                "description": "一站式统计分析与可视化平台，支持从数据清洗到论文图表的全流程科研服务",
                "icon": "📈",
                "color": "#3B82F6"
            },
            {
                "id": "nurse",
                "name": "医学文献智能解读系统",
                "description": "基于 NLP 技术的文献自动解析引擎，实现关键信息提取与证据质量评价",
                "icon": "📚",
                "color": "#EF4444"
            },
            {
                "id": "emergency_physician",
                "name": "急诊急救智能分诊系统",
                "description": "基于急诊医学的智能分诊与急救决策支持，快速评估病情危重程度",
                "icon": "🚑",
                "color": "#DC2626"
            }
        ]
    }
