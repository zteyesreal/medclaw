"""
MedClaw 分布式任务执行框架
支持并行执行、任务依赖、条件执行、多 Agent 协作
"""

from typing import Dict, List, Optional, Any, Literal, Callable
from pydantic import BaseModel, Field
from datetime import datetime
from enum import Enum
import asyncio
from collections import deque


# ========== 执行策略和状态枚举 ==========

class ExecutionPolicy(str, Enum):
    """步骤执行策略"""
    SEQUENTIAL = "sequential"  # 顺序执行
    PARALLEL = "parallel"      # 并行执行
    CONDITIONAL = "conditional"  # 条件执行


class TaskStatus(str, Enum):
    """任务状态"""
    PENDING = "pending"
    PLANNING = "planning"
    QUEUED = "queued"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class AgentStatus(str, Enum):
    """Agent 状态"""
    IDLE = "idle"
    BUSY = "busy"
    ERROR = "error"
    OFFLINE = "offline"


# ========== 增强的任务模型 ==========

class RetryPolicy(BaseModel):
    """重试策略"""
    max_retries: int = Field(default=3, description="最大重试次数")
    delay: float = Field(default=1.0, description="初始延迟（秒）")
    backoff: float = Field(default=2.0, description="退避因子")
    max_delay: float = Field(default=60.0, description="最大延迟（秒）")


class TaskStep(BaseModel):
    """增强的任务步骤"""
    id: str = Field(..., description="步骤唯一标识")
    action: str = Field(..., description="操作名称")
    params: Dict[str, Any] = Field(default_factory=dict, description="操作参数")
    
    # 执行策略
    execution_policy: ExecutionPolicy = Field(
        default=ExecutionPolicy.SEQUENTIAL,
        description="执行策略：sequential/parallel/conditional"
    )
    
    # 依赖关系
    dependencies: List[str] = Field(
        default_factory=list,
        description="依赖的步骤 ID 列表"
    )
    
    # 条件执行
    condition: Optional[str] = Field(
        default=None,
        description="执行条件（Python 表达式，可访问前序步骤结果）"
    )
    
    # 重试和超时
    retry_policy: Optional[RetryPolicy] = Field(
        default=None,
        description="重试策略"
    )
    
    timeout: Optional[int] = Field(
        default=None,
        description="超时时间（秒）"
    )
    
    # 优先级
    priority: int = Field(
        default=5,
        ge=1,
        le=10,
        description="优先级（1-10，10 最高）"
    )
    
    # 执行状态
    skipped: bool = Field(default=False, description="是否跳过")
    status: str = Field(default="pending", description="执行状态")
    result: Optional[Any] = Field(default=None, description="执行结果")
    error: Optional[str] = Field(default=None, description="错误信息")
    retries: int = Field(default=0, description="已重试次数")
    
    # 时间戳
    started_at: Optional[str] = Field(default=None, description="开始时间")
    completed_at: Optional[str] = Field(default=None, description="完成时间")


class Task(BaseModel):
    """增强的任务定义"""
    id: str
    name: str
    description: str
    profession: str
    goal: str
    steps: List[TaskStep] = Field(default_factory=list)
    
    # 步骤依赖关系图（DAG）
    step_dependencies: Dict[str, List[str]] = Field(
        default_factory=dict,
        description="步骤依赖关系：step_id -> [dependent_step_ids]"
    )
    
    # 任务状态
    status: TaskStatus = Field(default=TaskStatus.PENDING)
    
    # 执行结果
    result: Optional[Any] = None
    error: Optional[str] = None
    
    # 时间戳
    created_at: str = Field(default_factory=lambda: datetime.now().isoformat())
    started_at: Optional[str] = None
    completed_at: Optional[str] = None
    
    # 执行统计
    total_steps: int = 0
    completed_steps: int = 0
    failed_steps: int = 0
    skipped_steps: int = 0
    
    # 子任务（用于任务拆解）
    subtasks: List["Task"] = Field(default_factory=list)
    parent_task_id: Optional[str] = None
    
    # 分配给特定 Agent
    assigned_agent: Optional[str] = None
    
    class Config:
        arbitrary_types_allowed = True


# ========== 任务模板（保持不变，向后兼容） ==========

class TaskTemplate(BaseModel):
    """任务模板"""
    id: str
    name: str
    profession: str
    description: str
    goal_template: str
    default_steps: List[Dict[str, Any]]
    estimated_duration: str
    required_skills: List[str]


# ========== 条件评估引擎 ==========

class ConditionEvaluator:
    """条件评估引擎"""
    
    @staticmethod
    def evaluate(condition: str, context: Dict[str, Any]) -> bool:
        """
        评估条件表达式
        
        Args:
            condition: Python 表达式字符串
            context: 上下文（包含前序步骤结果）
            
        Returns:
            评估结果
        """
        try:
            # 创建安全的执行环境
            safe_globals = {
                "__builtins__": {
                    "len": len,
                    "str": str,
                    "int": int,
                    "float": float,
                    "bool": bool,
                    "list": list,
                    "dict": dict,
                    "any": any,
                    "all": all,
                    "sum": sum,
                    "min": min,
                    "max": max,
                }
            }
            safe_locals = context
            
            result = eval(condition, safe_globals, safe_locals)
            return bool(result)
        except Exception as e:
            # 条件评估失败，默认不执行
            print(f"条件评估失败：{condition}, 错误：{e}")
            return False


# ========== 拓扑排序（用于依赖解析） ==========

class DependencyResolver:
    """依赖关系解析器"""
    
    @staticmethod
    def topological_sort(steps: List[TaskStep]) -> List[List[str]]:
        """
        拓扑排序，返回可并行执行的步骤组
        
        Args:
            steps: 步骤列表
            
        Returns:
            步骤组列表，每组内的步骤可并行执行
        """
        # 构建邻接表和入度表
        graph: Dict[str, List[str]] = {}
        in_degree: Dict[str, int] = {}
        
        for step in steps:
            step_id = step.id
            graph[step_id] = []
            in_degree[step_id] = 0
        
        # 构建图
        for step in steps:
            for dep_id in step.dependencies:
                if dep_id in graph:
                    graph[dep_id].append(step.id)
                    in_degree[step.id] += 1
        
        # Kahn 算法
        result = []
        queue = deque()
        
        # 找到所有入度为 0 的节点
        for step_id, degree in in_degree.items():
            if degree == 0:
                queue.append(step_id)
        
        while queue:
            # 当前层级的所有节点（可并行执行）
            current_level = list(queue)
            result.append(current_level)
            queue.clear()
            
            # 处理当前层级
            for step_id in current_level:
                for neighbor in graph[step_id]:
                    in_degree[neighbor] -= 1
                    if in_degree[neighbor] == 0:
                        queue.append(neighbor)
        
        # 检查是否有环
        if len(sum(result, [])) != len(steps):
            raise ValueError("检测到循环依赖")
        
        return result
    
    @staticmethod
    def validate_dependencies(steps: List[TaskStep]) -> bool:
        """验证依赖关系是否有效"""
        step_ids = {step.id for step in steps}
        
        for step in steps:
            for dep_id in step.dependencies:
                if dep_id not in step_ids:
                    raise ValueError(f"步骤 {step.id} 依赖不存在的步骤：{dep_id}")
        
        return True


# ========== 导入现有任务模板（向后兼容） ==========

from medclaw.task_framework import PROFESSION_TASK_TEMPLATES

# 导出所有符号
__all__ = [
    "ExecutionPolicy",
    "TaskStatus",
    "AgentStatus",
    "RetryPolicy",
    "TaskStep",
    "Task",
    "TaskTemplate",
    "ConditionEvaluator",
    "DependencyResolver",
    "PROFESSION_TASK_TEMPLATES",
]
