"""
MedClaw OpenClaw 模式 HTML 模板（精简版）
"""


def get_openclaw_html_template():
    """获取 OpenClaw 模式 HTML 模板"""
    return """<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MedClaw - 医疗智能任务系统</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .gradient-bg{background:linear-gradient(135deg,#1e3a8a 0%,#3b82f6 100%)}
        .task-card:hover{transform:translateY(-2px);box-shadow:0 10px 20px rgba(0,0,0,0.15)}
        .step-active{border-color:#10B981;background:#ECFDF5}
        .step-done{border-color:#3B82F6;background:#EFF6FF}
        .step-wait{border-color:#E5E7EB;background:#F9FAFB}
    </style>
</head>
<body class="bg-gray-50">
    <div id="app" class="min-h-screen">
        <header class="gradient-bg text-white shadow-lg py-6">
            <div class="container mx-auto px-4">
                <div class="text-center">
                    <h1 class="text-3xl font-bold">🤖 MedClaw 医疗智能助手</h1>
                    <p class="text-blue-100 mt-2">灵活任务系统 · 全方位赋能医疗工作</p>
                </div>
            </div>
        </header>
        <main class="container mx-auto px-4 py-6">
            <div v-if="!selectedProfession">
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-7xl mx-auto">
                    <div v-for="module in modules" :key="module.id"
                         @click="selectProfession(module.id)"
                         class="bg-white rounded-2xl shadow-lg p-6 cursor-pointer hover:shadow-2xl transition-all duration-300 border-t-4"
                         :style="{borderTopColor: module.color}">
                        <div class="flex items-center gap-4 mb-4">
                            <span class="text-5xl">{{module.icon}}</span>
                            <div>
                                <h3 class="text-lg font-bold text-gray-800 leading-tight">{{module.name}}</h3>
                            </div>
                        </div>
                        <p class="text-gray-600 text-sm leading-relaxed mb-4">{{module.description}}</p>
                        <div class="flex items-center text-sm text-gray-500">
                            <i class="fas fa-list mr-2"></i>
                            <span>{{(templates[module.id]||[]).length}} 个工作任务</span>
                        </div>
                    </div>
                </div>
            </div>
            <div v-if="selectedProfession && !currentTask">
                <button @click="selectedProfession=null" class="mb-4 text-blue-600 hover:text-blue-800 font-medium">
                    <i class="fas fa-arrow-left mr-2"></i>返回功能模块
                </button>
                <h2 class="text-2xl font-bold text-gray-800 mb-6">
                    <span class="text-3xl mr-2">{{getModuleIcon(selectedProfession)}}</span>
                    {{getModuleName(selectedProfession)}} - 工作任务列表
                </h2>
                <div class="grid gap-6">
                    <div v-for="template in templates[selectedProfession]" :key="template.id"
                         @click="selectTask(template)"
                         class="bg-white rounded-xl shadow-md p-6 cursor-pointer task-card transition-all">
                        <div class="flex items-start justify-between mb-4">
                            <div>
                                <h3 class="text-lg font-bold text-gray-800">{{template.name}}</h3>
                                <p class="text-gray-600 text-sm mt-1">{{template.description}}</p>
                            </div>
                            <span class="text-3xl">{{getModuleIcon(selectedProfession)}}</span>
                        </div>
                        <div class="flex gap-4 text-sm text-gray-500">
                            <span><i class="fas fa-clock mr-1"></i>预计{{template.estimated_duration}}</span>
                            <span><i class="fas fa-list-ol mr-1"></i>共{{template.default_steps.length}} 步</span>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
    <script>
        const { createApp } = Vue
        createApp({
            data() {
                return {
                    modules: [],
                    templates: {},
                    selectedProfession: null,
                    currentTask: null,
                    taskStarted: false
                }
            },
            async mounted() {
                await this.loadModules()
                await this.loadTemplates()
            },
            methods: {
                async loadModules() {
                    const response = await fetch('/api/modules')
                    const data = await response.json()
                    this.modules = data.modules
                },
                async loadTemplates() {
                    const response = await fetch('/api/tasks')
                    const data = await response.json()
                    this.templates = data.templates
                },
                selectProfession(id) {
                    this.selectedProfession = id
                },
                getModuleIcon(id) {
                    const module = this.modules.find(m => m.id === id)
                    return module ? module.icon : '📋'
                },
                getModuleName(id) {
                    const module = this.modules.find(m => m.id === id)
                    return module ? module.name : '未知岗位'
                },
                selectTask(template) {
                    this.currentTask = template
                }
            }
        }).mount('#app')
    </script>
</body>
</html>
"""
