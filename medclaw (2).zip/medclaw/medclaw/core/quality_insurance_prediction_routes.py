"""
MedClaw 医疗质量、医保、预测模块 API 路由
"""

from fastapi import APIRouter
from typing import Dict, Any
import asyncio
from datetime import datetime

from .medical_ui_models import QualityCheckRequest, InsuranceAnalysisRequest, PredictionRequest
from .medical_ui_websocket import manager

router = APIRouter()


@router.post("/api/quality_check")
async def quality_check(request: QualityCheckRequest):
    """病历质控 - 医疗质量检查"""
    try:
        steps = [
            {"action": "fetch_active_records", "name": "获取在院病历", "status": "pending", "details": {}},
            {"action": "check_completeness", "name": "检查完整性", "status": "pending", "details": {}},
            {"action": "check_timeliness", "name": "检查及时性", "status": "pending", "details": {}},
            {"action": "validate_icd10", "name": "核对疾病编码", "status": "pending", "details": {}},
            {"action": "detect_issues", "name": "发现问题", "status": "pending", "details": {}},
            {"action": "generate_feedback", "name": "生成反馈", "status": "pending", "details": {}},
            {"action": "notify_physicians", "name": "通知医生", "status": "pending", "details": {}}
        ]
        
        for i, step in enumerate(steps):
            step["status"] = "doing"
            step_details = {}
            
            if step["action"] == "check_completeness":
                step_details = {
                    "medical_record": request.medical_record,
                    "completeness_checklist": [
                        {"item": "主诉", "required": True, "present": bool(request.medical_record.get("chief_complaint"))},
                        {"item": "现病史", "required": True, "present": bool(request.medical_record.get("present_illness"))},
                        {"item": "既往史", "required": True, "present": bool(request.medical_record.get("past_history"))},
                        {"item": "体格检查", "required": True, "present": bool(request.medical_record.get("physical_exam"))},
                        {"item": "辅助检查", "required": False, "present": bool(request.medical_record.get("auxiliary_exam"))}
                    ]
                }
            
            if step["action"] == "detect_issues" and request.historical_issues:
                step_details = {
                    "historical_issues": request.historical_issues,
                    "recurrent_issues": [],
                    "new_issues": []
                }
            
            if step["action"] == "notify_physicians" and request.doctor_workload:
                step_details = {
                    "doctor_workload": request.doctor_workload,
                    "assignment_suggestion": "根据工作量合理分配"
                }
            
            step["details"] = step_details
            
            await manager.broadcast({
                "type": "step_update",
                "module": "quality_check",
                "current_step": i,
                "total_steps": len(steps),
                "step": {
                    "action": step["action"],
                    "name": step["name"],
                    "status": step["status"],
                    "details": step_details
                }
            })
            await asyncio.sleep(0.3)
            step["status"] = "done"
        
        result = {
            "success": True,
            "data": {
                "medical_record_id": request.medical_record_id,
                "quality_score": 92,
                "completeness": {
                    "score": 95,
                    "missing_fields": ["过敏史"],
                    "suggestions": ["请补充患者过敏史信息"]
                },
                "rationality": {
                    "score": 90,
                    "issues": ["诊断依据不够充分"],
                    "suggestions": ["建议补充相关检查结果"]
                },
                "icd10_check": {
                    "valid": True,
                    "code": "G44.200",
                    "description": "紧张性头痛"
                },
                "historical_comparison": {
                    "previous_score": 88,
                    "improvement": 4,
                    "recurrent_issues": request.historical_issues or []
                },
                "checked_at": datetime.now().isoformat()
            },
            "progress": {
                "current_step": len(steps),
                "total_steps": len(steps),
                "percentage": 100
            }
        }
        
        await manager.notify_task_update("quality_check", "completed", result)
        return result
    except Exception as e:
        return {"success": False, "error": str(e)}


@router.post("/api/insurance_analysis")
async def insurance_analysis(request: InsuranceAnalysisRequest):
    """医保分析 - DRG 分组与费用审核"""
    try:
        steps = [
            {"action": "fetch_cases", "name": "获取病例", "status": "pending", "details": {}},
            {"action": "validate_main_diagnosis", "name": "核对主诊断", "status": "pending", "details": {}},
            {"action": "check_complications", "name": "检查并发症", "status": "pending", "details": {}},
            {"action": "review_procedures", "name": "查看手术操作", "status": "pending", "details": {}},
            {"action": "calculate_dr_weight", "name": "计算权重", "status": "pending", "details": {}},
            {"action": "detect_upcoding", "name": "检查高编", "status": "pending", "details": {}},
            {"action": "generate_audit_report", "name": "生成审核报告", "status": "pending", "details": {}}
        ]
        
        for i, step in enumerate(steps):
            step["status"] = "doing"
            step_details = {}
            
            if step["action"] == "calculate_dr_weight" and request.cost_details:
                step_details = {
                    "cost_details": request.cost_details,
                    "cost_structure": {
                        "drugs_ratio": request.cost_details.get("drugs", 0) / request.cost_details.get("total", 1),
                        "exams_ratio": request.cost_details.get("examinations", 0) / request.cost_details.get("total", 1),
                        "consumables_ratio": request.cost_details.get("consumables", 0) / request.cost_details.get("total", 1)
                    },
                    "reasonable_range": {
                        "drugs": "20-30%",
                        "exams": "30-40%",
                        "consumables": "10-15%"
                    }
                }
            
            if step["action"] == "detect_upcoding" and request.historical_audits:
                step_details = {
                    "historical_audits": request.historical_audits,
                    "comparison": "与历史对比",
                    "risk_indicators": []
                }
            
            if step["action"] == "generate_audit_report" and request.insurance_policy:
                step_details = {
                    "insurance_policy": request.insurance_policy,
                    "policy_compliance": "符合政策要求"
                }
            
            step["details"] = step_details
            
            await manager.broadcast({
                "type": "step_update",
                "module": "insurance_analysis",
                "current_step": i,
                "total_steps": len(steps),
                "step": {
                    "action": step["action"],
                    "name": step["name"],
                    "status": step["status"],
                    "details": step_details
                }
            })
            await asyncio.sleep(0.3)
            step["status"] = "done"
        
        cost_analysis = request.cost_details or {
            "total": 5000,
            "drugs": 1500,
            "examinations": 2000,
            "consumables": 500,
            "others": 1000
        }
        
        result = {
            "success": True,
            "data": {
                "medical_record_id": request.medical_record_id,
                "drg_group": {
                    "code": "GB19",
                    "name": "神经系统疾病",
                    "weight": 1.2
                },
                "cost_analysis": cost_analysis,
                "cost_structure_analysis": {
                    "drugs_ratio": f"{cost_analysis.get('drugs', 0) / cost_analysis.get('total', 1) * 100:.1f}%",
                    "exams_ratio": f"{cost_analysis.get('examinations', 0) / cost_analysis.get('total', 1) * 100:.1f}%",
                    "assessment": "费用结构合理" if cost_analysis.get('drugs', 0) / cost_analysis.get('total', 1) < 0.3 else "药占比偏高"
                },
                "risk_warning": {
                    "level": "low",
                    "issues": [],
                    "suggestions": ["费用结构合理"]
                },
                "policy_reference": request.insurance_policy or "国家医保目录 2024 版",
                "historical_comparison": {
                    "previous_audits": len(request.historical_audits or []),
                    "trend": "稳定"
                },
                "analyzed_at": datetime.now().isoformat()
            },
            "progress": {
                "current_step": len(steps),
                "total_steps": len(steps),
                "percentage": 100
            }
        }
        
        await manager.notify_task_update("insurance_analysis", "completed", result)
        return result
    except Exception as e:
        return {"success": False, "error": str(e)}


@router.post("/api/clinical_prediction")
async def clinical_prediction(request: PredictionRequest):
    """临床预测 - 疾病风险评估"""
    try:
        steps = [
            {"action": "get_patient_data", "name": "获取患者数据", "status": "pending"},
            {"action": "preprocess_data", "name": "数据预处理", "status": "pending"},
            {"action": "extract_features", "name": "特征提取", "status": "pending"},
            {"action": "model_inference", "name": "模型推理", "status": "pending"},
            {"action": "calculate_risk", "name": "计算风险评分", "status": "pending"},
            {"action": "risk_stratification", "name": "风险分层", "status": "pending"},
            {"action": "generate_report", "name": "生成评估报告", "status": "pending"}
        ]
        
        for i, step in enumerate(steps):
            step["status"] = "doing"
            await manager.broadcast({
                "type": "step_update",
                "module": "clinical_prediction",
                "current_step": i,
                "total_steps": len(steps),
                "step": step
            })
            await asyncio.sleep(0.3)
            step["status"] = "done"
        
        risk_score = 0.35
        risk_level = "中危" if 0.3 <= risk_score < 0.7 else ("高危" if risk_score >= 0.7 else "低危")
        
        result = {
            "success": True,
            "data": {
                "model_name": request.model_name,
                "risk_score": risk_score,
                "risk_level": risk_level,
                "confidence": 0.87,
                "feature_contributions": {
                    "age": 0.25,
                    "temperature": 0.30,
                    "heart_rate": 0.20,
                    "wbc": 0.25
                },
                "suggestions": [
                    "密切监测生命体征",
                    "完善相关检查",
                    "必要时转入 ICU"
                ],
                "predicted_at": datetime.now().isoformat()
            },
            "progress": {
                "current_step": len(steps),
                "total_steps": len(steps),
                "percentage": 100
            }
        }
        
        await manager.notify_task_update("clinical_prediction", "completed", result)
        return result
    except Exception as e:
        return {"success": False, "error": str(e)}
