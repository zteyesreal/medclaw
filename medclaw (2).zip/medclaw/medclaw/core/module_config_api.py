"""
模块配置 API 路由
"""

from fastapi import APIRouter, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from typing import Dict, Any

from .module_configs import module_config_manager
from .module_config_template import get_module_config_page_template

router = APIRouter(prefix="/api/module-config", tags=["模块配置"])


class ConfigResponse(BaseModel):
    success: bool
    data: Dict[str, Any] = None
    message: str = ""


@router.get("/page", response_class=HTMLResponse)
async def get_module_config_page():
    """获取模块配置页面"""
    return get_module_config_page_template()


@router.get("/{module_id}", response_model=ConfigResponse)
async def get_module_config(module_id: str):
    """获取指定模块的配置"""
    try:
        config = module_config_manager.get_module_config(module_id)
        if config:
            return ConfigResponse(
                success=True,
                data=config.model_dump(),
                message="获取配置成功"
            )
        else:
            return ConfigResponse(
                success=False,
                message=f"模块 {module_id} 不存在"
            )
    except Exception as e:
        return ConfigResponse(
            success=False,
            message=f"获取配置失败：{str(e)}"
        )


@router.put("/{module_id}", response_model=ConfigResponse)
async def update_module_config(module_id: str, config_data: Dict[str, Any]):
    """更新指定模块的配置"""
    try:
        success = module_config_manager.update_module_config(module_id, config_data)
        if success:
            await module_config_manager.save()
            return ConfigResponse(
                success=True,
                data=config_data,
                message="配置更新成功"
            )
        else:
            return ConfigResponse(
                success=False,
                message=f"更新配置失败：模块 {module_id} 不存在"
            )
    except Exception as e:
        return ConfigResponse(
            success=False,
            message=f"更新配置失败：{str(e)}"
        )


@router.get("", response_model=ConfigResponse)
async def get_all_module_configs():
    """获取所有模块的配置"""
    try:
        configs = module_config_manager.get_all_configs()
        return ConfigResponse(
            success=True,
            data=configs,
            message="获取所有配置成功"
        )
    except Exception as e:
        return ConfigResponse(
            success=False,
            message=f"获取配置失败：{str(e)}"
        )
