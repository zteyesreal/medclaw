"""
Computer-Use 模块
实现屏幕识别、鼠标键盘控制、系统 API 调用
"""

try:
    import pyautogui
    import pytesseract
    from PIL import Image as PILImage, ImageGrab
    import numpy as np
    PYAUTOGUI_AVAILABLE = True
except ImportError:
    PYAUTOGUI_AVAILABLE = False
    pyautogui = None
    pytesseract = None
    PILImage = None
    ImageGrab = None
    np = None

from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
import time
import logging
import subprocess
import platform

logger = logging.getLogger(__name__)


class ComputerUseAgent:
    """Computer-Use 智能体"""
    
    def __init__(self):
        if not PYAUTOGUI_AVAILABLE:
            logger.warning("pyautogui 未安装，Computer-Use 功能受限")
            logger.warning("请安装：pip install pyautogui pytesseract pillow opencv-python pygetwindow pyperclip")
        
        self.screen_width, self.screen_height = (0, 0)
        if PYAUTOGUI_AVAILABLE:
            self.screen_width, self.screen_height = pyautogui.size()
        
        self.system = platform.system()
        logger.info(f"Computer-Use Agent 初始化完成")
        logger.info(f"屏幕分辨率：{self.screen_width}x{self.screen_height}")
        logger.info(f"操作系统：{self.system}")
    
    # ========== 屏幕相关 ==========
    
    def get_screen(self):
        """获取当前屏幕截图"""
        if not PYAUTOGUI_AVAILABLE:
            return None
        screenshot = ImageGrab.grab()
        logger.debug(f"获取屏幕截图：{screenshot.size}")
        return screenshot
    
    def save_screenshot(self, filepath: str = "screenshot.png") -> str:
        """保存屏幕截图"""
        screenshot = self.get_screen()
        screenshot.save(filepath)
        logger.info(f"屏幕截图已保存：{filepath}")
        return filepath
    
    def recognize_text(self, image_path: Optional[str] = None) -> str:
        """
        识别屏幕或图片中的文字（OCR）
        
        Args:
            image_path: 图片路径，如果为 None 则识别当前屏幕
            
        Returns:
            识别的文字内容
        """
        if image_path:
            image = Image.open(image_path)
        else:
            image = self.get_screen()
        
        text = pytesseract.image_to_string(image, lang='chi_sim+eng')
        logger.info(f"OCR 识别完成，识别到 {len(text)} 个字符")
        return text
    
    def find_icon(self, icon_path: str, confidence: float = 0.8) -> Optional[Tuple[int, int]]:
        """
        在屏幕上查找图标
        
        Args:
            icon_path: 图标图片路径
            confidence: 匹配置信度
            
        Returns:
            图标中心坐标 (x, y)，如果未找到返回 None
        """
        try:
            import cv2
            
            screenshot = np.array(self.get_screen())
            template = cv2.imread(icon_path)
            
            result = cv2.matchTemplate(screenshot, template, cv2.TM_CCOEFF_NORMED)
            min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)
            
            if max_val >= confidence:
                h, w = template.shape[:2]
                center_x = max_loc[0] + w // 2
                center_y = max_loc[1] + h // 2
                logger.info(f"找到图标，位置：({center_x}, {center_y}), 置信度：{max_val:.2f}")
                return (center_x, center_y)
            else:
                logger.warning(f"未找到图标（置信度：{max_val:.2f}）")
                return None
        except Exception as e:
            logger.error(f"查找图标失败：{e}")
            return None
    
    # ========== 鼠标控制 ==========
    
    def move_mouse(self, x: int, y: int, duration: float = 0.5):
        """
        移动鼠标
        
        Args:
            x: 目标 X 坐标
            y: 目标 Y 坐标
            duration: 移动时间（秒）
        """
        pyautogui.moveTo(x, y, duration=duration)
        logger.debug(f"鼠标移动到：({x}, {y})")
    
    def click(self, x: Optional[int] = None, y: Optional[int] = None, button: str = 'left'):
        """
        点击鼠标
        
        Args:
            x: X 坐标（可选，为 None 则在当前位置点击）
            y: Y 坐标（可选）
            button: 按钮（'left', 'right', 'middle'）
        """
        if x is not None and y is not None:
            self.move_mouse(x, y)
        
        pyautogui.click(button=button)
        logger.debug(f"鼠标点击：{button} 键")
    
    def double_click(self, x: Optional[int] = None, y: Optional[int] = None):
        """双击"""
        if x is not None and y is not None:
            self.move_mouse(x, y)
        pyautogui.doubleClick()
        logger.debug(f"鼠标双击")
    
    def right_click(self, x: Optional[int] = None, y: Optional[int] = None):
        """右键点击"""
        if x is not None and y is not None:
            self.move_mouse(x, y)
        pyautogui.rightClick()
        logger.debug(f"鼠标右键点击")
    
    def drag(self, start_x: int, start_y: int, end_x: int, end_y: int, duration: float = 1.0):
        """
        拖拽操作
        
        Args:
            start_x, start_y: 起始位置
            end_x, end_y: 结束位置
            duration: 拖拽时间
        """
        self.move_mouse(start_x, start_y)
        pyautogui.drag(end_x - start_x, end_y - start_y, duration=duration)
        logger.debug(f"鼠标拖拽：({start_x},{start_y}) -> ({end_x},{end_y})")
    
    def scroll(self, clicks: int, x: Optional[int] = None, y: Optional[int] = None):
        """
        滚动鼠标滚轮
        
        Args:
            clicks: 滚动量（正数向上，负数向下）
            x, y: 滚动位置（可选）
        """
        if x is not None and y is not None:
            self.move_mouse(x, y)
        pyautogui.scroll(clicks)
        logger.debug(f"鼠标滚动：{clicks}")
    
    # ========== 键盘控制 ==========
    
    def type_text(self, text: str, interval: float = 0.1):
        """
        输入文本
        
        Args:
            text: 要输入的文本
            interval: 字符间隔（秒）
        """
        pyautogui.write(text, interval=interval)
        logger.debug(f"输入文本：{text[:50]}...")
    
    def press_key(self, key: str, presses: int = 1, interval: float = 0.1):
        """
        按键
        
        Args:
            key: 键名（如 'enter', 'ctrl', 'a' 等）
            presses: 按压次数
            interval: 间隔
        """
        pyautogui.press(key, presses=presses, interval=interval)
        logger.debug(f"按键：{key}")
    
    def hotkey(self, *keys):
        """
        快捷键组合
        
        Args:
            *keys: 键名列表，如 ('ctrl', 'c')
        """
        pyautogui.hotkey(*keys)
        logger.debug(f"快捷键：{'+'.join(keys)}")
    
    # ========== 系统 API 调用 ==========
    
    def open_application(self, app_name: str):
        """
        打开应用程序
        
        Args:
            app_name: 应用名称或路径
        """
        try:
            if self.system == "Windows":
                subprocess.Popen(app_name, shell=True)
            elif self.system == "Darwin":
                subprocess.Popen(['open', '-a', app_name])
            elif self.system == "Linux":
                subprocess.Popen([app_name])
            
            logger.info(f"打开应用：{app_name}")
        except Exception as e:
            logger.error(f"打开应用失败：{e}")
    
    def get_clipboard(self) -> str:
        """获取剪贴板内容"""
        import pyperclip
        content = pyperclip.paste()
        logger.debug(f"获取剪贴板内容：{len(content)} 字符")
        return content
    
    def set_clipboard(self, text: str):
        """设置剪贴板内容"""
        import pyperclip
        pyperclip.copy(text)
        logger.debug(f"设置剪贴板内容：{text[:50]}...")
    
    def get_active_window(self) -> Dict[str, Any]:
        """获取当前活动窗口信息"""
        try:
            import pygetwindow as gw
            active = gw.getActiveWindow()
            if active:
                info = {
                    "title": active.title,
                    "left": active.left,
                    "top": active.top,
                    "width": active.width,
                    "height": active.height
                }
                logger.debug(f"活动窗口：{active.title}")
                return info
        except Exception as e:
            logger.error(f"获取活动窗口失败：{e}")
        return {}
    
    # ========== 高级操作 ==========
    
    def execute_command(self, command: str) -> str:
        """
        执行系统命令
        
        Args:
            command: 命令字符串
            
        Returns:
            命令输出
        """
        try:
            result = subprocess.run(command, shell=True, capture_output=True, text=True, timeout=30)
            logger.info(f"执行命令：{command[:50]}...")
            return result.stdout + result.stderr
        except Exception as e:
            logger.error(f"执行命令失败：{e}")
            return f"Error: {e}"
    
    def wait(self, seconds: float):
        """等待"""
        time.sleep(seconds)
    
    def get_mouse_position(self) -> Tuple[int, int]:
        """获取鼠标当前位置"""
        pos = pyautogui.position()
        return (pos.x, pos.y)


# 全局实例
computer_use_agent = ComputerUseAgent()


def get_computer_use_agent() -> ComputerUseAgent:
    """获取 Computer-Use Agent 实例"""
    return computer_use_agent
