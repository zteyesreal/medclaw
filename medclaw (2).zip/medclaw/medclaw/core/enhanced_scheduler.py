"""
MedClaw 增强的任务调度器
支持优先级队列、任务超时、取消、统计
"""

import asyncio
import heapq
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime
import logging
import uuid

from .distributed_task_framework import Task, TaskStatus
from .parallel_executor import ParallelTaskExecutor

logger = logging.getLogger(__name__)


class PriorityTask:
    """优先级任务包装器"""
    
    def __init__(self, task: Task, priority: int = 5):
        self.task = task
        self.priority = priority
        self.timestamp = datetime.now()
        # 用于堆排序：(优先级，时间戳，任务)
        # 优先级数字越小优先级越高
        self._sort_key = (-priority, self.timestamp.timestamp())
    
    def __lt__(self, other):
        return self._sort_key < other._sort_key
    
    def __eq__(self, other):
        return self.task.id == other.task.id


class TaskScheduler:
    """增强的任务调度器"""
    
    def __init__(self, executor: Optional[ParallelTaskExecutor] = None):
        self.executor = executor or ParallelTaskExecutor()
        self.task_queue: asyncio.PriorityQueue = asyncio.PriorityQueue()
        self.tasks: Dict[str, Task] = {}
        self.running_tasks: Dict[str, asyncio.Task] = {}
        self.completed_tasks: Dict[str, Task] = {}
        self._priority_queue: List[PriorityTask] = []  # 同步优先级队列
        self._running = False
        self._scheduler_task: Optional[asyncio.Task] = None
        
        # 统计信息
        self.stats = {
            "total_submitted": 0,
            "total_completed": 0,
            "total_failed": 0,
            "total_cancelled": 0,
            "total_execution_time": 0.0,
        }
    
    def submit_task(self, task: Task, priority: int = 5) -> str:
        """
        提交任务到队列
        
        Args:
            task: 任务对象
            priority: 优先级（1-10，10 最高）
            
        Returns:
            任务 ID
        """
        task.status = TaskStatus.QUEUED
        self.tasks[task.id] = task
        self.stats["total_submitted"] += 1
        
        # 添加到优先级队列
        priority_task = PriorityTask(task, priority)
        heapq.heappush(self._priority_queue, priority_task)
        
        logger.info(f"任务已提交：{task.name} (优先级：{priority})")
        return task.id
    
    async def submit_task_async(self, task: Task, priority: int = 5) -> str:
        """
        异步提交任务
        
        Args:
            task: 任务对象
            priority: 优先级
            
        Returns:
            任务 ID
        """
        task.status = TaskStatus.QUEUED
        self.tasks[task.id] = task
        self.stats["total_submitted"] += 1
        
        await self.task_queue.put((-priority, task))
        
        logger.info(f"任务已异步提交：{task.name} (优先级：{priority})")
        return task.id
    
    async def start(self):
        """启动调度器"""
        if self._running:
            logger.warning("调度器已在运行")
            return
        
        self._running = True
        self._scheduler_task = asyncio.create_task(self._scheduler_loop())
        logger.info("调度器已启动")
    
    async def stop(self):
        """停止调度器"""
        self._running = False
        
        if self._scheduler_task:
            self._scheduler_task.cancel()
            try:
                await self._scheduler_task
            except asyncio.CancelledError:
                pass
        
        logger.info("调度器已停止")
    
    async def _scheduler_loop(self):
        """调度器主循环"""
        while self._running:
            try:
                # 从优先级队列获取任务
                if self._priority_queue:
                    priority_task = heapq.heappop(self._priority_queue)
                    task = priority_task.task
                    
                    # 异步执行任务
                    asyncio.create_task(self._execute_task(task))
                
                await asyncio.sleep(0.1)  # 避免空转
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"调度器循环错误：{e}")
                await asyncio.sleep(1)
    
    async def execute_task_now(self, task: Task, priority: int = 5) -> Task:
        """
        立即执行任务（不经过队列）
        
        Args:
            task: 任务对象
            priority: 优先级
            
        Returns:
            执行后的任务对象
        """
        return await self._execute_task(task, priority)
    
    async def _execute_task(self, task: Task, priority: int = 5) -> Task:
        """
        执行单个任务
        
        Args:
            task: 任务对象
            priority: 优先级
            
        Returns:
            执行后的任务对象
        """
        task.status = TaskStatus.RUNNING
        self.running_tasks[task.id] = asyncio.current_task()
        
        start_time = datetime.now()
        logger.info(f"开始执行任务：{task.name}")
        
        try:
            # 设置超时（如果有）
            if hasattr(task, 'timeout') and task.timeout:
                result = await asyncio.wait_for(
                    self.executor.execute_task(task),
                    timeout=task.timeout
                )
            else:
                result = await self.executor.execute_task(task)
            
            # 更新统计
            end_time = datetime.now()
            execution_time = (end_time - start_time).total_seconds()
            self.stats["total_execution_time"] += execution_time
            
            if task.status == TaskStatus.COMPLETED:
                self.stats["total_completed"] += 1
            else:
                self.stats["total_failed"] += 1
            
            # 移动到已完成
            self.completed_tasks[task.id] = task
            if task.id in self.tasks:
                del self.tasks[task.id]
            
        except asyncio.TimeoutError:
            task.status = TaskStatus.FAILED
            task.error = f"任务执行超时（{task.timeout}秒）"
            logger.error(f"任务超时：{task.name}")
            self.stats["total_failed"] += 1
            
        except asyncio.CancelledError:
            task.status = TaskStatus.CANCELLED
            logger.info(f"任务已取消：{task.name}")
            self.stats["total_cancelled"] += 1
            
        except Exception as e:
            task.status = TaskStatus.FAILED
            task.error = str(e)
            logger.error(f"任务执行失败：{e}")
            self.stats["total_failed"] += 1
        
        finally:
            if task.id in self.running_tasks:
                del self.running_tasks[task.id]
        
        return task
    
    async def cancel_task(self, task_id: str) -> bool:
        """
        取消任务
        
        Args:
            task_id: 任务 ID
            
        Returns:
            是否成功取消
        """
        # 检查是否在运行
        if task_id in self.running_tasks:
            running_task = self.running_tasks[task_id]
            running_task.cancel()
            logger.info(f"已取消运行中的任务：{task_id}")
            return True
        
        # 检查是否在队列中
        if task_id in self.tasks:
            task = self.tasks[task_id]
            task.status = TaskStatus.CANCELLED
            del self.tasks[task_id]
            self.stats["total_cancelled"] += 1
            logger.info(f"已取消队列中的任务：{task_id}")
            return True
        
        logger.warning(f"任务不存在：{task_id}")
        return False
    
    def get_task_status(self, task_id: str) -> Optional[TaskStatus]:
        """获取任务状态"""
        if task_id in self.tasks:
            return self.tasks[task_id].status
        elif task_id in self.running_tasks:
            return TaskStatus.RUNNING
        elif task_id in self.completed_tasks:
            return self.completed_tasks[task_id].status
        
        return None
    
    def get_task(self, task_id: str) -> Optional[Task]:
        """获取任务对象"""
        if task_id in self.tasks:
            return self.tasks[task_id]
        elif task_id in self.completed_tasks:
            return self.completed_tasks[task_id]
        
        return None
    
    def get_queue_size(self) -> int:
        """获取队列大小"""
        return len(self._priority_queue)
    
    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        stats = self.stats.copy()
        
        # 计算平均值
        if stats["total_completed"] > 0:
            stats["avg_execution_time"] = (
                stats["total_execution_time"] / stats["total_completed"]
            )
        else:
            stats["avg_execution_time"] = 0.0
        
        # 添加当前状态
        stats["queue_size"] = self.get_queue_size()
        stats["running_tasks"] = len(self.running_tasks)
        stats["pending_tasks"] = len(self.tasks)
        
        return stats
    
    def clear_completed(self):
        """清理已完成的任务"""
        count = len(self.completed_tasks)
        self.completed_tasks.clear()
        logger.info(f"已清理 {count} 个已完成的任务")
    
    def get_task_history(
        self,
        status: Optional[TaskStatus] = None,
        limit: int = 100
    ) -> List[Task]:
        """
        获取任务历史
        
        Args:
            status: 过滤状态（可选）
            limit: 返回数量限制
            
        Returns:
            任务列表
        """
        history = list(self.completed_tasks.values())
        
        if status:
            history = [t for t in history if t.status == status]
        
        # 按完成时间排序
        history.sort(
            key=lambda t: t.completed_at or "",
            reverse=True
        )
        
        return history[:limit]


class TaskQueueManager:
    """任务队列管理器"""
    
    def __init__(self):
        self.schedulers: Dict[str, TaskScheduler] = {}
        self.default_scheduler: Optional[TaskScheduler] = None
    
    def create_scheduler(
        self,
        scheduler_id: str = "default",
        executor: Optional[ParallelTaskExecutor] = None
    ) -> TaskScheduler:
        """创建调度器"""
        scheduler = TaskScheduler(executor)
        self.schedulers[scheduler_id] = scheduler
        
        if not self.default_scheduler:
            self.default_scheduler = scheduler
        
        logger.info(f"已创建调度器：{scheduler_id}")
        return scheduler
    
    def get_scheduler(self, scheduler_id: str) -> Optional[TaskScheduler]:
        """获取调度器"""
        return self.schedulers.get(scheduler_id)
    
    async def start_all(self):
        """启动所有调度器"""
        for scheduler_id, scheduler in self.schedulers.items():
            await scheduler.start()
            logger.info(f"调度器 {scheduler_id} 已启动")
    
    async def stop_all(self):
        """停止所有调度器"""
        for scheduler_id, scheduler in self.schedulers.items():
            await scheduler.stop()
            logger.info(f"调度器 {scheduler_id} 已停止")


# ========== 导出符号 ==========

__all__ = [
    "TaskScheduler",
    "TaskQueueManager",
    "PriorityTask",
]
