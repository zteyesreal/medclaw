"""
MedClaw 医疗专用 Web UI - 增强版（精简版）
包含七个模块的专业任务引导界面

已拆分为模块化结构
"""

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel
from typing import Dict, List, Optional, Any
import asyncio
import json
from datetime import datetime
import logging
from pathlib import Path

from .config_api import router as config_router

logger = logging.getLogger(__name__)

app = FastAPI(title="MedClaw 医疗专用界面")
app.include_router(config_router)

medical_modules = {}
active_tasks = {}


class MedicalRecordRequest(BaseModel):
    """病历书写请求"""
    patient_info: Dict[str, Any]
    chief_complaint: str
    present_illness: str = ""
    action: str = "generate"


class QualityCheckRequest(BaseModel):
    """病历质控请求"""
    medical_record_id: str
    medical_record: Dict[str, Any]
    check_type: str = "full"


class InsuranceAnalysisRequest(BaseModel):
    """医保分析请求"""
    medical_record_id: str
    medical_record: Dict[str, Any]


class PredictionRequest(BaseModel):
    """临床预测请求"""
    model_name: str
    patient_data: Dict[str, Any]


class AIReadingRequest(BaseModel):
    """AI 阅片请求"""
    image_path: str
    image_type: str


class ResearchAnalysisRequest(BaseModel):
    """科研分析请求"""
    analysis_type: str
    data: Dict[str, Any]


class PaperAnalysisRequest(BaseModel):
    """论文分析请求"""
    paper_input: str
    input_type: str


class ConnectionManager:
    """WebSocket 连接管理器"""
    def __init__(self):
        self.connections = []
    
    async def connect(self, ws):
        await ws.accept()
        self.connections.append(ws)
    
    def disconnect(self, ws):
        self.connections.remove(ws)


manager = ConnectionManager()


@app.get("/", response_class=HTMLResponse)
async def get_index():
    """获取增强版主界面"""
    return get_enhanced_html_template()


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """WebSocket 端点"""
    await manager.connect(websocket)
    try:
        while True:
            await websocket.receive_json()
    except WebSocketDisconnect:
        manager.disconnect(websocket)


@app.get("/api/modules")
async def get_modules():
    """获取可用医疗模块列表"""
    return {
        "modules": [
            {"id": "medical_record", "name": "智能病历生成引擎", "description": "基于多模态数据融合的病历自动构建系统", "icon": "🧠", "color": "#6366F1"},
            {"id": "medical_quality", "name": "医疗质量智能审计系统", "description": "运用知识图谱技术的病历质控引擎", "icon": "🛡️", "color": "#EC4899"},
            {"id": "insurance_analysis", "name": "医保合规性智能评估平台", "description": "基于 DRG/DIP 分组的费用优化系统", "icon": "💎", "color": "#8B5CF6"},
            {"id": "clinical_prediction", "name": "临床风险预测与决策支持系统", "description": "融合深度学习与循证医学的智能预测引擎", "icon": "🔮", "color": "#F59E0B"},
            {"id": "ai_reading", "name": "医学影像 AI 辅助诊断平台", "description": "基于计算机视觉的影像智能分析系统", "icon": "👁️", "color": "#10B981"},
            {"id": "research_analysis", "name": "临床科研数据分析工作台", "description": "一站式统计分析与可视化平台", "icon": "📈", "color": "#3B82F6"},
            {"id": "paper_analysis", "name": "医学文献智能解读系统", "description": "基于 NLP 技术的文献自动解析引擎", "icon": "📚", "color": "#EF4444"}
        ]
    }


def get_enhanced_html_template():
    """获取增强版 HTML 模板（精简版）"""
    return """<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MedClaw - 医疗专用界面（增强版）</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .gradient-bg { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
        .card-hover:hover { transform: translateY(-5px); box-shadow: 0 10px 20px rgba(0,0,0,0.1); }
    </style>
</head>
<body class="bg-gray-100">
    <div id="app" class="min-h-screen">
        <header class="gradient-bg text-white shadow-lg py-6">
            <div class="container mx-auto px-4">
                <h1 class="text-3xl font-bold">🏥 MedClaw 医疗专用界面（增强版）</h1>
                <p class="text-blue-100 mt-1">七个专业模块 · 全方位医疗智能服务</p>
            </div>
        </header>
        <main class="container mx-auto px-4 py-8">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                <div v-for="module in modules" :key="module.id"
                     @click="selectModule(module)"
                     class="bg-white rounded-xl shadow-md p-6 cursor-pointer card-hover transition-all"
                     :style="{borderTop: `4px solid ${module.color}`}">
                    <div class="text-4xl mb-3">{{ module.icon }}</div>
                    <h3 class="text-xl font-bold text-gray-800 mb-2">{{ module.name }}</h3>
                    <p class="text-gray-600 text-sm">{{ module.description }}</p>
                </div>
            </div>
        </main>
    </div>
    <script>
        const { createApp } = Vue
        createApp({
            data() {
                return { modules: [], selectedModule: null }
            },
            async mounted() {
                const response = await fetch('/api/modules')
                const data = await response.json()
                this.modules = data.modules
            },
            methods: {
                selectModule(module) {
                    this.selectedModule = module
                    alert('选择模块：' + module.name)
                }
            }
        }).mount('#app')
    </script>
</body>
</html>
"""
