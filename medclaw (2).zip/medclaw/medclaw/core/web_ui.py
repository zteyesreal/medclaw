"""
Web UI 可视化界面（精简版）
基于 FastAPI + Vue.js 的现代化界面
"""

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from typing import Dict, List, Optional, Any
import asyncio
import json
from datetime import datetime
import logging

from .computer_use import get_computer_use_agent
from .office_automation import get_office_automation
from .task_engine import get_autonomous_task_engine, TaskStatus

logger = logging.getLogger(__name__)

app = FastAPI(title="MedClaw Web UI")


class TaskRequest(BaseModel):
    goal: str
    execute: bool = True


class ComputerAction(BaseModel):
    action: str
    params: Dict[str, Any]


class TaskStatusResponse(BaseModel):
    task_id: str
    goal: str
    status: str
    progress: int
    result: Optional[str] = None


class ConnectionManager:
    """WebSocket 连接管理器"""
    def __init__(self):
        self.active_connections: List[WebSocket] = []
    
    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)
    
    def disconnect(self, websocket: WebSocket):
        self.active_connections.remove(websocket)
    
    async def broadcast(self, message: dict):
        for connection in self.active_connections:
            await connection.send_json(message)


manager = ConnectionManager()
task_engine = get_autonomous_task_engine()


@app.get("/", response_class=HTMLResponse)
async def get_index():
    """获取 Web UI 首页"""
    return get_web_ui_html()


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """WebSocket 端点"""
    await manager.connect(websocket)
    try:
        while True:
            data = await websocket.receive_json()
            logger.info(f"收到消息：{data}")
    except WebSocketDisconnect:
        manager.disconnect(websocket)


@app.get("/api/tasks")
async def get_tasks():
    """获取任务列表"""
    return {"tasks": []}


@app.post("/api/tasks")
async def create_task(request: TaskRequest):
    """创建新任务"""
    return {"success": True, "task_id": "task_001", "goal": request.goal}


def get_web_ui_html():
    """获取 Web UI HTML 模板（精简版）"""
    return """<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>MedClaw Web UI</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>
    <style>.gradient-bg{background:linear-gradient(135deg,#667eea 0%,#764ba2 100%)}</style>
</head>
<body class="bg-gray-100">
    <div id="app" class="min-h-screen">
        <header class="gradient-bg text-white shadow-lg py-6">
            <div class="container mx-auto px-4">
                <h1 class="text-3xl font-bold">🌐 MedClaw Web UI</h1>
                <p class="text-blue-100 mt-1">通用 Web 界面</p>
            </div>
        </header>
        <main class="container mx-auto px-4 py-8">
            <div class="bg-white rounded-xl shadow-md p-6">
                <h2 class="text-2xl font-bold mb-4">任务管理</h2>
                <button @click="createTask" class="bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-lg">
                    <i class="fas fa-plus mr-2"></i>创建任务
                </button>
            </div>
        </main>
    </div>
    <script>
        const{createApp}=Vue
        createApp({
            data(){return{tasks:[]}},
            methods:{
                async createTask(){
                    const r=await fetch('/api/tasks',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({goal:'新任务',execute:true})});
                    const d=await r.json();
                    alert('任务创建成功：'+d.task_id)
                }
            }
        }).mount('#app')
    </script>
</body>
</html>
"""
