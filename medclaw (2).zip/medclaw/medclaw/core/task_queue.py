"""
MedClaw 任务队列系统
支持内存队列、Redis队列、RabbitMQ队列
"""

import asyncio
import json
import time
from typing import Dict, List, Optional, Any, Union, Callable
from datetime import datetime
import logging
from enum import Enum
import uuid

logger = logging.getLogger(__name__)


class QueueType(str, Enum):
    """队列类型"""
    MEMORY = "memory"
    REDIS = "redis"
    RABBITMQ = "rabbitmq"


class TaskPriority(int, Enum):
    """任务优先级"""
    LOWEST = 1
    LOW = 3
    NORMAL = 5
    HIGH = 7
    HIGHEST = 10


class TaskStatus(str, Enum):
    """任务状态"""
    PENDING = "pending"
    QUEUED = "queued"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class QueueItem:
    """队列项"""
    
    def __init__(
        self,
        task_id: str,
        task_data: Any,
        priority: TaskPriority = TaskPriority.NORMAL,
        created_at: Optional[datetime] = None,
        scheduled_at: Optional[datetime] = None,
    ):
        self.task_id = task_id
        self.task_data = task_data
        self.priority = priority
        self.created_at = created_at or datetime.now()
        self.scheduled_at = scheduled_at or datetime.now()
        self.attempts = 0
        self.max_attempts = 3
        self.retry_delay = 1.0  # 秒
        self.timeout = 300  # 5 分钟超时
    
    def __lt__(self, other):
        """比较方法，用于优先级队列排序"""
        # 先比较优先级（高的优先），再比较创建时间（早的优先）
        if self.priority != other.priority:
            return self.priority > other.priority  # 优先级高的先出队
        return self.created_at < other.created_at  # 同优先级，先创建的先出队
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "task_id": self.task_id,
            "task_data": self.task_data,
            "priority": self.priority.value,
            "created_at": self.created_at.isoformat(),
            "scheduled_at": self.scheduled_at.isoformat(),
            "attempts": self.attempts,
            "max_attempts": self.max_attempts,
            "timeout": self.timeout,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "QueueItem":
        item = cls(
            task_id=data["task_id"],
            task_data=data["task_data"],
            priority=TaskPriority(data["priority"]),
            created_at=datetime.fromisoformat(data["created_at"]),
            scheduled_at=datetime.fromisoformat(data["scheduled_at"]),
        )
        item.attempts = data.get("attempts", 0)
        item.max_attempts = data.get("max_attempts", 3)
        item.timeout = data.get("timeout", 300)
        return item


class BaseTaskQueue:
    """任务队列基类"""
    
    def __init__(self, queue_name: str = "default"):
        self.queue_name = queue_name
        self.size = 0
        self.stats = {
            "enqueued": 0,
            "dequeued": 0,
            "processed": 0,
            "failed": 0,
            "cancelled": 0,
        }
    
    async def enqueue(self, item: QueueItem) -> bool:
        """入队"""
        raise NotImplementedError
    
    async def dequeue(self) -> Optional[QueueItem]:
        """出队"""
        raise NotImplementedError
    
    async def peek(self) -> Optional[QueueItem]:
        """查看队首元素（不移除）"""
        raise NotImplementedError
    
    async def size(self) -> int:
        """队列大小"""
        raise NotImplementedError
    
    async def clear(self):
        """清空队列"""
        raise NotImplementedError
    
    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        return self.stats.copy()


class MemoryTaskQueue(BaseTaskQueue):
    """内存任务队列"""
    
    def __init__(self, queue_name: str = "default"):
        super().__init__(queue_name)
        self._queue: asyncio.PriorityQueue = asyncio.PriorityQueue()
        self._items: Dict[str, QueueItem] = {}  # task_id -> item
        self._cancelled: set = set()  # 已取消的任务ID
    
    async def enqueue(self, item: QueueItem) -> bool:
        """入队"""
        try:
            # 使用负优先级值，因为 PriorityQueue 是最小堆
            priority_value = -item.priority
            await self._queue.put((priority_value, item.created_at.timestamp(), item))
            
            self._items[item.task_id] = item
            self.size += 1
            self.stats["enqueued"] += 1
            
            logger.info(f"任务 {item.task_id} 已入队（优先级：{item.priority}）")
            return True
        except Exception as e:
            logger.error(f"任务入队失败：{e}")
            return False
    
    async def dequeue(self) -> Optional[QueueItem]:
        """出队"""
        try:
            if self._queue.empty():
                return None
            
            priority_value, timestamp, item = await self._queue.get()
            
            # 检查是否已取消
            if item.task_id in self._cancelled:
                self._cancelled.remove(item.task_id)
                self.size -= 1
                return await self.dequeue()  # 递归获取下一个
            
            # 更新状态
            item.attempts += 1
            self.size -= 1
            self.stats["dequeued"] += 1
            
            logger.info(f"任务 {item.task_id} 已出队（尝试次数：{item.attempts}）")
            return item
        except Exception as e:
            logger.error(f"任务出队失败：{e}")
            return None
    
    async def peek(self) -> Optional[QueueItem]:
        """查看队首元素"""
        try:
            if self._queue.empty():
                return None
            
            # 临时获取元素
            priority_value, timestamp, item = await self._queue.get()
            
            # 立即放回去
            await self._queue.put((priority_value, timestamp, item))
            
            return item
        except Exception as e:
            logger.error(f"查看队首元素失败：{e}")
            return None
    
    async def size(self) -> int:
        """队列大小"""
        return self._queue.qsize()
    
    async def clear(self):
        """清空队列"""
        while not self._queue.empty():
            try:
                await self._queue.get()
            except:
                break
        self._items.clear()
        self._cancelled.clear()
        self.size = 0
    
    async def cancel_task(self, task_id: str) -> bool:
        """取消任务"""
        if task_id in self._items:
            self._cancelled.add(task_id)
            self.stats["cancelled"] += 1
            logger.info(f"任务 {task_id} 已取消")
            return True
        return False
    
    async def remove_task(self, task_id: str) -> bool:
        """移除任务（从队列中彻底删除）"""
        if task_id in self._items:
            del self._items[task_id]
            # 从队列中移除需要重建队列，这里简化处理
            self._cancelled.add(task_id)
            logger.info(f"任务 {task_id} 已移除")
            return True
        return False


class RedisTaskQueue(BaseTaskQueue):
    """Redis 任务队列"""
    
    def __init__(self, queue_name: str = "default", redis_host: str = "localhost", redis_port: int = 6379):
        super().__init__(queue_name)
        self.redis_host = redis_host
        self.redis_port = redis_port
        self.redis = None
        self._initialized = False
    
    async def initialize(self):
        """初始化 Redis 连接"""
        try:
            import aioredis
            self.redis = await aioredis.from_url(f"redis://{self.redis_host}:{self.redis_port}")
            self._initialized = True
            logger.info(f"Redis 队列 {self.queue_name} 初始化成功")
        except ImportError:
            logger.error("需要安装 aioredis: pip install aioredis")
            raise
        except Exception as e:
            logger.error(f"Redis 队列初始化失败：{e}")
            raise
    
    async def ensure_initialized(self):
        """确保已初始化"""
        if not self._initialized:
            await self.initialize()
    
    async def enqueue(self, item: QueueItem) -> bool:
        """入队"""
        await self.ensure_initialized()
        try:
            # 序列化任务数据
            item_data = json.dumps(item.to_dict())
            
            # 使用 ZADD 实现优先级队列（score 为优先级的负值）
            priority_score = -item.priority
            await self.redis.zadd(self.queue_name, {item.task_id: priority_score})
            
            # 存储任务详情
            await self.redis.hset(f"{self.queue_name}:details", item.task_id, item_data)
            
            self.stats["enqueued"] += 1
            logger.info(f"任务 {item.task_id} 已入 Redis 队列（优先级：{item.priority}）")
            return True
        except Exception as e:
            logger.error(f"任务入 Redis 队列失败：{e}")
            return False
    
    async def dequeue(self) -> Optional[QueueItem]:
        """出队"""
        await self.ensure_initialized()
        try:
            # 获取最高优先级的元素（分数最小的，即负值最大的）
            members = await self.redis.zrange(
                self.queue_name, 0, 0, withscores=True
            )
            
            if not members:
                return None
            
            task_id, priority_score = members[0]
            task_id = task_id.decode('utf-8') if isinstance(task_id, bytes) else task_id
            
            # 获取任务详情
            item_data = await self.redis.hget(f"{self.queue_name}:details", task_id)
            if not item_data:
                # 任务详情不存在，删除队列中的条目
                await self.redis.zrem(self.queue_name, task_id)
                return await self.dequeue()  # 递归获取下一个
            
            item = QueueItem.from_dict(json.loads(item_data))
            item.attempts += 1
            
            # 从队列中移除
            await self.redis.zrem(self.queue_name, task_id)
            await self.redis.hdel(f"{self.queue_name}:details", task_id)
            
            self.stats["dequeued"] += 1
            logger.info(f"任务 {item.task_id} 已从 Redis 队列出队（尝试次数：{item.attempts}）")
            return item
        except Exception as e:
            logger.error(f"任务从 Redis 队列出队失败：{e}")
            return None
    
    async def peek(self) -> Optional[QueueItem]:
        """查看队首元素"""
        await self.ensure_initialized()
        try:
            members = await self.redis.zrange(
                self.queue_name, 0, 0, withscores=True
            )
            
            if not members:
                return None
            
            task_id, priority_score = members[0]
            task_id = task_id.decode('utf-8') if isinstance(task_id, bytes) else task_id
            
            item_data = await self.redis.hget(f"{self.queue_name}:details", task_id)
            if item_data:
                return QueueItem.from_dict(json.loads(item_data))
            
            return None
        except Exception as e:
            logger.error(f"查看 Redis 队列首元素失败：{e}")
            return None
    
    async def size(self) -> int:
        """队列大小"""
        await self.ensure_initialized()
        try:
            return await self.redis.zcard(self.queue_name)
        except Exception as e:
            logger.error(f"获取 Redis 队列大小失败：{e}")
            return 0
    
    async def clear(self):
        """清空队列"""
        await self.ensure_initialized()
        try:
            await self.redis.delete(self.queue_name)
            await self.redis.delete(f"{self.queue_name}:details")
        except Exception as e:
            logger.error(f"清空 Redis 队列失败：{e}")
    
    async def cancel_task(self, task_id: str) -> bool:
        """取消任务"""
        await self.ensure_initialized()
        try:
            # 从队列中移除
            removed = await self.redis.zrem(self.queue_name, task_id)
            
            # 删除任务详情
            await self.redis.hdel(f"{self.queue_name}:details", task_id)
            
            if removed:
                self.stats["cancelled"] += 1
                logger.info(f"任务 {task_id} 已从 Redis 队列取消")
                return True
            
            return False
        except Exception as e:
            logger.error(f"取消 Redis 队列任务失败：{e}")
            return False


class RabbitMQTaskQueue(BaseTaskQueue):
    """RabbitMQ 任务队列"""

    def __init__(
        self,
        queue_name: str = "default",
        host: str = "localhost",
        port: int = 5672,
        username: str = "guest",
        password: str = "guest",
        virtual_host: str = "/",
    ):
        super().__init__(queue_name)
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.virtual_host = virtual_host
        self._connection = None
        self._channel = None
        self._initialized = False
        self._pending_tasks: Dict[str, QueueItem] = {}

    async def ensure_initialized(self):
        if self._initialized:
            return
        try:
            import aio_pika
            self._connection = await aio_pika.connect_robust(
                host=self.host,
                port=self.port,
                login=self.username,
                password=self.password,
                virtualhost=self.virtual_host,
            )
            self._channel = await self._connection.channel()
            await self._channel.set_qos(prefetch_count=10)
            self._queue = await self._channel.declare_queue(
                self.queue_name, durable=True
            )
            self._initialized = True
            logger.info(f"RabbitMQ 队列初始化成功: {self.queue_name}")
        except ImportError:
            logger.warning("aio_pika 未安装，使用内存队列降级处理")
            self._initialized = True
            self._queue = asyncio.Queue()
        except Exception as e:
            logger.error(f"RabbitMQ 连接失败: {e}")
            raise

    async def enqueue(self, item: QueueItem) -> bool:
        await self.ensure_initialized()
        try:
            import aio_pika
            message = aio_pika.Message(
                body=json.dumps(item.to_dict()).encode(),
                delivery_mode=aio_pika.DeliveryMode.PERSISTENT,
                priority=item.priority.value,
            )
            await self._channel.default_exchange.publish(
                message, routing_key=self.queue_name
            )
            self._pending_tasks[item.task_id] = item
            self.size += 1
            self.stats["enqueued"] += 1
            logger.info(f"任务 {item.task_id} 已入 RabbitMQ 队列")
            return True
        except ImportError:
            await self._queue.put(item)
            self._pending_tasks[item.task_id] = item
            self.size += 1
            self.stats["enqueued"] += 1
            return True
        except Exception as e:
            logger.error(f"RabbitMQ 入队失败: {e}")
            return False

    async def dequeue(self) -> Optional[QueueItem]:
        await self.ensure_initialized()
        try:
            import aio_pika
            message = await self._queue.get(timeout=5)
            async with message.process():
                item_data = json.loads(message.body.decode())
                item = QueueItem.from_dict(item_data)
                item.attempts += 1
                self.size -= 1
                self.stats["dequeued"] += 1
                if item.task_id in self._pending_tasks:
                    del self._pending_tasks[item.task_id]
                logger.info(f"任务 {item.task_id} 已出 RabbitMQ 队列")
                return item
        except ImportError:
            if self._queue.empty():
                return None
            item = await self._queue.get()
            item.attempts += 1
            self.size -= 1
            self.stats["dequeued"] += 1
            return item
        except asyncio.TimeoutError:
            return None
        except Exception as e:
            logger.error(f"RabbitMQ 出队失败: {e}")
            return None

    async def peek(self) -> Optional[QueueItem]:
        await self.ensure_initialized()
        try:
            if not self._pending_tasks:
                return None
            return next(iter(self._pending_tasks.values()))
        except Exception as e:
            logger.error(f"RabbitMQ 查看队首失败: {e}")
            return None

    async def size(self) -> int:
        await self.ensure_initialized()
        try:
            return await self._queue.message_count
        except ImportError:
            return self._queue.qsize()
        except Exception:
            return self.size

    async def clear(self):
        await self.ensure_initialized()
        try:
            import aio_pika
            await self._channel.delete_queue(self.queue_name)
            self._queue = await self._channel.declare_queue(
                self.queue_name, durable=True
            )
            self._pending_tasks.clear()
            self.size = 0
        except ImportError:
            while not self._queue.empty():
                try:
                    self._queue.get_nowait()
                except asyncio.QueueEmpty:
                    break
            self._pending_tasks.clear()
            self.size = 0
        except Exception as e:
            logger.error(f"RabbitMQ 清空队列失败: {e}")

    async def cancel_task(self, task_id: str) -> bool:
        await self.ensure_initialized()
        try:
            if task_id in self._pending_tasks:
                del self._pending_tasks[task_id]
                self.stats["cancelled"] += 1
                logger.info(f"任务 {task_id} 已从 RabbitMQ 队列取消")
                return True
            return False
        except Exception as e:
            logger.error(f"RabbitMQ 取消任务失败: {e}")
            return False

    async def close(self):
        if self._connection:
            await self._connection.close()
            self._initialized = False
            logger.info("RabbitMQ 连接已关闭")


class TaskQueueFactory:
    """任务队列工厂"""
    
    @staticmethod
    def create_queue(queue_type: QueueType, queue_name: str = "default", **kwargs) -> BaseTaskQueue:
        """
        创建任务队列
        
        Args:
            queue_type: 队列类型
            queue_name: 队列名称
            **kwargs: 队列特定参数
            
        Returns:
            任务队列实例
        """
        if queue_type == QueueType.MEMORY:
            return MemoryTaskQueue(queue_name)
        elif queue_type == QueueType.REDIS:
            redis_host = kwargs.get("redis_host", "localhost")
            redis_port = kwargs.get("redis_port", 6379)
            return RedisTaskQueue(queue_name, redis_host, redis_port)
        elif queue_type == QueueType.RABBITMQ:
            host = kwargs.get("host", "localhost")
            port = kwargs.get("port", 5672)
            username = kwargs.get("username", "guest")
            password = kwargs.get("password", "guest")
            virtual_host = kwargs.get("virtual_host", "/")
            return RabbitMQTaskQueue(queue_name, host, port, username, password, virtual_host)
        else:
            raise ValueError(f"不支持的队列类型：{queue_type}")


# ========== 导出符号 ==========

__all__ = [
    "QueueType",
    "TaskPriority",
    "TaskStatus",
    "QueueItem",
    "BaseTaskQueue",
    "MemoryTaskQueue",
    "RedisTaskQueue",
    "RabbitMQTaskQueue",
    "TaskQueueFactory",
]
