"""
MedClaw 工具缓存系统
支持内存缓存（LRU）和 Redis 缓存
"""

import asyncio
import hashlib
import json
import time
from typing import Dict, List, Optional, Any, Callable
from datetime import datetime, timedelta
from collections import OrderedDict
import logging

logger = logging.getLogger(__name__)


class CacheEntry:
    """缓存条目"""
    
    def __init__(self, key: str, value: Any, ttl: Optional[int] = None):
        self.key = key
        self.value = value
        self.created_at = time.time()
        self.ttl = ttl  # 秒，None 表示永不过期
        self.hits = 0
    
    def is_expired(self) -> bool:
        """检查是否过期"""
        if self.ttl is None:
            return False
        return (time.time() - self.created_at) > self.ttl
    
    def touch(self):
        """更新访问时间"""
        self.hits += 1
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "key": self.key,
            "value": self.value,
            "created_at": self.created_at,
            "ttl": self.ttl,
            "hits": self.hits,
        }


class MemoryToolCache:
    """内存工具缓存（LRU 策略）"""
    
    def __init__(
        self,
        max_size: int = 1000,
        default_ttl: Optional[int] = 3600
    ):
        self.max_size = max_size
        self.default_ttl = default_ttl
        self.cache: OrderedDict[str, CacheEntry] = OrderedDict()
        self._lock = asyncio.Lock()
        
        # 统计信息
        self.stats = {
            "hits": 0,
            "misses": 0,
            "evictions": 0,
            "sets": 0,
            "deletes": 0,
        }
    
    def _generate_key(self, tool_name: str, params: Dict[str, Any]) -> str:
        """生成缓存键"""
        # 对参数排序以确保相同参数生成相同键
        params_str = json.dumps(params, sort_keys=True)
        key_str = f"{tool_name}:{params_str}"
        return hashlib.sha256(key_str.encode()).hexdigest()
    
    async def get(self, tool_name: str, params: Dict[str, Any]) -> Optional[Any]:
        """获取缓存"""
        async with self._lock:
            key = self._generate_key(tool_name, params)
            
            if key not in self.cache:
                self.stats["misses"] += 1
                return None
            
            entry = self.cache[key]
            
            # 检查是否过期
            if entry.is_expired():
                del self.cache[key]
                self.stats["evictions"] += 1
                self.stats["misses"] += 1
                return None
            
            # 移动到末尾（最近使用）
            self.cache.move_to_end(key)
            entry.touch()
            self.stats["hits"] += 1
            
            logger.debug(f"缓存命中：{tool_name}")
            return entry.value
    
    async def set(
        self,
        tool_name: str,
        params: Dict[str, Any],
        value: Any,
        ttl: Optional[int] = None
    ):
        """设置缓存"""
        async with self._lock:
            key = self._generate_key(tool_name, params)
            
            # 如果已存在，先删除
            if key in self.cache:
                del self.cache[key]
            
            # 检查是否超出大小限制
            while len(self.cache) >= self.max_size:
                # 删除最旧的条目
                oldest_key = next(iter(self.cache))
                del self.cache[oldest_key]
                self.stats["evictions"] += 1
            
            # 添加新条目
            entry = CacheEntry(key, value, ttl or self.default_ttl)
            self.cache[key] = entry
            self.stats["sets"] += 1
            
            logger.debug(f"缓存设置：{tool_name}")
    
    async def delete(self, tool_name: str, params: Dict[str, Any]):
        """删除缓存"""
        async with self._lock:
            key = self._generate_key(tool_name, params)
            
            if key in self.cache:
                del self.cache[key]
                self.stats["deletes"] += 1
                logger.debug(f"缓存删除：{tool_name}")
    
    async def clear(self):
        """清空缓存"""
        async with self._lock:
            self.cache.clear()
            logger.info("缓存已清空")
    
    async def cleanup_expired(self):
        """清理过期条目"""
        async with self._lock:
            expired_keys = [
                key for key, entry in self.cache.items()
                if entry.is_expired()
            ]
            
            for key in expired_keys:
                del self.cache[key]
                self.stats["evictions"] += 1
            
            if expired_keys:
                logger.info(f"清理了 {len(expired_keys)} 个过期缓存条目")
    
    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        total = self.stats["hits"] + self.stats["misses"]
        hit_rate = (self.stats["hits"] / total * 100) if total > 0 else 0
        
        return {
            **self.stats,
            "size": len(self.cache),
            "max_size": self.max_size,
            "hit_rate": f"{hit_rate:.2f}%",
        }


class RedisToolCache:
    """Redis 工具缓存（可选）"""
    
    def __init__(
        self,
        redis_host: str = "localhost",
        redis_port: int = 6379,
        redis_db: int = 0,
        key_prefix: str = "medclaw:tool_cache:",
        default_ttl: Optional[int] = 3600
    ):
        self.redis_host = redis_host
        self.redis_port = redis_port
        self.redis_db = redis_db
        self.key_prefix = key_prefix
        self.default_ttl = default_ttl
        self.redis = None
        self._initialized = False
        
        self.stats = {
            "hits": 0,
            "misses": 0,
            "sets": 0,
            "deletes": 0,
            "errors": 0,
        }
    
    async def initialize(self):
        """初始化 Redis 连接"""
        try:
            import aioredis
            self.redis = await aioredis.from_url(
                f"redis://{self.redis_host}:{self.redis_port}/{self.redis_db}"
            )
            self._initialized = True
            logger.info(f"Redis 缓存已初始化：{self.redis_host}:{self.redis_port}")
        except ImportError:
            logger.error("需要安装 aioredis: pip install aioredis")
            raise
        except Exception as e:
            logger.error(f"Redis 缓存初始化失败：{e}")
            raise
    
    async def ensure_initialized(self):
        """确保已初始化"""
        if not self._initialized:
            await self.initialize()
    
    def _generate_key(self, tool_name: str, params: Dict[str, Any]) -> str:
        """生成缓存键"""
        params_str = json.dumps(params, sort_keys=True)
        key_str = f"{tool_name}:{params_str}"
        hash_key = hashlib.sha256(key_str.encode()).hexdigest()
        return f"{self.key_prefix}{hash_key}"
    
    async def get(self, tool_name: str, params: Dict[str, Any]) -> Optional[Any]:
        """获取缓存"""
        await self.ensure_initialized()
        
        try:
            key = self._generate_key(tool_name, params)
            value = await self.redis.get(key)
            
            if value is None:
                self.stats["misses"] += 1
                return None
            
            self.stats["hits"] += 1
            logger.debug(f"Redis 缓存命中：{tool_name}")
            return json.loads(value)
            
        except Exception as e:
            self.stats["errors"] += 1
            logger.error(f"Redis 缓存获取失败：{e}")
            return None
    
    async def set(
        self,
        tool_name: str,
        params: Dict[str, Any],
        value: Any,
        ttl: Optional[int] = None
    ):
        """设置缓存"""
        await self.ensure_initialized()
        
        try:
            key = self._generate_key(tool_name, params)
            ttl = ttl or self.default_ttl
            
            value_str = json.dumps(value)
            
            if ttl:
                await self.redis.setex(key, ttl, value_str)
            else:
                await self.redis.set(key, value_str)
            
            self.stats["sets"] += 1
            logger.debug(f"Redis 缓存设置：{tool_name}")
            
        except Exception as e:
            self.stats["errors"] += 1
            logger.error(f"Redis 缓存设置失败：{e}")
    
    async def delete(self, tool_name: str, params: Dict[str, Any]):
        """删除缓存"""
        await self.ensure_initialized()
        
        try:
            key = self._generate_key(tool_name, params)
            await self.redis.delete(key)
            self.stats["deletes"] += 1
            logger.debug(f"Redis 缓存删除：{tool_name}")
            
        except Exception as e:
            self.stats["errors"] += 1
            logger.error(f"Redis 缓存删除失败：{e}")
    
    async def clear(self):
        """清空缓存"""
        await self.ensure_initialized()
        
        try:
            # 删除所有带前缀的键
            keys = await self.redis.keys(f"{self.key_prefix}*")
            if keys:
                await self.redis.delete(*keys)
            logger.info("Redis 缓存已清空")
            
        except Exception as e:
            self.stats["errors"] += 1
            logger.error(f"Redis 缓存清空失败：{e}")
    
    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        total = self.stats["hits"] + self.stats["misses"]
        hit_rate = (self.stats["hits"] / total * 100) if total > 0 else 0
        
        return {
            **self.stats,
            "type": "redis",
            "hit_rate": f"{hit_rate:.2f}%",
        }


class ToolCacheFactory:
    """工具缓存工厂"""
    
    @staticmethod
    def create_cache(
        cache_type: str = "memory",
        **kwargs
    ) -> MemoryToolCache | RedisToolCache:
        """
        创建缓存实例
        
        Args:
            cache_type: 缓存类型 ("memory" 或 "redis")
            **kwargs: 缓存特定参数
            
        Returns:
            缓存实例
        """
        if cache_type == "memory":
            max_size = kwargs.get("max_size", 1000)
            default_ttl = kwargs.get("default_ttl", 3600)
            return MemoryToolCache(max_size, default_ttl)
        
        elif cache_type == "redis":
            redis_host = kwargs.get("redis_host", "localhost")
            redis_port = kwargs.get("redis_port", 6379)
            redis_db = kwargs.get("redis_db", 0)
            key_prefix = kwargs.get("key_prefix", "medclaw:tool_cache:")
            default_ttl = kwargs.get("default_ttl", 3600)
            return RedisToolCache(
                redis_host, redis_port, redis_db, key_prefix, default_ttl
            )
        
        else:
            raise ValueError(f"不支持的缓存类型：{cache_type}")


# ========== 导出符号 ==========

__all__ = [
    "CacheEntry",
    "MemoryToolCache",
    "RedisToolCache",
    "ToolCacheFactory",
]
