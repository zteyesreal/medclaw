"""
模块基类
所有功能模块的父类
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional
from .mcp_client import MCPClient


class ModuleBase(ABC):
    """模块基类"""
    
    def __init__(self, name: str, config: Optional[Dict[str, Any]] = None, mcp_client: Optional[MCPClient] = None):
        """
        初始化模块
        
        Args:
            name: 模块名称
            config: 模块配置
            mcp_client: MCP 客户端
        """
        self.name = name
        self.config = config or {}
        self.mcp_client = mcp_client
    
    @abstractmethod
    async def execute(self, **kwargs) -> Any:
        """
        执行模块功能
        
        Args:
            **kwargs: 输入参数
            
        Returns:
            执行结果
        """
        pass
    
    def validate_input(self, data: Dict[str, Any]) -> bool:
        """
        验证输入数据
        
        Args:
            data: 输入数据
            
        Returns:
            是否有效
        """
        return True
    
    def format_output(self, result: Any) -> str:
        """
        格式化输出
        
        Args:
            result: 执行结果
            
        Returns:
            格式化后的字符串
        """
        if isinstance(result, dict):
            import json
            return json.dumps(result, ensure_ascii=False, indent=2)
        return str(result)
