"""
MedClaw 医疗专用 Web UI
基于 FastAPI + Vue.js 的医疗功能可视化界面

模块说明:
- medical_ui_models.py: 数据模型定义
- medical_ui_websocket.py: WebSocket 连接管理
- medical_ui_routes.py: API 路由实现（已拆分为多个模块）
- medical_ui_templates.py: HTML 模板（已拆分为样式和脚本）
"""

from fastapi import FastAPI
from fastapi.responses import HTMLResponse

from .config_api import router as config_router
from .medical_ui_routes import router as medical_router
from .medical_ui_templates import get_enhanced_medical_html_template
from .settings import router as settings_router
from .module_config_api import router as module_config_router

app = FastAPI(title="MedClaw 医疗专用界面")

# 注册设置管理路由
app.include_router(settings_router)

# 注册模块配置路由
app.include_router(module_config_router)

# 注册配置管理路由
app.include_router(config_router)

# 注册医疗模块路由
app.include_router(medical_router)


@app.get("/", response_class=HTMLResponse)
async def get_medical_index():
    """获取医疗专用界面首页"""
    return get_enhanced_medical_html_template()
