"""
MedClaw 任务状态持久化
支持 SQLite、MySQL、PostgreSQL
"""

import asyncio
import json
from typing import Dict, List, Optional, Any, Union
from datetime import datetime
import logging
import uuid

logger = logging.getLogger(__name__)


class TaskRecord:
    """任务记录"""
    
    def __init__(
        self,
        task_id: str,
        task_type: str,
        task_data: Dict[str, Any],
        status: str = "pending",
        priority: int = 5,
        result: Optional[Any] = None,
        error: Optional[str] = None,
        created_at: Optional[datetime] = None,
        updated_at: Optional[datetime] = None,
        started_at: Optional[datetime] = None,
        completed_at: Optional[datetime] = None,
        worker_id: Optional[str] = None,
        retry_count: int = 0,
        max_retries: int = 3,
        timeout: int = 300,
        metadata: Optional[Dict[str, Any]] = None,
    ):
        self.task_id = task_id
        self.task_type = task_type
        self.task_data = task_data
        self.status = status
        self.priority = priority
        self.result = result
        self.error = error
        self.created_at = created_at or datetime.now()
        self.updated_at = updated_at or datetime.now()
        self.started_at = started_at
        self.completed_at = completed_at
        self.worker_id = worker_id
        self.retry_count = retry_count
        self.max_retries = max_retries
        self.timeout = timeout
        self.metadata = metadata or {}
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "task_id": self.task_id,
            "task_type": self.task_type,
            "task_data": self.task_data,
            "status": self.status,
            "priority": self.priority,
            "result": self.result,
            "error": self.error,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "worker_id": self.worker_id,
            "retry_count": self.retry_count,
            "max_retries": self.max_retries,
            "timeout": self.timeout,
            "metadata": self.metadata,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TaskRecord":
        return cls(
            task_id=data["task_id"],
            task_type=data["task_type"],
            task_data=data.get("task_data", {}),
            status=data.get("status", "pending"),
            priority=data.get("priority", 5),
            result=data.get("result"),
            error=data.get("error"),
            created_at=datetime.fromisoformat(data["created_at"]) if data.get("created_at") else None,
            updated_at=datetime.fromisoformat(data["updated_at"]) if data.get("updated_at") else None,
            started_at=datetime.fromisoformat(data["started_at"]) if data.get("started_at") else None,
            completed_at=datetime.fromisoformat(data["completed_at"]) if data.get("completed_at") else None,
            worker_id=data.get("worker_id"),
            retry_count=data.get("retry_count", 0),
            max_retries=data.get("max_retries", 3),
            timeout=data.get("timeout", 300),
            metadata=data.get("metadata", {}),
        )


class TaskHistoryRecord:
    """任务历史记录"""
    
    def __init__(
        self,
        history_id: str,
        task_id: str,
        old_status: str,
        new_status: str,
        changed_at: datetime,
        reason: Optional[str] = None,
        operator: Optional[str] = None,
    ):
        self.history_id = history_id
        self.task_id = task_id
        self.old_status = old_status
        self.new_status = new_status
        self.changed_at = changed_at
        self.reason = reason
        self.operator = operator
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "history_id": self.history_id,
            "task_id": self.task_id,
            "old_status": self.old_status,
            "new_status": self.new_status,
            "changed_at": self.changed_at.isoformat(),
            "reason": self.reason,
            "operator": self.operator,
        }


class BaseTaskStorage:
    """任务存储基类"""
    
    async def initialize(self):
        """初始化"""
        raise NotImplementedError
    
    async def save_task(self, task: TaskRecord) -> bool:
        """保存任务"""
        raise NotImplementedError
    
    async def update_task(self, task_id: str, updates: Dict[str, Any]) -> bool:
        """更新任务"""
        raise NotImplementedError
    
    async def get_task(self, task_id: str) -> Optional[TaskRecord]:
        """获取任务"""
        raise NotImplementedError
    
    async def delete_task(self, task_id: str) -> bool:
        """删除任务"""
        raise NotImplementedError
    
    async def query_tasks(
        self,
        status: Optional[str] = None,
        task_type: Optional[str] = None,
        worker_id: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[TaskRecord]:
        """查询任务"""
        raise NotImplementedError
    
    async def save_history(self, history: TaskHistoryRecord) -> bool:
        """保存历史记录"""
        raise NotImplementedError
    
    async def get_history(self, task_id: str, limit: int = 50) -> List[TaskHistoryRecord]:
        """获取任务历史"""
        raise NotImplementedError
    
    async def cleanup(self):
        """清理资源"""
        raise NotImplementedError


class SQLiteTaskStorage(BaseTaskStorage):
    """SQLite 任务存储"""
    
    def __init__(self, db_path: str = "medclaw.db"):
        self.db_path = db_path
        self._conn = None
        self._initialized = False
    
    async def initialize(self):
        """初始化数据库"""
        try:
            import aiosqlite
            
            self._conn = await aiosqlite.connect(self.db_path)
            self._conn.row_factory = aiosqlite.Row
            
            # 创建任务表
            await self._conn.execute("""
                CREATE TABLE IF NOT EXISTS tasks (
                    task_id TEXT PRIMARY KEY,
                    task_type TEXT NOT NULL,
                    task_data TEXT,
                    status TEXT DEFAULT 'pending',
                    priority INTEGER DEFAULT 5,
                    result TEXT,
                    error TEXT,
                    created_at TEXT,
                    updated_at TEXT,
                    started_at TEXT,
                    completed_at TEXT,
                    worker_id TEXT,
                    retry_count INTEGER DEFAULT 0,
                    max_retries INTEGER DEFAULT 3,
                    timeout INTEGER DEFAULT 300,
                    metadata TEXT
                )
            """)
            
            # 创建历史表
            await self._conn.execute("""
                CREATE TABLE IF NOT EXISTS task_history (
                    history_id TEXT PRIMARY KEY,
                    task_id TEXT NOT NULL,
                    old_status TEXT,
                    new_status TEXT NOT NULL,
                    changed_at TEXT,
                    reason TEXT,
                    operator TEXT,
                    FOREIGN KEY (task_id) REFERENCES tasks(task_id)
                )
            """)
            
            # 创建索引
            await self._conn.execute("CREATE INDEX IF NOT EXISTS idx_status ON tasks(status)")
            await self._conn.execute("CREATE INDEX IF NOT EXISTS idx_type ON tasks(task_type)")
            await self._conn.execute("CREATE INDEX IF NOT EXISTS idx_worker ON tasks(worker_id)")
            await self._conn.execute("CREATE INDEX IF NOT EXISTS idx_history_task ON task_history(task_id)")
            
            await self._conn.commit()
            self._initialized = True
            
            logger.info(f"SQLite 任务存储已初始化：{self.db_path}")
            
        except ImportError:
            logger.error("需要安装 aiosqlite: pip install aiosqlite")
            raise
        except Exception as e:
            logger.error(f"SQLite 初始化失败：{e}")
            raise
    
    async def save_task(self, task: TaskRecord) -> bool:
        """保存任务"""
        await self.ensure_initialized()
        try:
            await self._conn.execute("""
                INSERT OR REPLACE INTO tasks (
                    task_id, task_type, task_data, status, priority,
                    result, error, created_at, updated_at, started_at,
                    completed_at, worker_id, retry_count, max_retries,
                    timeout, metadata
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                task.task_id,
                task.task_type,
                json.dumps(task.task_data),
                task.status,
                task.priority,
                json.dumps(task.result) if task.result is not None else None,
                task.error,
                task.created_at.isoformat() if task.created_at else None,
                task.updated_at.isoformat() if task.updated_at else None,
                task.started_at.isoformat() if task.started_at else None,
                task.completed_at.isoformat() if task.completed_at else None,
                task.worker_id,
                task.retry_count,
                task.max_retries,
                task.timeout,
                json.dumps(task.metadata),
            ))
            await self._conn.commit()
            return True
        except Exception as e:
            logger.error(f"保存任务失败：{e}")
            return False
    
    async def update_task(self, task_id: str, updates: Dict[str, Any]) -> bool:
        """更新任务"""
        await self.ensure_initialized()
        try:
            # 构建更新语句
            set_clauses = []
            values = []
            
            for key, value in updates.items():
                if key in ['task_data', 'result', 'metadata'] and isinstance(value, (dict, list)):
                    set_clauses.append(f"{key} = ?")
                    values.append(json.dumps(value))
                elif key in ['created_at', 'updated_at', 'started_at', 'completed_at']:
                    set_clauses.append(f"{key} = ?")
                    values.append(value.isoformat() if isinstance(value, datetime) else value)
                elif key != 'task_id':  # 跳过 task_id
                    set_clauses.append(f"{key} = ?")
                    values.append(value)
            
            if not set_clauses:
                return False
            
            values.append(task_id)
            
            await self._conn.execute(f"""
                UPDATE tasks SET {', '.join(set_clauses)} WHERE task_id = ?
            """, values)
            
            await self._conn.commit()
            return True
        except Exception as e:
            logger.error(f"更新任务失败：{e}")
            return False
    
    async def get_task(self, task_id: str) -> Optional[TaskRecord]:
        """获取任务"""
        await self.ensure_initialized()
        try:
            cursor = await self._conn.execute(
                "SELECT * FROM tasks WHERE task_id = ?",
                (task_id,)
            )
            row = await cursor.fetchone()
            
            if row:
                return self._row_to_task(row)
            return None
        except Exception as e:
            logger.error(f"获取任务失败：{e}")
            return None
    
    async def delete_task(self, task_id: str) -> bool:
        """删除任务"""
        await self.ensure_initialized()
        try:
            await self._conn.execute(
                "DELETE FROM tasks WHERE task_id = ?",
                (task_id,)
            )
            await self._conn.commit()
            return True
        except Exception as e:
            logger.error(f"删除任务失败：{e}")
            return False
    
    async def query_tasks(
        self,
        status: Optional[str] = None,
        task_type: Optional[str] = None,
        worker_id: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[TaskRecord]:
        """查询任务"""
        await self.ensure_initialized()
        try:
            query = "SELECT * FROM tasks WHERE 1=1"
            params = []
            
            if status:
                query += " AND status = ?"
                params.append(status)
            
            if task_type:
                query += " AND task_type = ?"
                params.append(task_type)
            
            if worker_id:
                query += " AND worker_id = ?"
                params.append(worker_id)
            
            query += " ORDER BY priority DESC, created_at ASC LIMIT ? OFFSET ?"
            params.extend([limit, offset])
            
            cursor = await self._conn.execute(query, params)
            rows = await cursor.fetchall()
            
            return [self._row_to_task(row) for row in rows]
        except Exception as e:
            logger.error(f"查询任务失败：{e}")
            return []
    
    async def save_history(self, history: TaskHistoryRecord) -> bool:
        """保存历史记录"""
        await self.ensure_initialized()
        try:
            await self._conn.execute("""
                INSERT INTO task_history (
                    history_id, task_id, old_status, new_status,
                    changed_at, reason, operator
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                history.history_id,
                history.task_id,
                history.old_status,
                history.new_status,
                history.changed_at.isoformat(),
                history.reason,
                history.operator,
            ))
            await self._conn.commit()
            return True
        except Exception as e:
            logger.error(f"保存历史失败：{e}")
            return False
    
    async def get_history(self, task_id: str, limit: int = 50) -> List[TaskHistoryRecord]:
        """获取任务历史"""
        await self.ensure_initialized()
        try:
            cursor = await self._conn.execute(
                """
                SELECT * FROM task_history 
                WHERE task_id = ? 
                ORDER BY changed_at DESC 
                LIMIT ?
                """,
                (task_id, limit)
            )
            rows = await cursor.fetchall()
            
            return [self._row_to_history(row) for row in rows]
        except Exception as e:
            logger.error(f"获取历史失败：{e}")
            return []
    
    async def cleanup(self):
        """清理资源"""
        if self._conn:
            await self._conn.close()
            logger.info("SQLite 连接已关闭")
    
    async def ensure_initialized(self):
        """确保已初始化"""
        if not self._initialized:
            await self.initialize()
    
    def _row_to_task(self, row) -> TaskRecord:
        """将数据库行转换为 TaskRecord"""
        return TaskRecord(
            task_id=row["task_id"],
            task_type=row["task_type"],
            task_data=json.loads(row["task_data"]) if row["task_data"] else {},
            status=row["status"],
            priority=row["priority"],
            result=json.loads(row["result"]) if row["result"] else None,
            error=row["error"],
            created_at=datetime.fromisoformat(row["created_at"]) if row["created_at"] else None,
            updated_at=datetime.fromisoformat(row["updated_at"]) if row["updated_at"] else None,
            started_at=datetime.fromisoformat(row["started_at"]) if row["started_at"] else None,
            completed_at=datetime.fromisoformat(row["completed_at"]) if row["completed_at"] else None,
            worker_id=row["worker_id"],
            retry_count=row["retry_count"],
            max_retries=row["max_retries"],
            timeout=row["timeout"],
            metadata=json.loads(row["metadata"]) if row["metadata"] else {},
        )
    
    def _row_to_history(self, row) -> TaskHistoryRecord:
        """将数据库行转换为 TaskHistoryRecord"""
        return TaskHistoryRecord(
            history_id=row["history_id"],
            task_id=row["task_id"],
            old_status=row["old_status"],
            new_status=row["new_status"],
            changed_at=datetime.fromisoformat(row["changed_at"]),
            reason=row["reason"],
            operator=row["operator"],
        )


class MySQLTaskStorage(BaseTaskStorage):
    """MySQL 任务存储"""
    
    def __init__(
        self,
        host: str = "localhost",
        port: int = 3306,
        database: str = "medclaw",
        user: str = "root",
        password: str = "",
    ):
        self.host = host
        self.port = port
        self.database = database
        self.user = user
        self.password = password
        self._pool = None
        self._initialized = False
    
    async def initialize(self):
        """初始化连接池"""
        try:
            import aiomysql
            
            self._pool = await aiomysql.create_pool(
                host=self.host,
                port=self.port,
                user=self.user,
                password=self.password,
                db=self.database,
                minsize=1,
                maxsize=10,
                autocommit=True,
            )
            
            # 创建表
            async with self._pool.acquire() as conn:
                await self._create_tables(conn)
            
            self._initialized = True
            logger.info(f"MySQL 任务存储已初始化：{self.database}")
            
        except ImportError:
            logger.error("需要安装 aiomysql: pip install aiomysql")
            raise
        except Exception as e:
            logger.error(f"MySQL 初始化失败：{e}")
            raise
    
    async def _create_tables(self, conn):
        """创建表"""
        async with conn.cursor() as cur:
            # 创建任务表
            await cur.execute("""
                CREATE TABLE IF NOT EXISTS tasks (
                    task_id VARCHAR(255) PRIMARY KEY,
                    task_type VARCHAR(100) NOT NULL,
                    task_data JSON,
                    status VARCHAR(50) DEFAULT 'pending',
                    priority INT DEFAULT 5,
                    result JSON,
                    error TEXT,
                    created_at DATETIME,
                    updated_at DATETIME,
                    started_at DATETIME,
                    completed_at DATETIME,
                    worker_id VARCHAR(255),
                    retry_count INT DEFAULT 0,
                    max_retries INT DEFAULT 3,
                    timeout INT DEFAULT 300,
                    metadata JSON,
                    INDEX idx_status (status),
                    INDEX idx_type (task_type),
                    INDEX idx_worker (worker_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
            
            # 创建历史表
            await cur.execute("""
                CREATE TABLE IF NOT EXISTS task_history (
                    history_id VARCHAR(255) PRIMARY KEY,
                    task_id VARCHAR(255) NOT NULL,
                    old_status VARCHAR(50),
                    new_status VARCHAR(50) NOT NULL,
                    changed_at DATETIME,
                    reason TEXT,
                    operator VARCHAR(255),
                    FOREIGN KEY (task_id) REFERENCES tasks(task_id),
                    INDEX idx_history_task (task_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
    
    async def save_task(self, task: TaskRecord) -> bool:
        """保存任务"""
        await self.ensure_initialized()
        try:
            async with self._pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute("""
                        INSERT INTO tasks (
                            task_id, task_type, task_data, status, priority,
                            result, error, created_at, updated_at, started_at,
                            completed_at, worker_id, retry_count, max_retries,
                            timeout, metadata
                        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                        ON DUPLICATE KEY UPDATE
                            task_data=VALUES(task_data),
                            status=VALUES(status),
                            priority=VALUES(priority),
                            result=VALUES(result),
                            error=VALUES(error),
                            updated_at=VALUES(updated_at),
                            started_at=VALUES(started_at),
                            completed_at=VALUES(completed_at),
                            worker_id=VALUES(worker_id),
                            retry_count=VALUES(retry_count),
                            metadata=VALUES(metadata)
                    """, (
                        task.task_id,
                        task.task_type,
                        json.dumps(task.task_data),
                        task.status,
                        task.priority,
                        json.dumps(task.result) if task.result is not None else None,
                        task.error,
                        task.created_at.isoformat() if task.created_at else None,
                        task.updated_at.isoformat() if task.updated_at else None,
                        task.started_at.isoformat() if task.started_at else None,
                        task.completed_at.isoformat() if task.completed_at else None,
                        task.worker_id,
                        task.retry_count,
                        task.max_retries,
                        task.timeout,
                        json.dumps(task.metadata),
                    ))
            return True
        except Exception as e:
            logger.error(f"保存任务失败：{e}")
            return False
    
    async def update_task(self, task_id: str, updates: Dict[str, Any]) -> bool:
        """更新任务"""
        await self.ensure_initialized()
        try:
            set_clauses = []
            values = []
            
            for key, value in updates.items():
                if key in ['task_data', 'result', 'metadata'] and isinstance(value, (dict, list)):
                    set_clauses.append(f"{key} = %s")
                    values.append(json.dumps(value))
                elif key in ['created_at', 'updated_at', 'started_at', 'completed_at']:
                    set_clauses.append(f"{key} = %s")
                    values.append(value.isoformat() if isinstance(value, datetime) else value)
                elif key != 'task_id':
                    set_clauses.append(f"{key} = %s")
                    values.append(value)
            
            if not set_clauses:
                return False
            
            values.append(task_id)
            
            async with self._pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute(f"""
                        UPDATE tasks SET {', '.join(set_clauses)} WHERE task_id = %s
                    """, values)
            return True
        except Exception as e:
            logger.error(f"更新任务失败：{e}")
            return False
    
    async def get_task(self, task_id: str) -> Optional[TaskRecord]:
        """获取任务"""
        await self.ensure_initialized()
        try:
            async with self._pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute(
                        "SELECT * FROM tasks WHERE task_id = %s",
                        (task_id,)
                    )
                    row = await cur.fetchone()
                    
                    if row:
                        return self._row_to_task(row)
                    return None
        except Exception as e:
            logger.error(f"获取任务失败：{e}")
            return None
    
    async def delete_task(self, task_id: str) -> bool:
        """删除任务"""
        await self.ensure_initialized()
        try:
            async with self._pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute(
                        "DELETE FROM tasks WHERE task_id = %s",
                        (task_id,)
                    )
            return True
        except Exception as e:
            logger.error(f"删除任务失败：{e}")
            return False
    
    async def query_tasks(
        self,
        status: Optional[str] = None,
        task_type: Optional[str] = None,
        worker_id: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[TaskRecord]:
        """查询任务"""
        await self.ensure_initialized()
        try:
            query = "SELECT * FROM tasks WHERE 1=1"
            params = []
            
            if status:
                query += " AND status = %s"
                params.append(status)
            
            if task_type:
                query += " AND task_type = %s"
                params.append(task_type)
            
            if worker_id:
                query += " AND worker_id = %s"
                params.append(worker_id)
            
            query += " ORDER BY priority DESC, created_at ASC LIMIT %s OFFSET %s"
            params.extend([limit, offset])
            
            async with self._pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute(query, params)
                    rows = await cur.fetchall()
                    
                    return [self._row_to_task(row) for row in rows]
        except Exception as e:
            logger.error(f"查询任务失败：{e}")
            return []
    
    async def save_history(self, history: TaskHistoryRecord) -> bool:
        """保存历史记录"""
        await self.ensure_initialized()
        try:
            async with self._pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute("""
                        INSERT INTO task_history (
                            history_id, task_id, old_status, new_status,
                            changed_at, reason, operator
                        ) VALUES (%s, %s, %s, %s, %s, %s, %s)
                    """, (
                        history.history_id,
                        history.task_id,
                        history.old_status,
                        history.new_status,
                        history.changed_at.isoformat(),
                        history.reason,
                        history.operator,
                    ))
            return True
        except Exception as e:
            logger.error(f"保存历史失败：{e}")
            return False
    
    async def get_history(self, task_id: str, limit: int = 50) -> List[TaskHistoryRecord]:
        """获取任务历史"""
        await self.ensure_initialized()
        try:
            async with self._pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute(
                        """
                        SELECT * FROM task_history 
                        WHERE task_id = %s 
                        ORDER BY changed_at DESC 
                        LIMIT %s
                        """,
                        (task_id, limit)
                    )
                    rows = await cur.fetchall()
                    
                    return [self._row_to_history(row) for row in rows]
        except Exception as e:
            logger.error(f"获取历史失败：{e}")
            return []
    
    async def cleanup(self):
        """清理资源"""
        if self._pool:
            self._pool.close()
            await self._pool.wait_closed()
            logger.info("MySQL 连接池已关闭")
    
    async def ensure_initialized(self):
        """确保已初始化"""
        if not self._initialized:
            await self.initialize()
    
    def _row_to_task(self, row) -> TaskRecord:
        """将数据库行转换为 TaskRecord"""
        return TaskRecord(
            task_id=row["task_id"],
            task_type=row["task_type"],
            task_data=json.loads(row["task_data"]) if row["task_data"] else {},
            status=row["status"],
            priority=row["priority"],
            result=json.loads(row["result"]) if row["result"] else None,
            error=row["error"],
            created_at=datetime.fromisoformat(row["created_at"]) if row["created_at"] else None,
            updated_at=datetime.fromisoformat(row["updated_at"]) if row["updated_at"] else None,
            started_at=datetime.fromisoformat(row["started_at"]) if row["started_at"] else None,
            completed_at=datetime.fromisoformat(row["completed_at"]) if row["completed_at"] else None,
            worker_id=row["worker_id"],
            retry_count=row["retry_count"],
            max_retries=row["max_retries"],
            timeout=row["timeout"],
            metadata=json.loads(row["metadata"]) if row["metadata"] else {},
        )
    
    def _row_to_history(self, row) -> TaskHistoryRecord:
        """将数据库行转换为 TaskHistoryRecord"""
        return TaskHistoryRecord(
            history_id=row["history_id"],
            task_id=row["task_id"],
            old_status=row["old_status"],
            new_status=row["new_status"],
            changed_at=datetime.fromisoformat(row["changed_at"]),
            reason=row["reason"],
            operator=row["operator"],
        )


class TaskStorageFactory:
    """任务存储工厂"""
    
    @staticmethod
    def create_storage(storage_type: str, **kwargs) -> BaseTaskStorage:
        """
        创建任务存储
        
        Args:
            storage_type: 存储类型 ("sqlite", "mysql", "postgresql")
            **kwargs: 存储特定参数
            
        Returns:
            任务存储实例
        """
        if storage_type == "sqlite":
            db_path = kwargs.get("db_path", "medclaw.db")
            return SQLiteTaskStorage(db_path)
        elif storage_type == "mysql":
            return MySQLTaskStorage(
                host=kwargs.get("host", "localhost"),
                port=kwargs.get("port", 3306),
                database=kwargs.get("database", "medclaw"),
                user=kwargs.get("user", "root"),
                password=kwargs.get("password", ""),
            )
        elif storage_type == "postgresql":
            # PostgreSQL 实现类似，这里简化
            raise NotImplementedError("PostgreSQL 存储暂未实现")
        else:
            raise ValueError(f"不支持的存储类型：{storage_type}")


# ========== 导出符号 ==========

__all__ = [
    "TaskRecord",
    "TaskHistoryRecord",
    "BaseTaskStorage",
    "SQLiteTaskStorage",
    "MySQLTaskStorage",
    "TaskStorageFactory",
]
