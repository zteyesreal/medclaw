"""
MedClaw 工具权限管理
基于角色的访问控制（RBAC）
"""

from typing import Dict, List, Optional, Any, Set
from enum import Enum
import logging

logger = logging.getLogger(__name__)


class ToolRole(str, Enum):
    """工具角色"""
    ADMIN = "admin"
    USER = "user"
    GUEST = "guest"
    SYSTEM = "system"


class ToolPermissionManager:
    """工具权限管理器"""
    
    def __init__(self):
        # 角色 - 工具映射
        self.role_tools: Dict[ToolRole, Set[str]] = {
            ToolRole.ADMIN: set(),  # admin 默认可以访问所有工具
            ToolRole.USER: set(),
            ToolRole.GUEST: set(),
            ToolRole.SYSTEM: set(),
        }
        
        # 用户 - 角色映射
        self.user_roles: Dict[str, ToolRole] = {}
        
        # 默认角色
        self.default_role = ToolRole.GUEST
        
        # 统计信息
        self.stats = {
            "checks": 0,
            "allowed": 0,
            "denied": 0,
        }
        
        logger.info("工具权限管理器已初始化")
    
    async def initialize(self):
        """初始化"""
        # 可以在这里加载配置文件或数据库
        logger.info("权限管理器初始化完成")
    
    def set_role_tools(self, role: ToolRole, tool_names: List[str]):
        """设置角色可访问的工具"""
        self.role_tools[role] = set(tool_names)
        logger.info(f"已设置角色 {role.value} 的工具权限：{tool_names}")
    
    def add_user_role(self, user_id: str, role: ToolRole):
        """为用户分配角色"""
        self.user_roles[user_id] = role
        logger.info(f"用户 {user_id} 已分配角色 {role.value}")
    
    def get_user_role(self, user_id: str) -> ToolRole:
        """获取用户角色"""
        return self.user_roles.get(user_id, self.default_role)
    
    async def has_permission(
        self,
        user_id: str,
        tool_name: str
    ) -> bool:
        """
        检查用户是否有权限调用工具
        
        Args:
            user_id: 用户 ID
            tool_name: 工具名称
            
        Returns:
            是否有权限
        """
        self.stats["checks"] += 1
        
        role = self.get_user_role(user_id)
        
        # Admin 可以访问所有工具
        if role == ToolRole.ADMIN:
            self.stats["allowed"] += 1
            return True
        
        # System 可以访问所有工具
        if role == ToolRole.SYSTEM:
            self.stats["allowed"] += 1
            return True
        
        # 检查角色是否有该工具的权限
        allowed_tools = self.role_tools.get(role, set())
        
        # 如果角色权限为空，默认允许（白名单模式）
        # 如果需要黑名单模式，可以在这里修改逻辑
        if not allowed_tools:
            self.stats["allowed"] += 1
            return True
        
        has_access = tool_name in allowed_tools
        
        if has_access:
            self.stats["allowed"] += 1
        else:
            self.stats["denied"] += 1
        
        return has_access
    
    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        return self.stats.copy()


# ========== 导出符号 ==========

__all__ = [
    "ToolRole",
    "ToolPermissionManager",
]
