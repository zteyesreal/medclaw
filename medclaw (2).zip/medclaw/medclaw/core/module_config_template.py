"""
模块配置页面模板
"""

def get_module_config_page_template():
    """获取模块配置页面 HTML"""
    return """<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MedClaw - 模块配置中心</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>
</head>
<body class="bg-gray-100">
    <div id="app" class="min-h-screen">
        <!-- 顶部导航 -->
        <nav class="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-4 shadow-lg">
            <div class="container mx-auto flex justify-between items-center">
                <h1 class="text-2xl font-bold">
                    <i class="fas fa-cogs mr-2"></i>MedClaw 模块配置中心
                </h1>
                <div class="flex space-x-4">
                    <a href="/" class="text-white hover:text-gray-200">
                        <i class="fas fa-home mr-1"></i>返回首页
                    </a>
                    <a href="/api/settings/page" target="_blank" class="text-white hover:text-gray-200">
                        <i class="fas fa-sliders-h mr-1"></i>统一设置
                    </a>
                </div>
            </div>
        </nav>

        <div class="container mx-auto p-6">
            <!-- 模块选择 -->
            <div class="bg-white rounded-lg shadow-md p-4 mb-6">
                <h2 class="text-xl font-bold mb-4">选择要配置的模块</h2>
                <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4">
                    <button v-for="module in modules" :key="module.id"
                            @click="selectModule(module.id)"
                            :class="['p-4 rounded-lg border-2 transition-all', 
                                     selectedModule === module.id ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300']">
                        <div class="text-3xl mb-2">{{ module.icon }}</div>
                        <div class="font-semibold text-gray-800">{{ module.name }}</div>
                    </button>
                </div>
            </div>

            <!-- 配置表单区域 -->
            <div v-if="selectedModule" class="bg-white rounded-lg shadow-md p-6">
                <div class="flex justify-between items-center mb-6">
                    <h2 class="text-2xl font-bold text-gray-800">
                        {{ modules.find(m => m.id === selectedModule)?.icon }} 
                        {{ modules.find(m => m.id === selectedModule)?.name }} 配置
                    </h2>
                    <div class="space-x-2">
                        <button @click="loadConfig" class="px-4 py-2 bg-gray-600 text-white rounded hover:bg-gray-700">
                            <i class="fas fa-redo mr-2"></i>重新加载
                        </button>
                        <button @click="saveConfig" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
                            <i class="fas fa-save mr-2"></i>保存配置
                        </button>
                    </div>
                </div>

                <!-- EMR 模块配置 -->
                <div v-if="selectedModule === 'emr_generation'" class="space-y-6">
                    <!-- HIS 系统对接 -->
                    <section class="border rounded-lg p-4">
                        <h3 class="text-lg font-bold text-blue-600 mb-4">
                            <i class="fas fa-hospital mr-2"></i>HIS 系统对接
                        </h3>
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-gray-700 mb-2">启用 HIS 对接</label>
                                <input type="checkbox" v-model="config.his_enabled" class="mr-2">
                            </div>
                            <div>
                                <label class="block text-gray-700 mb-2">主机地址</label>
                                <input type="text" v-model="config.his_database.host" class="w-full border rounded px-3 py-2">
                            </div>
                            <div>
                                <label class="block text-gray-700 mb-2">端口</label>
                                <input type="number" v-model="config.his_database.port" class="w-full border rounded px-3 py-2">
                            </div>
                            <div>
                                <label class="block text-gray-700 mb-2">数据库名</label>
                                <input type="text" v-model="config.his_database.database" class="w-full border rounded px-3 py-2">
                            </div>
                            <div>
                                <label class="block text-gray-700 mb-2">用户名</label>
                                <input type="text" v-model="config.his_database.username" class="w-full border rounded px-3 py-2">
                            </div>
                            <div>
                                <label class="block text-gray-700 mb-2">密码</label>
                                <input type="password" v-model="config.his_database.password" class="w-full border rounded px-3 py-2">
                            </div>
                        </div>
                    </section>

                    <!-- LIS 系统对接 -->
                    <section class="border rounded-lg p-4">
                        <h3 class="text-lg font-bold text-green-600 mb-4">
                            <i class="fas fa-flask mr-2"></i>LIS 系统对接
                        </h3>
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-gray-700 mb-2">启用 LIS 对接</label>
                                <input type="checkbox" v-model="config.lis_enabled" class="mr-2">
                            </div>
                            <div>
                                <label class="block text-gray-700 mb-2">主机地址</label>
                                <input type="text" v-model="config.lis_database.host" class="w-full border rounded px-3 py-2">
                            </div>
                            <div>
                                <label class="block text-gray-700 mb-2">端口</label>
                                <input type="number" v-model="config.lis_database.port" class="w-full border rounded px-3 py-2">
                            </div>
                            <div>
                                <label class="block text-gray-700 mb-2">数据库名</label>
                                <input type="text" v-model="config.lis_database.database" class="w-full border rounded px-3 py-2">
                            </div>
                        </div>
                    </section>

                    <!-- PACS 系统对接 -->
                    <section class="border rounded-lg p-4">
                        <h3 class="text-lg font-bold text-purple-600 mb-4">
                            <i class="fas fa-x-ray mr-2"></i>PACS 系统对接
                        </h3>
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-gray-700 mb-2">启用 PACS 对接</label>
                                <input type="checkbox" v-model="config.pacs_enabled" class="mr-2">
                            </div>
                            <div>
                                <label class="block text-gray-700 mb-2">DICOM AE Title</label>
                                <input type="text" v-model="config.pacs_dicom_ae_title" class="w-full border rounded px-3 py-2">
                            </div>
                            <div>
                                <label class="block text-gray-700 mb-2">DICOM 端口</label>
                                <input type="number" v-model="config.pacs_dicom_port" class="w-full border rounded px-3 py-2">
                            </div>
                        </div>
                    </section>

                    <!-- 病历生成参数 -->
                    <section class="border rounded-lg p-4 bg-blue-50">
                        <h3 class="text-lg font-bold text-gray-800 mb-4">
                            <i class="fas fa-file-medical mr-2"></i>病历生成参数
                        </h3>
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-gray-700 mb-2">自动生成病历</label>
                                <input type="checkbox" v-model="config.auto_generate" class="mr-2">
                            </div>
                            <div>
                                <label class="block text-gray-700 mb-2">模板引擎</label>
                                <select v-model="config.template_engine" class="w-full border rounded px-3 py-2">
                                    <option value="jinja2">Jinja2</option>
                                    <option value="mako">Mako</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-gray-700 mb-2">启用质控检查</label>
                                <input type="checkbox" v-model="config.quality_check_enabled" class="mr-2">
                            </div>
                        </div>
                    </section>
                </div>

                <!-- 医保模块配置 -->
                <div v-if="selectedModule === 'insurance_compliance'" class="space-y-6">
                    <!-- 医保前置机 -->
                    <section class="border rounded-lg p-4">
                        <h3 class="text-lg font-bold text-blue-600 mb-4">
                            <i class="fas fa-server mr-2"></i>医保前置机对接
                        </h3>
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-gray-700 mb-2">启用前置机</label>
                                <input type="checkbox" v-model="config.preprocessor_enabled" class="mr-2">
                            </div>
                            <div>
                                <label class="block text-gray-700 mb-2">主机地址</label>
                                <input type="text" v-model="config.preprocessor_host" class="w-full border rounded px-3 py-2">
                            </div>
                            <div>
                                <label class="block text-gray-700 mb-2">端口</label>
                                <input type="number" v-model="config.preprocessor_port" class="w-full border rounded px-3 py-2">
                            </div>
                            <div>
                                <label class="block text-gray-700 mb-2">API 密钥</label>
                                <input type="password" v-model="config.preprocessor_api_key" class="w-full border rounded px-3 py-2">
                            </div>
                        </div>
                    </section>

                    <!-- DRG/DIP 分组 -->
                    <section class="border rounded-lg p-4 bg-green-50">
                        <h3 class="text-lg font-bold text-gray-800 mb-4">
                            <i class="fas fa-project-diagram mr-2"></i>DRG/DIP 分组配置
                        </h3>
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-gray-700 mb-2">启用 DRG</label>
                                <input type="checkbox" v-model="config.drg_enabled" class="mr-2">
                            </div>
                            <div>
                                <label class="block text-gray-700 mb-2">DRG 版本</label>
                                <select v-model="config.drg_version" class="w-full border rounded px-3 py-2">
                                    <option value="CHS-DRG 1.1">CHS-DRG 1.1</option>
                                    <option value="CHS-DRG 1.0">CHS-DRG 1.0</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-gray-700 mb-2">启用 DIP</label>
                                <input type="checkbox" v-model="config.dip_enabled" class="mr-2">
                            </div>
                            <div>
                                <label class="block text-gray-700 mb-2">DIP 版本</label>
                                <select v-model="config.dip_version" class="w-full border rounded px-3 py-2">
                                    <option value="国家版 2.0">国家版 2.0</option>
                                    <option value="国家版 1.0">国家版 1.0</option>
                                </select>
                            </div>
                        </div>
                    </section>
                </div>

                <!-- 风险预测模块配置 -->
                <div v-if="selectedModule === 'risk_prediction'" class="space-y-6">
                    <!-- 数据源配置 -->
                    <section class="border rounded-lg p-4">
                        <h3 class="text-lg font-bold text-blue-600 mb-4">
                            <i class="fas fa-database mr-2"></i>数据源配置
                        </h3>
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-gray-700 mb-2">HIS 数据</label>
                                <input type="checkbox" v-model="config.his_data_enabled" class="mr-2">
                            </div>
                            <div>
                                <label class="block text-gray-700 mb-2">LIS 数据</label>
                                <input type="checkbox" v-model="config.lis_data_enabled" class="mr-2">
                            </div>
                            <div>
                                <label class="block text-gray-700 mb-2">PACS 数据</label>
                                <input type="checkbox" v-model="config.pacs_data_enabled" class="mr-2">
                            </div>
                            <div>
                                <label class="block text-gray-700 mb-2">EMR 数据</label>
                                <input type="checkbox" v-model="config.emr_data_enabled" class="mr-2">
                            </div>
                        </div>
                    </section>

                    <!-- 预测模型 -->
                    <section class="border rounded-lg p-4 bg-purple-50">
                        <h3 class="text-lg font-bold text-gray-800 mb-4">
                            <i class="fas fa-brain mr-2"></i>预测模型配置
                        </h3>
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-gray-700 mb-2">模型类型</label>
                                <select v-model="config.model_type" class="w-full border rounded px-3 py-2">
                                    <option value="ensemble">集成模型</option>
                                    <option value="xgboost">XGBoost</option>
                                    <option value="random_forest">随机森林</option>
                                    <option value="logistic">逻辑回归</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-gray-700 mb-2">置信度阈值</label>
                                <input type="number" step="0.1" v-model="config.confidence_threshold" class="w-full border rounded px-3 py-2">
                            </div>
                        </div>
                    </section>
                </div>

                <!-- 医学影像模块配置 -->
                <div v-if="selectedModule === 'medical_imaging'" class="space-y-6">
                    <!-- PACS 对接 -->
                    <section class="border rounded-lg p-4">
                        <h3 class="text-lg font-bold text-blue-600 mb-4">
                            <i class="fas fa-x-ray mr-2"></i>PACS 对接配置
                        </h3>
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-gray-700 mb-2">DICOM AE Title</label>
                                <input type="text" v-model="config.pacs_dicom_ae_title" class="w-full border rounded px-3 py-2">
                            </div>
                            <div>
                                <label class="block text-gray-700 mb-2">PACS 主机</label>
                                <input type="text" v-model="config.pacs_dicom_host" class="w-full border rounded px-3 py-2">
                            </div>
                            <div>
                                <label class="block text-gray-700 mb-2">PACS 端口</label>
                                <input type="number" v-model="config.pacs_dicom_port" class="w-full border rounded px-3 py-2">
                            </div>
                            <div>
                                <label class="block text-gray-700 mb-2">WADO URL</label>
                                <input type="text" v-model="config.pacs_wado_url" class="w-full border rounded px-3 py-2">
                            </div>
                        </div>
                    </section>

                    <!-- AI 模型 -->
                    <section class="border rounded-lg p-4 bg-purple-50">
                        <h3 class="text-lg font-bold text-gray-800 mb-4">
                            <i class="fas fa-robot mr-2"></i>AI 模型配置
                        </h3>
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-gray-700 mb-2">模型提供商</label>
                                <select v-model="config.model_provider" class="w-full border rounded px-3 py-2">
                                    <option value="local">本地部署</option>
                                    <option value="azure">Azure AI</option>
                                    <option value="aws">AWS AI</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-gray-700 mb-2">启用 GPU 加速</label>
                                <input type="checkbox" v-model="config.gpu_enabled" class="mr-2">
                            </div>
                            <div>
                                <label class="block text-gray-700 mb-2">肺结节检测</label>
                                <input type="checkbox" v-model="config.lung_nodule_enabled" class="mr-2">
                            </div>
                            <div>
                                <label class="block text-gray-700 mb-2">骨折检测</label>
                                <input type="checkbox" v-model="config.fracture_enabled" class="mr-2">
                            </div>
                        </div>
                    </section>
                </div>

                <!-- 其他模块配置占位 -->
                <div v-if="['clinical_research', 'literature_analysis', 'quality_audit'].includes(selectedModule)" class="text-center py-12">
                    <i class="fas fa-tools text-6xl text-gray-300 mb-4"></i>
                    <p class="text-gray-500">该模块配置页面正在开发中...</p>
                </div>
            </div>
        </div>
    </div>

    <script>
        const { createApp } = Vue;

        createApp({
            data() {
                return {
                    selectedModule: '',
                    config: {},
                    modules: [
                        { id: 'emr_generation', name: '电子病历生成引擎', icon: '' },
                        { id: 'insurance_compliance', name: '医保合规性评估', icon: '💎' },
                        { id: 'risk_prediction', name: '临床风险预测', icon: '🔮' },
                        { id: 'medical_imaging', name: '医学影像 AI', icon: '👁️' },
                        { id: 'clinical_research', name: '临床科研分析', icon: '📊' },
                        { id: 'literature_analysis', name: '医学文献解读', icon: '📚' },
                        { id: 'quality_audit', name: '医疗质量审计', icon: '🛡️' }
                    ]
                };
            },
            methods: {
                selectModule(moduleId) {
                    this.selectedModule = moduleId;
                    this.loadConfig();
                },
                async loadConfig() {
                    try {
                        const response = await fetch(`/api/module-config/${this.selectedModule}`);
                        const data = await response.json();
                        if (data.success) {
                            this.config = data.data;
                        }
                    } catch (error) {
                        console.error('加载配置失败:', error);
                    }
                },
                async saveConfig() {
                    try {
                        const response = await fetch(`/api/module-config/${this.selectedModule}`, {
                            method: 'PUT',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify(this.config)
                        });
                        const data = await response.json();
                        if (data.success) {
                            alert('配置保存成功！');
                        } else {
                            alert('保存失败：' + data.message);
                        }
                    } catch (error) {
                        alert('保存失败：' + error.message);
                    }
                }
            }
        }).mount('#app');
    </script>
</body>
</html>
"""

__all__ = ["get_module_config_page_template"]
