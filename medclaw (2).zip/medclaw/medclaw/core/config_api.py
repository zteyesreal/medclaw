"""
MedClaw 配置管理 API
提供配置加载、保存、验证的 HTTP 接口
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from typing import Dict, List, Optional, Any
import yaml
import json
from pathlib import Path
from datetime import datetime

router = APIRouter(prefix="/api/config", tags=["配置管理"])

# 配置文件路径
CONFIG_PATH = Path("config.yaml")


# ========== 数据模型 ==========

class AppConfigModel(BaseModel):
    """应用配置"""
    name: str = "MedClaw"
    debug: bool = False


class DatabaseConfigModel(BaseModel):
    """数据库配置"""
    url: str = "sqlite:///./medclaw.db"


class MCPConfigModel(BaseModel):
    """MCP 配置"""
    server_url: str = "http://localhost:8001"
    api_key: Optional[str] = ""
    timeout: int = 30


class QQBotConfigModel(BaseModel):
    """QQBot 配置"""
    type: str = "go-cqhttp"
    driver: Optional[str] = "~fastapi+~websockets"
    host: Optional[str] = "127.0.0.1"
    port: Optional[int] = 8080
    websocket: Optional[str] = "ws://127.0.0.1:6700"


class ModuleConfigModel(BaseModel):
    """模块配置"""
    enabled: List[str] = [
        "medical_record",
        "medical_quality",
        "insurance_analysis",
        "clinical_prediction",
        "ai_reading",
        "research_analysis",
        "paper_analysis"
    ]
    
    medical_record: Dict[str, Any] = {"template_dir": "./templates/medical_record"}
    medical_quality: Dict[str, Any] = {"rule_dir": "./rules/medical_quality"}
    insurance_analysis: Dict[str, Any] = {"drg_dict_path": "./data/drg_dict.json", "rule_dir": "./rules/insurance"}
    clinical_prediction: Dict[str, Any] = {"model_dir": "./models/clinical"}
    ai_reading: Dict[str, Any] = {"model_name": "resnet50", "weights_path": "./models/ai_reading/model.pth", "device": "cpu", "dicom_cache": "./cache/dicom"}
    research_analysis: Dict[str, Any] = {"data_dir": "./data/research"}
    paper_analysis: Dict[str, Any] = {"cache_dir": "./cache/papers"}


class ConfigModel(BaseModel):
    """完整配置模型"""
    app: AppConfigModel = Field(default_factory=AppConfigModel)
    database: DatabaseConfigModel = Field(default_factory=DatabaseConfigModel)
    mcp: MCPConfigModel = Field(default_factory=MCPConfigModel)
    qqbot: QQBotConfigModel = Field(default_factory=QQBotConfigModel)
    modules: ModuleConfigModel = Field(default_factory=ModuleConfigModel)


# ========== 辅助函数 ==========

def load_config() -> Dict[str, Any]:
    """加载配置文件"""
    if not CONFIG_PATH.exists():
        # 创建默认配置
        default_config = ConfigModel()
        save_config(default_config.dict())
        return default_config.dict()
    
    with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)


def save_config(config_data: Dict[str, Any]) -> bool:
    """保存配置文件"""
    try:
        with open(CONFIG_PATH, 'w', encoding='utf-8') as f:
            yaml.dump(config_data, f, allow_unicode=True, default_flow_style=False)
        return True
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"保存配置失败：{str(e)}")


def validate_config(config_data: Dict[str, Any]) -> Dict[str, List[str]]:
    """验证配置，返回错误信息"""
    errors = []
    warnings = []
    
    # 验证 MCP 配置
    mcp = config_data.get('mcp', {})
    if not mcp.get('server_url'):
        warnings.append("MCP 服务端地址未配置，将使用默认值")
    
    # 验证 QQBot 配置
    qqbot = config_data.get('qqbot', {})
    if qqbot.get('type') == 'go-cqhttp':
        if not qqbot.get('websocket'):
            errors.append("go-cqhttp 模式需要配置 WebSocket 地址")
    elif qqbot.get('type') == 'nonebot':
        if not qqbot.get('port'):
            errors.append("NoneBot 模式需要配置端口号")
    
    # 验证模块配置
    modules = config_data.get('modules', {})
    enabled = modules.get('enabled', [])
    if not enabled:
        warnings.append("未启用任何模块")
    
    return {
        "errors": errors,
        "warnings": warnings,
        "valid": len(errors) == 0
    }


# ========== API 路由 ==========

@router.get("")
def get_config():
    """获取当前配置"""
    try:
        config = load_config()
        return {
            "success": True,
            "data": config,
            "config_path": str(CONFIG_PATH.absolute())
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("")
def update_config(config_data: ConfigModel):
    """更新配置"""
    try:
        # 验证配置
        validation = validate_config(config_data.dict())
        
        # 保存配置
        save_config(config_data.dict())
        
        return {
            "success": True,
            "message": "配置已保存",
            "validation": validation,
            "config_path": str(CONFIG_PATH.absolute()),
            "saved_at": datetime.now().isoformat()
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"保存配置失败：{str(e)}")


@router.post("/validate")
def validate_config_endpoint(config_data: ConfigModel):
    """验证配置"""
    try:
        validation = validate_config(config_data.dict())
        return {
            "success": True,
            "validation": validation
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/reset")
def reset_config():
    """重置为默认配置"""
    try:
        default_config = ConfigModel()
        save_config(default_config.dict())
        
        return {
            "success": True,
            "message": "配置已重置为默认值",
            "data": default_config.dict()
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/modules")
def get_available_modules():
    """获取可用模块列表"""
    modules = [
        {
            "id": "medical_record",
            "name": "病历书写",
            "description": "结构化病历生成、模板填充",
            "icon": "📝",
            "default_enabled": True
        },
        {
            "id": "medical_quality",
            "name": "病历质控",
            "description": "完整性检查、合理性验证",
            "icon": "✅",
            "default_enabled": True
        },
        {
            "id": "insurance_analysis",
            "name": "医保分析",
            "description": "DRG/DIP 分组、费用分析",
            "icon": "💰",
            "default_enabled": True
        },
        {
            "id": "clinical_prediction",
            "name": "临床预测",
            "description": "败血症、并发症风险预测",
            "icon": "🔮",
            "default_enabled": True
        },
        {
            "id": "ai_reading",
            "name": "AI 阅片",
            "description": "CT/X 光分析、病灶检测",
            "icon": "🖼️",
            "default_enabled": True
        },
        {
            "id": "research_analysis",
            "name": "科研分析",
            "description": "统计分析、趋势分析",
            "icon": "📊",
            "default_enabled": True
        },
        {
            "id": "paper_analysis",
            "name": "论文分析",
            "description": "PDF 解析、信息提取",
            "icon": "📄",
            "default_enabled": True
        }
    ]
    
    return {
        "success": True,
        "modules": modules
    }
