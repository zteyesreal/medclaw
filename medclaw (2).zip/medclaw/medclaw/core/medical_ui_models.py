"""
MedClaw 医疗专用 UI 数据模型
包含所有请求/响应模型定义
"""

from pydantic import BaseModel
from typing import Dict, List, Optional, Any


class MedicalRecordRequest(BaseModel):
    """病历书写请求"""
    patient_info: Dict[str, Any]
    chief_complaint: str
    present_illness: str = ""
    action: str = "generate"
    lab_results: Optional[Dict[str, Any]] = None
    exam_results: Optional[Dict[str, Any]] = None
    allow_dynamic_adjustment: bool = True
    additional_steps: Optional[List[Dict[str, Any]]] = None
    step_modifications: Optional[Dict[int, Dict[str, Any]]] = None


class QualityCheckRequest(BaseModel):
    """病历质控请求"""
    medical_record_id: str
    medical_record: Dict[str, Any]
    doctor_workload: Optional[Dict[str, Any]] = None
    department_standards: Optional[Dict[str, Any]] = None
    historical_issues: Optional[List[str]] = None


class InsuranceAnalysisRequest(BaseModel):
    """医保分析请求"""
    medical_record_id: str
    medical_record: Dict[str, Any]
    cost_details: Optional[Dict[str, Any]] = None
    insurance_policy: Optional[str] = None
    historical_audits: Optional[List[Dict[str, Any]]] = None


class PredictionRequest(BaseModel):
    """临床预测请求"""
    model_name: str = "sepsis"
    patient_data: Dict[str, Any]
    vital_signs_history: Optional[List[Dict[str, Any]]] = None
    lab_trends: Optional[Dict[str, Any]] = None
    comorbidities: Optional[List[str]] = None


class AIReadingRequest(BaseModel):
    """AI 阅片请求"""
    image_path: str
    image_type: str = "ct"
    patient_history: Optional[Dict[str, Any]] = None
    previous_images: Optional[List[str]] = None
    clinical_suspicion: Optional[str] = None


class ResearchAnalysisRequest(BaseModel):
    """科研分析请求"""
    data: Dict[str, Any]
    analysis_type: str = "descriptive"
    inclusion_criteria: Optional[Dict[str, Any]] = None
    exclusion_criteria: Optional[Dict[str, Any]] = None
    grouping_method: Optional[str] = None
    statistical_methods: Optional[List[str]] = None


class PaperAnalysisRequest(BaseModel):
    """论文分析请求"""
    paper_input: str
    input_type: str = "text"
    research_field: Optional[str] = None
    analysis_depth: Optional[str] = None
    output_language: Optional[str] = None
