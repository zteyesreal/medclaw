"""
MedClaw 工具编排器
支持工具调用链、并行执行、缓存、权限控制
"""

import asyncio
import time
from typing import Dict, List, Optional, Any, Callable, Union, Tuple
from datetime import datetime
import logging
import uuid

from .mcp_client import MCPClient, MCPTool, MCPError
from .tool_cache import MemoryToolCache, ToolCacheFactory
from .tool_permissions import ToolPermissionManager
from .tool_audit import ToolAuditLogger

logger = logging.getLogger(__name__)


class ToolChainStep:
    """工具链步骤"""
    
    def __init__(
        self,
        tool_name: str,
        params: Optional[Dict[str, Any]] = None,
        output_mapping: Optional[str] = None,
        condition: Optional[Callable[[Any], bool]] = None
    ):
        self.tool_name = tool_name
        self.params = params or {}
        self.output_mapping = output_mapping  # 将输出映射到哪个参数名
        self.condition = condition  # 条件函数，接收前一步输出，返回是否执行
    
    def should_execute(self, previous_output: Any) -> bool:
        """检查是否应该执行"""
        if self.condition is None:
            return True
        return self.condition(previous_output)


class ToolChain:
    """工具调用链"""
    
    def __init__(self, chain_id: Optional[str] = None):
        self.chain_id = chain_id or str(uuid.uuid4())
        self.steps: List[ToolChainStep] = []
        self.results: List[Any] = []
        self.start_time: Optional[float] = None
        self.end_time: Optional[float] = None
    
    def add_step(
        self,
        tool_name: str,
        params: Optional[Dict[str, Any]] = None,
        output_mapping: Optional[str] = None,
        condition: Optional[Callable[[Any], bool]] = None
    ) -> 'ToolChain':
        """添加步骤到链"""
        step = ToolChainStep(tool_name, params, output_mapping, condition)
        self.steps.append(step)
        return self
    
    def reset(self):
        """重置链"""
        self.steps.clear()
        self.results.clear()
        self.start_time = None
        self.end_time = None
    
    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        duration = (self.end_time - self.start_time) if self.end_time and self.start_time else 0
        return {
            "chain_id": self.chain_id,
            "steps_count": len(self.steps),
            "results_count": len(self.results),
            "duration_seconds": duration,
        }


class ToolOrchestrator:
    """工具编排器"""
    
    def __init__(
        self,
        mcp_client: MCPClient,
        cache_enabled: bool = True,
        permission_enabled: bool = True,
        audit_enabled: bool = True,
        cache_config: Optional[Dict[str, Any]] = None,
    ):
        self.mcp_client = mcp_client
        self.cache_enabled = cache_enabled
        self.permission_enabled = permission_enabled
        self.audit_enabled = audit_enabled
        
        # 初始化缓存
        if cache_enabled:
            cache_type = (cache_config or {}).get("type", "memory")
            self.cache = ToolCacheFactory.create_cache(cache_type, **(cache_config or {}))
        else:
            self.cache = None
        
        # 初始化权限管理器
        if permission_enabled:
            self.permission_manager = ToolPermissionManager()
        else:
            self.permission_manager = None
        
        # 初始化审计日志
        if audit_enabled:
            self.audit_logger = ToolAuditLogger()
        else:
            self.audit_logger = None
        
        # 统计信息
        self.stats = {
            "total_calls": 0,
            "cache_hits": 0,
            "permission_denied": 0,
            "errors": 0,
        }
        
        logger.info(f"工具编排器已初始化")
    
    async def initialize(self):
        """初始化编排器"""
        if self.cache and hasattr(self.cache, 'initialize'):
            await self.cache.initialize()
        
        if self.permission_manager:
            await self.permission_manager.initialize()
        
        if self.audit_logger:
            await self.audit_logger.initialize()
        
        logger.info("工具编排器初始化完成")
    
    async def execute(
        self,
        tool_name: str,
        params: Optional[Dict[str, Any]] = None,
        bypass_cache: bool = False,
        bypass_permission: bool = False,
        **kwargs
    ) -> Any:
        """
        执行工具（带编排功能）
        
        Args:
            tool_name: 工具名称
            params: 工具参数
            bypass_cache: 是否绕过缓存
            bypass_permission: 是否绕过权限检查
            **kwargs: 额外参数
            
        Returns:
            工具执行结果
        """
        self.stats["total_calls"] += 1
        start_time = time.time()
        
        try:
            # 权限检查
            if self.permission_enabled and not bypass_permission:
                await self._check_permission(tool_name, params)
            
            # 缓存检查
            if self.cache_enabled and not bypass_cache:
                cached_result = await self.cache.get(tool_name, params or {})
                if cached_result is not None:
                    self.stats["cache_hits"] += 1
                    logger.info(f"缓存命中：{tool_name}")
                    return cached_result
            
            # 执行工具
            result = await self.mcp_client.call_tool(tool_name, **(params or {}))
            
            # 缓存结果
            if self.cache_enabled and not bypass_cache:
                await self.cache.set(tool_name, params or {}, result)
            
            # 审计日志
            if self.audit_enabled:
                await self.audit_logger.log_call(
                    tool_name=tool_name,
                    params=params or {},
                    result=result,
                    duration=time.time() - start_time,
                    caller="orchestrator"
                )
            
            return result
            
        except MCPError as e:
            self.stats["errors"] += 1
            logger.error(f"MCP 工具执行失败：{tool_name}, 错误：{e}")
            raise
        except PermissionError as e:
            self.stats["permission_denied"] += 1
            logger.warning(f"权限拒绝：{tool_name}, 错误：{e}")
            raise
        except Exception as e:
            self.stats["errors"] += 1
            logger.error(f"工具执行失败：{tool_name}, 错误：{e}")
            raise
    
    async def execute_chain(
        self,
        chain: ToolChain,
        initial_params: Optional[Dict[str, Any]] = None
    ) -> List[Any]:
        """
        执行工具链
        
        Args:
            chain: 工具链
            initial_params: 初始参数
            
        Returns:
            所有步骤的结果列表
        """
        chain.start_time = time.time()
        
        results = []
        previous_output = None
        
        for step in chain.steps:
            # 检查条件
            if not step.should_execute(previous_output):
                logger.info(f"跳过步骤：{step.tool_name} (条件不满足)")
                results.append(None)
                continue
            
            # 准备参数
            params = step.params.copy() if step.params else {}
            
            # 如果指定了 output_mapping，将前一步输出作为参数
            if previous_output is not None and step.output_mapping:
                params[step.output_mapping] = previous_output
            
            # 执行步骤
            try:
                result = await self.execute(step.tool_name, params)
                results.append(result)
                previous_output = result
                
                logger.info(f"工具链步骤完成：{step.tool_name}")
                
            except Exception as e:
                logger.error(f"工具链步骤失败：{step.tool_name}, 错误：{e}")
                raise
        
        chain.results = results
        chain.end_time = time.time()
        
        logger.info(f"工具链执行完成：{chain.chain_id}, 步骤数：{len(results)}")
        return results
    
    async def execute_parallel(
        self,
        tool_calls: List[Tuple[str, Dict[str, Any]]]
    ) -> List[Any]:
        """
        并行执行多个工具调用
        
        Args:
            tool_calls: 工具调用列表 [(tool_name, params), ...]
            
        Returns:
            结果列表
        """
        coroutines = []
        
        for tool_name, params in tool_calls:
            coro = self.execute(tool_name, params)
            coroutines.append(coro)
        
        # 并行执行所有工具
        results = await asyncio.gather(*coroutines, return_exceptions=True)
        
        # 处理异常
        processed_results = []
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                logger.error(f"并行工具 {tool_calls[i][0]} 执行失败：{result}")
                processed_results.append(None)  # 或者抛出异常
            else:
                processed_results.append(result)
        
        logger.info(f"并行执行完成：{len(results)} 个工具")
        return processed_results
    
    async def _check_permission(self, tool_name: str, params: Optional[Dict[str, Any]]):
        """检查权限"""
        if not self.permission_manager:
            return
        
        # 这里可以获取当前调用者（从上下文、token 等）
        # 简化版本：假设是默认用户
        caller = "default_user"
        
        if not await self.permission_manager.has_permission(caller, tool_name):
            raise PermissionError(f"用户 {caller} 没有权限调用工具 {tool_name}")
    
    def create_chain(self) -> ToolChain:
        """创建新的工具链"""
        return ToolChain()
    
    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        cache_stats = self.cache.get_stats() if self.cache else {}
        permission_stats = self.permission_manager.get_stats() if self.permission_manager else {}
        audit_stats = self.audit_logger.get_stats() if self.audit_logger else {}
        
        return {
            **self.stats,
            "cache": cache_stats,
            "permission": permission_stats,
            "audit": audit_stats,
        }
    
    async def clear_cache(self):
        """清空缓存"""
        if self.cache:
            await self.cache.clear()
            logger.info("缓存已清空")
    
    async def cleanup(self):
        """清理资源"""
        if self.cache and hasattr(self.cache, 'cleanup'):
            await self.cache.cleanup()
        
        if self.audit_logger:
            await self.audit_logger.cleanup()
        
        logger.info("工具编排器已清理")


# ========== 导出符号 ==========

__all__ = [
    "ToolChainStep",
    "ToolChain",
    "ToolOrchestrator",
]
