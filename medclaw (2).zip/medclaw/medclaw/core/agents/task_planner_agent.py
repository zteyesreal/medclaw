"""
MedClaw Task Planner Agent
实现任务智能拆解、LLM 调用、子任务规划
"""

import asyncio
import json
from typing import Dict, List, Optional, Any, TypeVar, Generic
from datetime import datetime
import logging
import uuid

from .base import BaseAgent, AgentCapability, AgentStatus

logger = logging.getLogger(__name__)


class SubTask:
    """子任务定义"""
    
    def __init__(
        self,
        task_id: str,
        description: str,
        required_capability: str,
        params: Optional[Dict[str, Any]] = None,
        dependencies: Optional[List[str]] = None,
        priority: int = 5,
        estimated_duration: Optional[int] = None,
    ):
        self.task_id = task_id
        self.description = description
        self.required_capability = required_capability
        self.params = params or {}
        self.dependencies = dependencies or []
        self.priority = priority
        self.estimated_duration = estimated_duration  # 秒
        self.status = "pending"  # pending, running, completed, failed
        self.result: Optional[Any] = None
        self.error: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "task_id": self.task_id,
            "description": self.description,
            "required_capability": self.required_capability,
            "params": self.params,
            "dependencies": self.dependencies,
            "priority": self.priority,
            "estimated_duration": self.estimated_duration,
            "status": self.status,
            "result": self.result,
            "error": self.error,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SubTask":
        task = cls(
            task_id=data["task_id"],
            description=data["description"],
            required_capability=data["required_capability"],
            params=data.get("params", {}),
            dependencies=data.get("dependencies", []),
            priority=data.get("priority", 5),
            estimated_duration=data.get("estimated_duration"),
        )
        task.status = data.get("status", "pending")
        task.result = data.get("result")
        task.error = data.get("error")
        return task


class TaskPlan:
    """任务计划"""
    
    def __init__(self, plan_id: Optional[str] = None):
        self.plan_id = plan_id or str(uuid.uuid4())
        self.goal: str = ""
        self.subtasks: List[SubTask] = []
        self.created_at = datetime.now()
        self.started_at: Optional[datetime] = None
        self.completed_at: Optional[datetime] = None
        self.status = "draft"  # draft, running, completed, failed
    
    def add_subtask(self, subtask: SubTask) -> "TaskPlan":
        """添加子任务"""
        self.subtasks.append(subtask)
        return self
    
    def get_subtask(self, task_id: str) -> Optional[SubTask]:
        """获取子任务"""
        for task in self.subtasks:
            if task.task_id == task_id:
                return task
        return None
    
    def get_ready_tasks(self) -> List[SubTask]:
        """获取可以执行的任务（依赖已满足）"""
        ready = []
        for task in self.subtasks:
            if task.status != "pending":
                continue
            
            # 检查依赖
            deps_satisfied = all(
                any(t.task_id == dep_id and t.status == "completed" 
                    for t in self.subtasks)
                for dep_id in task.dependencies
            )
            
            if deps_satisfied:
                ready.append(task)
        
        return ready
    
    def get_execution_order(self) -> List[SubTask]:
        """获取执行顺序（拓扑排序）"""
        # 简单的拓扑排序
        in_degree = {task.task_id: len(task.dependencies) for task in self.subtasks}
        queue = [task for task in self.subtasks if in_degree[task.task_id] == 0]
        result = []
        
        while queue:
            # 按优先级排序
            queue.sort(key=lambda t: -t.priority)
            current = queue.pop(0)
            result.append(current)
            
            for task in self.subtasks:
                if current.task_id in task.dependencies:
                    in_degree[task.task_id] -= 1
                    if in_degree[task.task_id] == 0:
                        queue.append(task)
        
        return result
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "plan_id": self.plan_id,
            "goal": self.goal,
            "subtasks": [t.to_dict() for t in self.subtasks],
            "created_at": self.created_at.isoformat(),
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "status": self.status,
        }


class TaskPlannerAgent(BaseAgent):
    """Task Planner Agent"""
    
    def __init__(self, agent_id: Optional[str] = None, llm_config: Optional[Dict[str, Any]] = None):
        super().__init__(agent_id)
        self.name = "TaskPlannerAgent"
        self.llm_config = llm_config or {}
        
        # 注册能力
        self.capabilities = [
            AgentCapability(
                name="task_planning",
                description="任务规划和拆解能力",
                parameters={"max_subtasks": 20, "supports_dependencies": True}
            ),
            AgentCapability(
                name="llm_integration",
                description="LLM 调用能力",
                parameters={"providers": ["openai", "claude", "local"]}
            ),
            AgentCapability(
                name="execution_tracking",
                description="执行跟踪能力",
                parameters={"real_time_status": True, "progress_tracking": True}
            ),
        ]
        
        self.current_plan: Optional[TaskPlan] = None
        self.plans_history: List[TaskPlan] = []
    
    async def initialize(self) -> bool:
        """初始化"""
        logger.info(f"TaskPlannerAgent {self.agent_id} 初始化")
        self.status = AgentStatus.IDLE
        return True
    
    async def execute(self, task: Any) -> Any:
        """执行任务"""
        self.status = AgentStatus.BUSY
        self.last_active = datetime.now()
        
        try:
            action = task.get("action")
            params = task.get("params", {})
            
            if action == "decompose_goal":
                return await self.decompose_goal(
                    goal=params.get("goal", ""),
                    context=params.get("context", {}),
                )
            elif action == "create_plan":
                return await self.create_plan(
                    goal=params.get("goal", ""),
                    subtasks=params.get("subtasks", []),
                )
            elif action == "execute_plan":
                return await self.execute_plan(params.get("plan", {}))
            elif action == "get_plan_status":
                return await self.get_plan_status(params.get("plan_id", ""))
            elif action == "update_subtask":
                return await self.update_subtask(
                    plan_id=params.get("plan_id", ""),
                    task_id=params.get("task_id", ""),
                    status=params.get("status", ""),
                    result=params.get("result"),
                    error=params.get("error"),
                )
            else:
                raise ValueError(f"未知操作：{action}")
                
        except Exception as e:
            logger.error(f"TaskPlannerAgent 执行失败：{e}")
            raise e
        finally:
            self.status = AgentStatus.IDLE
            self.completed_tasks += 1
    
    async def cleanup(self) -> bool:
        """清理"""
        logger.info(f"TaskPlannerAgent {self.agent_id} 清理完成")
        return True
    
    async def decompose_goal(
        self,
        goal: str,
        context: Optional[Dict[str, Any]] = None
    ) -> TaskPlan:
        """
        拆解目标为子任务
        
        Args:
            goal: 目标描述
            context: 上下文信息
            
        Returns:
            任务计划
        """
        logger.info(f"开始拆解目标：{goal}")
        
        plan = TaskPlan()
        plan.goal = goal
        plan.status = "draft"
        
        # 使用 LLM 进行任务拆解（如果有配置）
        if self.llm_config.get("provider"):
            try:
                subtasks = await self._llm_decompose_goal(goal, context)
                for task_data in subtasks:
                    subtask = SubTask(
                        task_id=task_data.get("task_id", str(uuid.uuid4())),
                        description=task_data.get("description", ""),
                        required_capability=task_data.get("required_capability", "general"),
                        params=task_data.get("params", {}),
                        dependencies=task_data.get("dependencies", []),
                        priority=task_data.get("priority", 5),
                        estimated_duration=task_data.get("estimated_duration"),
                    )
                    plan.add_subtask(subtask)
                
                logger.info(f"通过 LLM 拆解为 {len(subtasks)} 个子任务")
                
            except Exception as e:
                logger.warning(f"LLM 拆解失败，使用规则引擎：{e}")
                subtasks = self._rule_based_decompose(goal, context)
                for task_data in subtasks:
                    plan.add_subtask(SubTask(**task_data))
        else:
            # 使用规则引擎拆解
            subtasks = self._rule_based_decompose(goal, context)
            for task_data in subtasks:
                plan.add_subtask(SubTask(**task_data))
        
        self.current_plan = plan
        self.plans_history.append(plan)
        
        logger.info(f"任务计划已创建：{plan.plan_id}, 包含 {len(plan.subtasks)} 个子任务")
        return plan
    
    async def _llm_decompose_goal(
        self,
        goal: str,
        context: Optional[Dict[str, Any]] = None
    ) -> List[Dict[str, Any]]:
        """使用 LLM 拆解目标"""
        provider = self.llm_config.get("provider", "openai")
        
        # 构建提示词
        prompt = f"""请将以下目标拆解为可执行的子任务列表：

目标：{goal}

上下文：{json.dumps(context or {}, ensure_ascii=False)}

请返回 JSON 格式的子任务列表，每个子任务包含：
- task_id: 任务 ID（自动生成）
- description: 任务描述
- required_capability: 所需能力（如：screen_capture, file_search, keyboard_control 等）
- params: 任务参数
- dependencies: 依赖的任务 ID 列表
- priority: 优先级（1-10）
- estimated_duration: 预计执行时间（秒）

示例输出：
[
  {{
    "task_id": "task_1",
    "description": "打开 Chrome 浏览器",
    "required_capability": "application_control",
    "params": {{"application": "chrome"}},
    "dependencies": [],
    "priority": 10,
    "estimated_duration": 5
  }},
  {{
    "task_id": "task_2",
    "description": "搜索文件",
    "required_capability": "file_search",
    "params": {{"pattern": "*.pdf"}},
    "dependencies": ["task_1"],
    "priority": 8,
    "estimated_duration": 10
  }}
]

请只返回 JSON 数组，不要其他内容。"""
        
        # 调用 LLM（简化实现，实际应调用 API）
        if provider == "openai":
            return await self._call_openai(prompt)
        elif provider == "claude":
            return await self._call_claude(prompt)
        elif provider == "local":
            return await self._call_local_llm(prompt)
        else:
            raise ValueError(f"不支持的 LLM 提供商：{provider}")
    
    async def _call_openai(self, prompt: str) -> List[Dict[str, Any]]:
        """调用 OpenAI"""
        try:
            from openai import AsyncOpenAI
            
            api_key = self.llm_config.get("api_key")
            model = self.llm_config.get("model", "gpt-4")
            
            if not api_key:
                raise ValueError("OpenAI API Key 未配置")
            
            client = AsyncOpenAI(api_key=api_key)
            
            response = await client.chat.completions.create(
                model=model,
                messages=[
                    {"role": "system", "content": "你是一个任务规划专家，擅长将复杂目标拆解为可执行的子任务。"},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.3,
                max_tokens=2000,
            )
            
            result = response.choices[0].message.content
            subtasks = json.loads(result)
            
            return subtasks
            
        except ImportError:
            raise ValueError("需要安装 openai: pip install openai")
        except Exception as e:
            logger.error(f"OpenAI 调用失败：{e}")
            raise e
    
    async def _call_claude(self, prompt: str) -> List[Dict[str, Any]]:
        """调用 Claude"""
        try:
            from anthropic import AsyncAnthropic
            
            api_key = self.llm_config.get("api_key")
            model = self.llm_config.get("model", "claude-3-opus-20240229")
            
            if not api_key:
                raise ValueError("Claude API Key 未配置")
            
            client = AsyncAnthropic(api_key=api_key)
            
            response = await client.messages.create(
                model=model,
                max_tokens=2000,
                messages=[
                    {"role": "user", "content": prompt}
                ]
            )
            
            result = response.content[0].text
            subtasks = json.loads(result)
            
            return subtasks
            
        except ImportError:
            raise ValueError("需要安装 anthropic: pip install anthropic")
        except Exception as e:
            logger.error(f"Claude 调用失败：{e}")
            raise e
    
    async def _call_local_llm(self, prompt: str) -> List[Dict[str, Any]]:
        """调用本地 LLM"""
        # 这里可以集成 Ollama、vLLM 等本地模型
        # 简化实现：返回示例
        logger.warning("本地 LLM 未配置，返回示例任务")
        return [
            {
                "task_id": "task_1",
                "description": f"执行任务：{prompt[:50]}...",
                "required_capability": "general",
                "params": {},
                "dependencies": [],
                "priority": 5,
                "estimated_duration": 30
            }
        ]
    
    def _rule_based_decompose(
        self,
        goal: str,
        context: Optional[Dict[str, Any]] = None
    ) -> List[Dict[str, Any]]:
        """基于规则的任务拆解（简化版）"""
        # 简单的关键词匹配
        subtasks = []
        
        goal_lower = goal.lower()
        
        if "打开" in goal_lower or "启动" in goal_lower:
            subtasks.append({
                "task_id": str(uuid.uuid4()),
                "description": f"打开应用程序",
                "required_capability": "application_control",
                "params": {"application": "default"},
                "dependencies": [],
                "priority": 10,
                "estimated_duration": 5
            })
        
        if "搜索" in goal_lower or "查找" in goal_lower:
            subtasks.append({
                "task_id": str(uuid.uuid4()),
                "description": f"搜索文件",
                "required_capability": "file_search",
                "params": {"pattern": "*.*"},
                "dependencies": [],
                "priority": 8,
                "estimated_duration": 10
            })
        
        if "下载" in goal_lower:
            subtasks.append({
                "task_id": str(uuid.uuid4()),
                "description": f"下载文件",
                "required_capability": "network_download",
                "params": {},
                "dependencies": [],
                "priority": 7,
                "estimated_duration": 30
            })
        
        if "截图" in goal_lower or "截屏" in goal_lower:
            subtasks.append({
                "task_id": str(uuid.uuid4()),
                "description": f"屏幕截图",
                "required_capability": "screen_capture",
                "params": {},
                "dependencies": [],
                "priority": 6,
                "estimated_duration": 2
            })
        
        # 如果没有匹配到任何规则，返回一个通用任务
        if not subtasks:
            subtasks.append({
                "task_id": str(uuid.uuid4()),
                "description": f"执行目标：{goal}",
                "required_capability": "general",
                "params": {},
                "dependencies": [],
                "priority": 5,
                "estimated_duration": 60
            })
        
        return subtasks
    
    async def create_plan(
        self,
        goal: str,
        subtasks: List[Dict[str, Any]]
    ) -> TaskPlan:
        """创建任务计划"""
        plan = TaskPlan()
        plan.goal = goal
        
        for task_data in subtasks:
            subtask = SubTask(
                task_id=task_data.get("task_id", str(uuid.uuid4())),
                description=task_data.get("description", ""),
                required_capability=task_data.get("required_capability", "general"),
                params=task_data.get("params", {}),
                dependencies=task_data.get("dependencies", []),
                priority=task_data.get("priority", 5),
                estimated_duration=task_data.get("estimated_duration"),
            )
            plan.add_subtask(subtask)
        
        self.current_plan = plan
        self.plans_history.append(plan)
        
        return plan
    
    async def execute_plan(self, plan_data: Dict[str, Any]) -> Dict[str, Any]:
        """执行任务计划（需要协调器配合）"""
        # 这里只是标记，实际执行需要 AgentCoordinator
        plan_id = plan_data.get("plan_id")
        
        plan = None
        for p in self.plans_history:
            if p.plan_id == plan_id:
                plan = p
                break
        
        if not plan:
            raise ValueError(f"计划不存在：{plan_id}")
        
        plan.status = "running"
        plan.started_at = datetime.now()
        
        # 返回执行顺序
        execution_order = plan.get_execution_order()
        
        return {
            "plan_id": plan.plan_id,
            "status": "running",
            "execution_order": [t.task_id for t in execution_order],
            "total_subtasks": len(plan.subtasks),
        }
    
    async def get_plan_status(self, plan_id: str) -> Dict[str, Any]:
        """获取计划状态"""
        for plan in self.plans_history:
            if plan.plan_id == plan_id:
                return plan.to_dict()
        
        raise ValueError(f"计划不存在：{plan_id}")
    
    async def update_subtask(
        self,
        plan_id: str,
        task_id: str,
        status: str,
        result: Optional[Any] = None,
        error: Optional[str] = None
    ) -> bool:
        """更新子任务状态"""
        plan = None
        for p in self.plans_history:
            if p.plan_id == plan_id:
                plan = p
                break
        
        if not plan:
            raise ValueError(f"计划不存在：{plan_id}")
        
        subtask = plan.get_subtask(task_id)
        if not subtask:
            raise ValueError(f"子任务不存在：{task_id}")
        
        subtask.status = status
        subtask.result = result
        subtask.error = error
        
        # 检查计划是否完成
        all_completed = all(t.status == "completed" for t in plan.subtasks)
        any_failed = any(t.status == "failed" for t in plan.subtasks)
        
        if all_completed:
            plan.status = "completed"
            plan.completed_at = datetime.now()
        elif any_failed:
            plan.status = "failed"
            plan.completed_at = datetime.now()
        
        return True


# ========== 导出符号 ==========

__all__ = [
    "SubTask",
    "TaskPlan",
    "TaskPlannerAgent",
]
