"""
MedClaw Office Automation Agent
实现办公自动化能力：文件整理、搜索、邮件处理、文档读取
"""

import asyncio
import os
import shutil
import fnmatch
from pathlib import Path
from typing import Dict, Any, Optional, List
from datetime import datetime, timedelta
import logging

from .base import BaseAgent, AgentCapability, AgentStatus

logger = logging.getLogger(__name__)


class OfficeAutomationAgent(BaseAgent):
    """Office Automation Agent"""
    
    def __init__(self, agent_id: Optional[str] = None):
        super().__init__(agent_id)
        self.name = "OfficeAutomationAgent"
        
        # 注册能力
        self.capabilities = [
            AgentCapability(
                name="file_organization",
                description="文件整理能力",
                parameters={"actions": ["organize_by_type", "organize_by_date", "cleanup"]}
            ),
            AgentCapability(
                name="file_search",
                description="文件搜索能力",
                parameters={"patterns": ["*.pdf", "*.docx", "*.xlsx"], "recursive": True}
            ),
            AgentCapability(
                name="document_reading",
                description="文档读取能力",
                parameters={"formats": ["pdf", "docx", "xlsx", "txt"]}
            ),
            AgentCapability(
                name="email_handling",
                description="邮件处理能力（可选）",
                parameters={"provider": "outlook"}
            ),
        ]
    
    async def initialize(self) -> bool:
        """初始化"""
        logger.info(f"OfficeAutomationAgent {self.agent_id} 初始化")
        self.status = AgentStatus.IDLE
        self.last_active = datetime.now()
        return True
    
    async def execute(self, task: Any) -> Any:
        """执行任务"""
        self.status = AgentStatus.BUSY
        self.last_active = datetime.now()
        
        try:
            action = task.get("action")
            params = task.get("params", {})
            
            # 路由到具体方法
            if action == "organize_files":
                return await self.organize_files(**params)
            elif action == "search_files":
                return await self.search_files(**params)
            elif action == "cleanup_old_files":
                return await self.cleanup_old_files(**params)
            elif action == "read_pdf":
                return await self.read_pdf(**params)
            elif action == "read_docx":
                return await self.read_docx(**params)
            elif action == "read_xlsx":
                return await self.read_xlsx(**params)
            elif action == "read_txt":
                return await self.read_txt(**params)
            elif action == "get_file_info":
                return await self.get_file_info(**params)
            else:
                raise ValueError(f"未知操作：{action}")
                
        except Exception as e:
            logger.error(f"OfficeAutomationAgent 执行失败：{e}")
            raise e
        finally:
            self.status = AgentStatus.IDLE
            self.completed_tasks += 1
    
    async def cleanup(self) -> bool:
        """清理"""
        logger.info(f"OfficeAutomationAgent {self.agent_id} 清理完成")
        return True
    
    # ========== 文件整理 ==========
    
    async def organize_files(
        self,
        source_dir: str,
        target_dir: Optional[str] = None,
        organize_by: str = "type"
    ) -> Dict[str, Any]:
        """
        整理文件
        
        Args:
            source_dir: 源目录
            target_dir: 目标目录（默认为 source_dir）
            organize_by: 整理方式 ("type" 或 "date")
            
        Returns:
            整理结果
        """
        try:
            source = Path(source_dir)
            target = Path(target_dir) if target_dir else source
            
            if not source.exists():
                return {"success": False, "error": f"目录不存在：{source_dir}"}
            
            moved_count = 0
            organized_files = []
            
            # 获取所有文件
            files = [f for f in source.iterdir() if f.is_file()]
            
            for file_path in files:
                try:
                    if organize_by == "type":
                        # 按类型整理
                        extension = file_path.suffix.lower().replace(".", "")
                        if not extension:
                            extension = "other"
                        
                        target_subdir = target / extension
                        
                    elif organize_by == "date":
                        # 按日期整理
                        mtime = datetime.fromtimestamp(file_path.stat().st_mtime)
                        date_str = mtime.strftime("%Y-%m")
                        target_subdir = target / date_str
                    
                    else:
                        target_subdir = target
                    
                    # 创建目标目录
                    target_subdir.mkdir(parents=True, exist_ok=True)
                    
                    # 移动文件
                    target_path = target_subdir / file_path.name
                    
                    # 如果目标文件已存在，添加序号
                    if target_path.exists():
                        base = target_path.stem
                        suffix = target_path.suffix
                        counter = 1
                        while target_path.exists():
                            target_path = target_subdir / f"{base}_{counter}{suffix}"
                            counter += 1
                    
                    shutil.move(str(file_path), str(target_path))
                    moved_count += 1
                    organized_files.append({
                        "source": str(file_path),
                        "target": str(target_path),
                    })
                    
                except Exception as e:
                    logger.warning(f"移动文件 {file_path} 失败：{e}")
            
            return {
                "success": True,
                "moved_count": moved_count,
                "organized_files": organized_files,
                "organize_by": organize_by,
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    # ========== 文件搜索 ==========
    
    async def search_files(
        self,
        pattern: str,
        search_dir: Optional[str] = None,
        recursive: bool = True
    ) -> Dict[str, Any]:
        """
        搜索文件
        
        Args:
            pattern: 搜索模式（支持通配符，如 *.pdf）
            search_dir: 搜索目录（默认为当前目录）
            recursive: 是否递归搜索子目录
            
        Returns:
            搜索结果
        """
        try:
            search_path = Path(search_dir) if search_dir else Path.cwd()
            
            if not search_path.exists():
                return {"success": False, "error": f"目录不存在：{search_dir}"}
            
            matched_files = []
            
            if recursive:
                # 递归搜索
                for root, dirs, files in os.walk(search_path):
                    for filename in files:
                        if fnmatch.fnmatch(filename, pattern):
                            file_path = Path(root) / filename
                            matched_files.append({
                                "path": str(file_path),
                                "name": filename,
                                "size": file_path.stat().st_size,
                                "modified": datetime.fromtimestamp(
                                    file_path.stat().st_mtime
                                ).isoformat(),
                            })
            else:
                # 仅搜索当前目录
                for file_path in search_path.glob(pattern):
                    if file_path.is_file():
                        matched_files.append({
                            "path": str(file_path),
                            "name": file_path.name,
                            "size": file_path.stat().st_size,
                            "modified": datetime.fromtimestamp(
                                file_path.stat().st_mtime
                            ).isoformat(),
                        })
            
            return {
                "success": True,
                "count": len(matched_files),
                "pattern": pattern,
                "files": matched_files,
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    # ========== 清理旧文件 ==========
    
    async def cleanup_old_files(
        self,
        directory: str,
        days_old: int = 30,
        pattern: str = "*",
        dry_run: bool = True
    ) -> Dict[str, Any]:
        """
        清理旧文件
        
        Args:
            directory: 目录
            days_old: 多少天前的文件
            pattern: 文件模式
            dry_run: 是否仅模拟（不实际删除）
            
        Returns:
            清理结果
        """
        try:
            dir_path = Path(directory)
            
            if not dir_path.exists():
                return {"success": False, "error": f"目录不存在：{directory}"}
            
            cutoff_date = datetime.now() - timedelta(days=days_old)
            deleted_count = 0
            deleted_files = []
            total_size = 0
            
            for file_path in dir_path.glob(pattern):
                if file_path.is_file():
                    mtime = datetime.fromtimestamp(file_path.stat().st_mtime)
                    
                    if mtime < cutoff_date:
                        file_size = file_path.stat().st_size
                        
                        if not dry_run:
                            file_path.unlink()
                        
                        deleted_count += 1
                        deleted_files.append({
                            "path": str(file_path),
                            "size": file_size,
                            "modified": mtime.isoformat(),
                        })
                        total_size += file_size
            
            return {
                "success": True,
                "deleted_count": deleted_count,
                "deleted_files": deleted_files if deleted_count < 100 else deleted_files[:100],
                "total_size_bytes": total_size,
                "total_size_mb": round(total_size / (1024 * 1024), 2),
                "dry_run": dry_run,
                "days_old": days_old,
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    # ========== 文档读取 ==========
    
    async def read_pdf(
        self,
        file_path: str,
        pages: Optional[List[int]] = None
    ) -> Dict[str, Any]:
        """读取 PDF 文件"""
        try:
            # 尝试使用 PyPDF2
            try:
                import PyPDF2
                
                with open(file_path, "rb") as f:
                    reader = PyPDF2.PdfReader(f)
                    
                    if pages is None:
                        pages = list(range(len(reader.pages)))
                    
                    text_content = []
                    for page_num in pages:
                        if page_num < len(reader.pages):
                            page = reader.pages[page_num]
                            text_content.append(page.extract_text())
                    
                    return {
                        "success": True,
                        "file": file_path,
                        "pages": len(reader.pages),
                        "extracted_pages": len(text_content),
                        "content": "\n".join(text_content),
                    }
                    
            except ImportError:
                return {
                    "success": False,
                    "error": "需要安装 PyPDF2: pip install PyPDF2"
                }
                
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def read_docx(
        self,
        file_path: str
    ) -> Dict[str, Any]:
        """读取 Word 文档"""
        try:
            try:
                from docx import Document
                
                doc = Document(file_path)
                
                paragraphs = []
                for para in doc.paragraphs:
                    if para.text.strip():
                        paragraphs.append(para.text)
                
                return {
                    "success": True,
                    "file": file_path,
                    "paragraph_count": len(paragraphs),
                    "content": "\n".join(paragraphs),
                }
                
            except ImportError:
                return {
                    "success": False,
                    "error": "需要安装 python-docx: pip install python-docx"
                }
                
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def read_xlsx(
        self,
        file_path: str,
        sheet_name: Optional[str] = None
    ) -> Dict[str, Any]:
        """读取 Excel 文件"""
        try:
            try:
                import openpyxl
                
                wb = openpyxl.load_workbook(file_path, data_only=True)
                
                if sheet_name:
                    ws = wb[sheet_name]
                else:
                    ws = wb.active
                
                # 读取所有数据
                data = []
                for row in ws.iter_rows(values_only=True):
                    if any(cell is not None for cell in row):
                        data.append(list(row))
                
                return {
                    "success": True,
                    "file": file_path,
                    "sheet": ws.title,
                    "row_count": len(data),
                    "column_count": len(data[0]) if data else 0,
                    "data": data[:100],  # 只返回前 100 行
                }
                
            except ImportError:
                return {
                    "success": False,
                    "error": "需要安装 openpyxl: pip install openpyxl"
                }
                
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def read_txt(
        self,
        file_path: str,
        encoding: str = "utf-8"
    ) -> Dict[str, Any]:
        """读取文本文件"""
        try:
            with open(file_path, "r", encoding=encoding) as f:
                content = f.read()
            
            return {
                "success": True,
                "file": file_path,
                "encoding": encoding,
                "line_count": content.count("\n") + 1,
                "content": content[:10000],  # 只返回前 10000 字符
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    # ========== 文件信息 ==========
    
    async def get_file_info(
        self,
        file_path: str
    ) -> Dict[str, Any]:
        """获取文件信息"""
        try:
            path = Path(file_path)
            
            if not path.exists():
                return {"success": False, "error": f"文件不存在：{file_path}"}
            
            stat = path.stat()
            
            return {
                "success": True,
                "path": str(path),
                "name": path.name,
                "size": stat.st_size,
                "size_kb": round(stat.st_size / 1024, 2),
                "size_mb": round(stat.st_size / (1024 * 1024), 2),
                "created": datetime.fromtimestamp(stat.st_ctime).isoformat(),
                "modified": datetime.fromtimestamp(stat.st_mtime).isoformat(),
                "accessed": datetime.fromtimestamp(stat.st_atime).isoformat(),
                "is_file": path.is_file(),
                "is_dir": path.is_dir(),
                "extension": path.suffix,
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}


# ========== 导出符号 ==========

__all__ = ["OfficeAutomationAgent"]
