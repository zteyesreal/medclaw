"""
MedClaw Computer-Use Agent
实现屏幕操作能力：截图、鼠标、键盘、窗口管理
"""

import asyncio
import pyautogui
import pygetwindow as gw
from typing import Dict, Any, Optional, Tuple, List
from datetime import datetime
import logging

from .base import BaseAgent, AgentCapability, AgentStatus

logger = logging.getLogger(__name__)


# 禁用 pyautogui 的安全暂停
pyautogui.FAILSAFE = True
pyautogui.PAUSE = 0.1


class ComputerUseAgent(BaseAgent):
    """Computer-Use Agent"""
    
    def __init__(self, agent_id: Optional[str] = None):
        super().__init__(agent_id)
        self.name = "ComputerUseAgent"
        
        # 注册能力
        self.capabilities = [
            AgentCapability(
                name="screen_capture",
                description="屏幕截图能力",
                parameters={"format": "png", "quality": "high"}
            ),
            AgentCapability(
                name="mouse_control",
                description="鼠标控制能力",
                parameters={"actions": ["click", "double_click", "right_click", "move", "drag"]}
            ),
            AgentCapability(
                name="keyboard_control",
                description="键盘控制能力",
                parameters={"actions": ["type", "press", "hotkey"]}
            ),
            AgentCapability(
                name="window_management",
                description="窗口管理能力",
                parameters={"actions": ["open", "close", "minimize", "maximize", "switch"]}
            ),
            AgentCapability(
                name="clipboard",
                description="剪贴板操作能力",
                parameters={"actions": ["copy", "paste"]}
            ),
        ]
        
        # 屏幕信息
        self.screen_width, self.screen_height = pyautogui.size()
    
    async def initialize(self) -> bool:
        """初始化"""
        logger.info(f"ComputerUseAgent {self.agent_id} 初始化")
        self.status = AgentStatus.IDLE
        self.last_active = datetime.now()
        return True
    
    async def execute(self, task: Any) -> Any:
        """执行任务"""
        self.status = AgentStatus.BUSY
        self.last_active = datetime.now()
        
        try:
            action = task.get("action")
            params = task.get("params", {})
            
            # 路由到具体方法
            if action == "screenshot":
                return await self.screenshot(**params)
            elif action == "click":
                return await self.click(**params)
            elif action == "double_click":
                return await self.double_click(**params)
            elif action == "right_click":
                return await self.right_click(**params)
            elif action == "move_mouse":
                return await self.move_mouse(**params)
            elif action == "drag_mouse":
                return await self.drag_mouse(**params)
            elif action == "type_text":
                return await self.type_text(**params)
            elif action == "press_key":
                return await self.press_key(**params)
            elif action == "hotkey":
                return await self.hotkey(**params)
            elif action == "open_application":
                return await self.open_application(**params)
            elif action == "close_window":
                return await self.close_window(**params)
            elif action == "switch_window":
                return await self.switch_window(**params)
            elif action == "get_mouse_position":
                return await self.get_mouse_position()
            elif action == "get_active_window":
                return await self.get_active_window()
            else:
                raise ValueError(f"未知操作：{action}")
                
        except Exception as e:
            logger.error(f"ComputerUseAgent 执行失败：{e}")
            raise e
        finally:
            self.status = AgentStatus.IDLE
            self.completed_tasks += 1
    
    async def cleanup(self) -> bool:
        """清理"""
        logger.info(f"ComputerUseAgent {self.agent_id} 清理完成")
        return True
    
    # ========== 屏幕截图 ==========
    
    async def screenshot(
        self,
        filename: Optional[str] = None,
        region: Optional[Tuple[int, int, int, int]] = None
    ) -> Dict[str, Any]:
        """
        屏幕截图
        
        Args:
            filename: 保存文件名（可选）
            region: 截图区域 (left, top, width, height)
            
        Returns:
            截图信息
        """
        try:
            screenshot = pyautogui.screenshot(region=region)
            
            if filename:
                screenshot.save(filename)
                logger.info(f"截图已保存：{filename}")
            
            return {
                "success": True,
                "filename": filename,
                "region": region,
                "size": screenshot.size,
                "timestamp": datetime.now().isoformat(),
            }
        except Exception as e:
            logger.error(f"截图失败：{e}")
            return {"success": False, "error": str(e)}
    
    # ========== 鼠标控制 ==========
    
    async def click(
        self,
        x: Optional[int] = None,
        y: Optional[int] = None,
        button: str = "left",
        clicks: int = 1,
        interval: float = 0.1
    ) -> Dict[str, Any]:
        """鼠标点击"""
        try:
            if x is not None and y is not None:
                pyautogui.click(x=x, y=y, button=button, clicks=clicks, interval=interval)
            else:
                pyautogui.click(button=button, clicks=clicks, interval=interval)
            
            return {"success": True, "action": "click", "button": button}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def double_click(
        self,
        x: Optional[int] = None,
        y: Optional[int] = None
    ) -> Dict[str, Any]:
        """鼠标双击"""
        return await self.click(x=x, y=y, button="left", clicks=2)
    
    async def right_click(
        self,
        x: Optional[int] = None,
        y: Optional[int] = None
    ) -> Dict[str, Any]:
        """鼠标右键"""
        return await self.click(x=x, y=y, button="right")
    
    async def move_mouse(
        self,
        x: int,
        y: int,
        duration: float = 0.5
    ) -> Dict[str, Any]:
        """移动鼠标"""
        try:
            pyautogui.moveTo(x=x, y=y, duration=duration)
            return {"success": True, "position": (x, y)}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def drag_mouse(
        self,
        start_x: int,
        start_y: int,
        end_x: int,
        end_y: int,
        duration: float = 0.5
    ) -> Dict[str, Any]:
        """拖动鼠标"""
        try:
            pyautogui.moveTo(start_x, start_y)
            pyautogui.drag(end_x - start_x, end_y - start_y, duration=duration)
            return {"success": True, "from": (start_x, start_y), "to": (end_x, end_y)}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def get_mouse_position(self) -> Dict[str, Any]:
        """获取鼠标位置"""
        pos = pyautogui.position()
        return {"success": True, "x": pos.x, "y": pos.y}
    
    # ========== 键盘控制 ==========
    
    async def type_text(
        self,
        text: str,
        interval: float = 0.1
    ) -> Dict[str, Any]:
        """输入文本"""
        try:
            pyautogui.write(text, interval=interval)
            return {"success": True, "text": text}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def press_key(
        self,
        key: str,
        presses: int = 1,
        interval: float = 0.1
    ) -> Dict[str, Any]:
        """按键"""
        try:
            pyautogui.press(key, presses=presses, interval=interval)
            return {"success": True, "key": key}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def hotkey(self, *keys: str) -> Dict[str, Any]:
        """快捷键"""
        try:
            pyautogui.hotkey(*keys)
            return {"success": True, "keys": keys}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    # ========== 窗口管理 ==========
    
    async def open_application(
        self,
        application: str
    ) -> Dict[str, Any]:
        """打开应用"""
        try:
            import subprocess
            subprocess.Popen(application)
            await asyncio.sleep(1)  # 等待应用启动
            return {"success": True, "application": application}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def close_window(
        self,
        window_title: Optional[str] = None
    ) -> Dict[str, Any]:
        """关闭窗口"""
        try:
            if window_title:
                windows = gw.getWindowsWithTitle(window_title)
                if windows:
                    windows[0].close()
            else:
                # 关闭活动窗口
                active_window = gw.getActiveWindow()
                if active_window:
                    active_window.close()
            
            return {"success": True, "window": window_title or "active"}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def switch_window(
        self,
        window_title: str
    ) -> Dict[str, Any]:
        """切换窗口"""
        try:
            windows = gw.getWindowsWithTitle(window_title)
            if windows:
                windows[0].activate()
                return {"success": True, "window": window_title}
            else:
                return {"success": False, "error": f"未找到窗口：{window_title}"}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def get_active_window(self) -> Dict[str, Any]:
        """获取活动窗口"""
        try:
            window = gw.getActiveWindow()
            if window:
                return {
                    "success": True,
                    "title": window.title,
                    "left": window.left,
                    "top": window.top,
                    "width": window.width,
                    "height": window.height,
                }
            else:
                return {"success": False, "error": "没有活动窗口"}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    # ========== 剪贴板操作 ==========
    
    async def clipboard_copy(
        self,
        text: str
    ) -> Dict[str, Any]:
        """复制到剪贴板"""
        try:
            import pyperclip
            pyperclip.copy(text)
            return {"success": True, "text": text}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def clipboard_paste(self) -> Dict[str, Any]:
        """从剪贴板粘贴"""
        try:
            import pyperclip
            text = pyperclip.paste()
            return {"success": True, "text": text}
        except Exception as e:
            return {"success": False, "error": str(e)}


# ========== 导出符号 ==========

__all__ = ["ComputerUseAgent"]
