"""
MedClaw Agent 基础框架
支持多 Agent 协作、任务分配、结果汇总
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Any, TypeVar, Generic
from enum import Enum
import asyncio
import logging
from datetime import datetime
import uuid

logger = logging.getLogger(__name__)


class AgentStatus(str, Enum):
    """Agent 状态"""
    IDLE = "idle"
    BUSY = "busy"
    ERROR = "error"
    OFFLINE = "offline"


class AgentCapability:
    """Agent 能力描述"""
    
    def __init__(self, name: str, description: str, parameters: Optional[Dict[str, Any]] = None):
        self.name = name
        self.description = description
        self.parameters = parameters or {}
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "parameters": self.parameters,
        }


class AgentMessage:
    """Agent 间通信消息"""
    
    def __init__(
        self,
        message_type: str,
        sender: str,
        receiver: str,
        content: Any,
        timestamp: Optional[str] = None,
    ):
        self.message_type = message_type  # "request", "response", "notification"
        self.sender = sender
        self.receiver = receiver
        self.content = content
        self.timestamp = timestamp or datetime.now().isoformat()
        self.id = str(uuid.uuid4())
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "type": self.message_type,
            "sender": self.sender,
            "receiver": self.receiver,
            "content": self.content,
            "timestamp": self.timestamp,
        }


class BaseAgent(ABC):
    """Agent 抽象基类"""
    
    def __init__(self, agent_id: Optional[str] = None):
        self.agent_id = agent_id or str(uuid.uuid4())
        self.name = self.__class__.__name__
        self.status = AgentStatus.IDLE
        self.capabilities: List[AgentCapability] = []
        self.current_task: Optional[Any] = None
        self.completed_tasks = 0
        self.failed_tasks = 0
        self.created_at = datetime.now()
        self.last_active = datetime.now()
    
    @abstractmethod
    async def initialize(self) -> bool:
        """
        初始化 Agent
        
        Returns:
            是否成功
        """
        pass
    
    @abstractmethod
    async def execute(self, task: Any) -> Any:
        """
        执行任务
        
        Args:
            task: 任务对象
            
        Returns:
            执行结果
        """
        pass
    
    @abstractmethod
    async def cleanup(self) -> bool:
        """
        清理资源
        
        Returns:
            是否成功
        """
        pass
    
    def get_status(self) -> Dict[str, Any]:
        """获取 Agent 状态"""
        return {
            "agent_id": self.agent_id,
            "name": self.name,
            "status": self.status.value,
            "capabilities": [cap.to_dict() for cap in self.capabilities],
            "current_task": self.current_task,
            "completed_tasks": self.completed_tasks,
            "failed_tasks": self.failed_tasks,
            "last_active": self.last_active.isoformat(),
        }
    
    def can_execute(self, task_type: str) -> bool:
        """
        判断是否能执行某类任务
        
        Args:
            task_type: 任务类型
            
        Returns:
            是否能执行
        """
        if self.status != AgentStatus.IDLE:
            return False
        
        return any(cap.name == task_type for cap in self.capabilities)


class AgentRegistry:
    """Agent 注册中心"""
    
    def __init__(self):
        self.agents: Dict[str, BaseAgent] = {}
        self.capability_index: Dict[str, List[str]] = {}  # capability -> [agent_ids]
    
    def register(self, agent: BaseAgent) -> bool:
        """注册 Agent"""
        if agent.agent_id in self.agents:
            logger.warning(f"Agent {agent.agent_id} 已存在")
            return False
        
        self.agents[agent.agent_id] = agent
        
        # 更新能力索引
        for cap in agent.capabilities:
            if cap.name not in self.capability_index:
                self.capability_index[cap.name] = []
            self.capability_index[cap.name].append(agent.agent_id)
        
        logger.info(f"已注册 Agent: {agent.agent_id} ({agent.name})")
        return True
    
    def unregister(self, agent_id: str) -> bool:
        """注销 Agent"""
        if agent_id not in self.agents:
            return False
        
        agent = self.agents[agent_id]
        
        # 从能力索引中移除
        for cap in agent.capabilities:
            if cap.name in self.capability_index:
                self.capability_index[cap.name].remove(agent_id)
        
        del self.agents[agent_id]
        logger.info(f"已注销 Agent: {agent_id}")
        return True
    
    def get_agent(self, agent_id: str) -> Optional[BaseAgent]:
        """获取 Agent"""
        return self.agents.get(agent_id)
    
    def find_agents_by_capability(self, capability: str) -> List[BaseAgent]:
        """根据能力查找 Agent"""
        agent_ids = self.capability_index.get(capability, [])
        return [self.agents[aid] for aid in agent_ids if aid in self.agents]
    
    def get_all_agents(self) -> List[BaseAgent]:
        """获取所有 Agent"""
        return list(self.agents.values())
    
    def get_idle_agents(self) -> List[BaseAgent]:
        """获取所有空闲 Agent"""
        return [a for a in self.agents.values() if a.status == AgentStatus.IDLE]


class AgentMessageBus:
    """Agent 消息总线"""
    
    def __init__(self):
        self.queues: Dict[str, asyncio.Queue] = {}
        self.subscribers: Dict[str, List[str]] = {}  # topic -> [agent_ids]
    
    def create_queue(self, agent_id: str):
        """为 Agent 创建消息队列"""
        if agent_id not in self.queues:
            self.queues[agent_id] = asyncio.Queue()
            logger.info(f"已为 Agent {agent_id} 创建消息队列")
    
    def remove_queue(self, agent_id: str):
        """移除 Agent 消息队列"""
        if agent_id in self.queues:
            del self.queues[agent_id]
    
    async def send_message(self, message: AgentMessage):
        """发送消息"""
        if message.receiver not in self.queues:
            logger.warning(f"Agent {message.receiver} 没有消息队列")
            return
        
        await self.queues[message.receiver].put(message)
        logger.debug(f"消息已发送：{message.id} -> {message.receiver}")
    
    async def broadcast(self, topic: str, content: Any, sender: Optional[str] = None):
        """广播消息"""
        subscribers = self.subscribers.get(topic, [])
        for agent_id in subscribers:
            if agent_id in self.queues:
                message = AgentMessage(
                    message_type="notification",
                    sender=sender or "system",
                    receiver=agent_id,
                    content=content,
                )
                await self.queues[agent_id].put(message)
    
    def subscribe(self, agent_id: str, topic: str):
        """订阅主题"""
        if topic not in self.subscribers:
            self.subscribers[topic] = []
        if agent_id not in self.subscribers[topic]:
            self.subscribers[topic].append(agent_id)
    
    def unsubscribe(self, agent_id: str, topic: str):
        """取消订阅"""
        if topic in self.subscribers:
            if agent_id in self.subscribers[topic]:
                self.subscribers[topic].remove(agent_id)
    
    async def receive_message(self, agent_id: str, timeout: Optional[float] = None) -> Optional[AgentMessage]:
        """接收消息"""
        if agent_id not in self.queues:
            return None
        
        try:
            if timeout:
                return await asyncio.wait_for(
                    self.queues[agent_id].get(),
                    timeout=timeout
                )
            else:
                return await self.queues[agent_id].get()
        except asyncio.TimeoutError:
            return None


class AgentCoordinator:
    """Agent 协调器"""
    
    def __init__(self):
        self.registry = AgentRegistry()
        self.message_bus = AgentMessageBus()
        self.task_assignments: Dict[str, str] = {}  # task_id -> agent_id
        self._running = False
    
    def register_agent(self, agent: BaseAgent) -> bool:
        """注册 Agent"""
        result = self.registry.register(agent)
        if result:
            self.message_bus.create_queue(agent.agent_id)
        return result
    
    def unregister_agent(self, agent_id: str) -> bool:
        """注销 Agent"""
        return self.registry.unregister(agent_id)
    
    async def assign_task(self, task: Any, required_capability: str) -> Optional[str]:
        """
        分配任务给合适的 Agent
        
        Args:
            task: 任务对象
            required_capability: 所需能力
            
        Returns:
            被分配的 Agent ID
        """
        # 查找有该能力的空闲 Agent
        agents = self.registry.find_agents_by_capability(required_capability)
        idle_agents = [a for a in agents if a.status == AgentStatus.IDLE]
        
        if not idle_agents:
            logger.warning(f"没有可用的 Agent 执行任务（需要能力：{required_capability}）")
            return None
        
        # 选择第一个空闲 Agent（可以优化为负载均衡）
        agent = idle_agents[0]
        agent.status = AgentStatus.BUSY
        agent.current_task = task
        
        task_id = getattr(task, 'id', str(uuid.uuid4()))
        self.task_assignments[task_id] = agent.agent_id
        
        logger.info(f"任务 {task_id} 已分配给 Agent {agent.agent_id}")
        return agent.agent_id
    
    async def execute_task(self, task: Any, required_capability: str) -> Any:
        """
        执行任务（分配并等待结果）
        
        Args:
            task: 任务对象
            required_capability: 所需能力
            
        Returns:
            执行结果
        """
        agent_id = await self.assign_task(task, required_capability)
        
        if not agent_id:
            raise RuntimeError(f"没有可用的 Agent 执行任务")
        
        agent = self.registry.get_agent(agent_id)
        if not agent:
            raise RuntimeError(f"Agent {agent_id} 不存在")
        
        try:
            result = await agent.execute(task)
            agent.completed_tasks += 1
            return result
        except Exception as e:
            agent.failed_tasks += 1
            raise e
        finally:
            agent.status = AgentStatus.IDLE
            agent.current_task = None
            task_id = getattr(task, 'id', None)
            if task_id and task_id in self.task_assignments:
                del self.task_assignments[task_id]
    
    async def broadcast_message(self, topic: str, content: Any, sender: Optional[str] = None):
        """广播消息"""
        await self.message_bus.broadcast(topic, content, sender)
    
    def get_agent_status(self, agent_id: str) -> Optional[Dict[str, Any]]:
        """获取 Agent 状态"""
        agent = self.registry.get_agent(agent_id)
        if agent:
            return agent.get_status()
        return None
    
    def get_all_agent_status(self) -> List[Dict[str, Any]]:
        """获取所有 Agent 状态"""
        return [agent.get_status() for agent in self.registry.get_all_agents()]
    
    async def start(self):
        """启动协调器"""
        self._running = True
        logger.info("Agent 协调器已启动")
    
    async def stop(self):
        """停止协调器"""
        self._running = False
        
        # 清理所有 Agent
        for agent in self.registry.get_all_agents():
            try:
                await agent.cleanup()
            except Exception as e:
                logger.error(f"清理 Agent {agent.agent_id} 失败：{e}")
        
        logger.info("Agent 协调器已停止")


# ========== 导出符号 ==========

__all__ = [
    "AgentStatus",
    "AgentCapability",
    "AgentMessage",
    "BaseAgent",
    "AgentRegistry",
    "AgentMessageBus",
    "AgentCoordinator",
]
