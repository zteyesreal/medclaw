"""
MedClaw 模块配置管理
为每个功能模块提供独立的配置管理
"""

from pydantic import BaseModel, Field
from typing import Dict, List, Optional, Any
import json
from pathlib import Path
import logging

logger = logging.getLogger(__name__)


# ========== 通用数据源配置 ==========

class DatabaseConnection(BaseModel):
    """数据库连接配置"""
    host: str = Field(default="localhost", description="主机地址")
    port: int = Field(default=1433, description="端口")
    database: str = Field(default="", description="数据库名")
    username: str = Field(default="", description="用户名")
    password: str = Field(default="", description="密码")
    driver: str = Field(default="mssql", description="驱动类型")
    charset: str = Field(default="utf8", description="字符集")
    
    @property
    def connection_string(self) -> str:
        if self.driver == "mssql":
            return f"mssql+pymssql://{self.username}:{self.password}@{self.host}:{self.port}/{self.database}?charset={self.charset}"
        elif self.driver == "mysql":
            return f"mysql+pymysql://{self.username}:{self.password}@{self.host}:{self.port}/{self.database}?charset={self.charset}"
        elif self.driver == "postgresql":
            return f"postgresql://{self.username}:{self.password}@{self.host}:{self.port}/{self.database}"
        else:
            return ""


class APIEndpoint(BaseModel):
    """API 端点配置"""
    name: str = Field(default="", description="端点名称")
    base_url: str = Field(default="", description="基础 URL")
    timeout: int = Field(default=30, description="超时时间（秒）")
    api_key: Optional[str] = Field(default=None, description="API 密钥")
    auth_type: str = Field(default="none", description="认证类型：none, basic, bearer, apikey")
    headers: Dict[str, str] = Field(default_factory=dict, description="自定义请求头")
    enabled: bool = Field(default=True, description="是否启用")


class HL7Connection(BaseModel):
    """HL7/FHIR 连接配置"""
    host: str = Field(default="localhost", description="主机地址")
    port: int = Field(default=2575, description="端口")
    sending_facility: str = Field(default="", description="发送机构")
    receiving_facility: str = Field(default="", description="接收机构")
    version: str = Field(default="2.5.1", description="HL7 版本")


# ========== 各模块专用配置 ==========

class EMRModuleConfig(BaseModel):
    """电子病历模块配置"""
    
    # HIS 系统对接
    his_enabled: bool = Field(default=True, description="启用 HIS 对接")
    his_database: DatabaseConnection = Field(default_factory=DatabaseConnection, description="HIS 数据库")
    his_api: APIEndpoint = Field(default_factory=APIEndpoint, description="HIS API")
    
    # LIS 系统对接
    lis_enabled: bool = Field(default=True, description="启用 LIS 对接")
    lis_database: DatabaseConnection = Field(default_factory=DatabaseConnection, description="LIS 数据库")
    lis_api: APIEndpoint = Field(default_factory=APIEndpoint, description="LIS API")
    
    # PACS 系统对接
    pacs_enabled: bool = Field(default=True, description="启用 PACS 对接")
    pacs_dicom_ae_title: str = Field(default="PACS", description="DICOM AE Title")
    pacs_dicom_port: int = Field(default=104, description="DICOM 端口")
    pacs_api: APIEndpoint = Field(default_factory=APIEndpoint, description="PACS API")
    
    # 病理系统对接
    pathology_enabled: bool = Field(default=True, description="启用病理系统")
    pathology_database: DatabaseConnection = Field(default_factory=DatabaseConnection, description="病理数据库")
    
    # 病历生成参数
    auto_generate: bool = Field(default=True, description="自动生成病历")
    template_engine: str = Field(default="jinja2", description="模板引擎")
    quality_check_enabled: bool = Field(default=True, description="启用质控检查")
    
    class Config:
        json_schema_extra = {
            "module_name": "电子病历生成引擎",
            "module_id": "emr_generation"
        }


class InsuranceModuleConfig(BaseModel):
    """医保合规模块配置"""
    
    # 医保前置机对接
    preprocessor_enabled: bool = Field(default=True, description="启用医保前置机")
    preprocessor_host: str = Field(default="localhost", description="前置机主机")
    preprocessor_port: int = Field(default=8080, description="前置机端口")
    preprocessor_api_key: str = Field(default="", description="前置机 API 密钥")
    
    # DRG/DIP 分组配置
    drg_enabled: bool = Field(default=True, description="启用 DRG 分组")
    drg_version: str = Field(default="CHS-DRG 1.1", description="DRG 版本")
    dip_enabled: bool = Field(default=True, description="启用 DIP 分组")
    dip_version: str = Field(default="国家版 2.0", description="DIP 版本")
    
    # 费用监控配置
    cost_monitoring_enabled: bool = Field(default=True, description="启用费用监控")
    cost_threshold: float = Field(default=10000.0, description="费用阈值")
    auto_alert: bool = Field(default=True, description="自动预警")
    
    # 规则引擎配置
    rule_engine_url: str = Field(default="http://localhost:8088", description="规则引擎 URL")
    rule_update_interval: int = Field(default=3600, description="规则更新间隔（秒）")
    
    class Config:
        json_schema_extra = {
            "module_name": "医保合规性智能评估平台",
            "module_id": "insurance_compliance"
        }


class RiskPredictionConfig(BaseModel):
    """临床风险预测模块配置"""
    
    # 数据源配置
    his_data_enabled: bool = Field(default=True, description="启用 HIS 数据")
    lis_data_enabled: bool = Field(default=True, description="启用 LIS 数据")
    pacs_data_enabled: bool = Field(default=True, description="启用 PACS 数据")
    emr_data_enabled: bool = Field(default=True, description="启用 EMR 数据")
    
    # 预测模型配置
    model_type: str = Field(default="ensemble", description="模型类型：logistic, random_forest, xgboost, ensemble")
    model_path: str = Field(default="models/risk_prediction", description="模型文件路径")
    confidence_threshold: float = Field(default=0.7, description="置信度阈值")
    
    # 风险类型配置
    sepsis_enabled: bool = Field(default=True, description="启用败血症风险预测")
    complication_enabled: bool = Field(default=True, description="启用并发症预测")
    readmission_enabled: bool = Field(default=True, description="启用再入院风险预测")
    mortality_enabled: bool = Field(default=True, description="启用死亡风险预测")
    
    # 预警配置
    alert_enabled: bool = Field(default=True, description="启用预警")
    alert_channels: List[str] = Field(default=["system", "sms"], description="预警渠道")
    alert_frequency: str = Field(default="realtime", description="预警频率：realtime, hourly, daily")
    
    class Config:
        json_schema_extra = {
            "module_name": "临床风险预测与决策支持系统",
            "module_id": "risk_prediction"
        }


class ImagingModuleConfig(BaseModel):
    """医学影像 AI 模块配置"""
    
    # PACS 对接配置
    pacs_dicom_ae_title: str = Field(default="AI_IMAGING", description="DICOM AE Title")
    pacs_dicom_host: str = Field(default="localhost", description="PACS 主机")
    pacs_dicom_port: int = Field(default=104, description="PACS 端口")
    pacs_wado_url: str = Field(default="http://localhost:8080/wado", description="WADO URL")
    
    # AI 模型配置
    model_provider: str = Field(default="local", description="模型提供商：local, azure, aws, custom")
    lung_nodule_enabled: bool = Field(default=True, description="启用肺结节检测")
    fracture_enabled: bool = Field(default=True, description="启用骨折检测")
    stroke_enabled: bool = Field(default=True, description="启用脑卒中检测")
    tumor_enabled: bool = Field(default=True, description="启用肿瘤检测")
    
    # 图像处理配置
    auto_preprocess: bool = Field(default=True, description="自动预处理")
    image_format: str = Field(default="dicom", description="图像格式：dicom, nifti, nrrd")
    gpu_enabled: bool = Field(default=True, description="启用 GPU 加速")
    batch_size: int = Field(default=4, description="批处理大小")
    
    # 报告生成配置
    auto_report: bool = Field(default=True, description="自动生成报告")
    report_template: str = Field(default="default", description="报告模板")
    include_measurements: bool = Field(default=True, description="包含测量数据")
    
    class Config:
        json_schema_extra = {
            "module_name": "医学影像 AI 辅助诊断平台",
            "module_id": "medical_imaging"
        }


class ResearchModuleConfig(BaseModel):
    """临床科研模块配置"""
    
    # 数据源配置
    data_sources: List[str] = Field(default=["his", "lis", "pacs", "emr"], description="数据源列表")
    data_warehouse_url: str = Field(default="http://localhost:9000", description="数据仓库 URL")
    
    # 统计分析配置
    stats_engine: str = Field(default="r", description="统计引擎：r, python, sas")
    r_server_url: str = Field(default="http://localhost:6311", description="R Server URL")
    python_env: str = Field(default="research_env", description="Python 环境")
    
    # 可视化配置
    chart_types: List[str] = Field(default=["bar", "line", "scatter", "heatmap", "survival"], description="支持的图表类型")
    export_formats: List[str] = Field(default=["png", "svg", "pdf", "html"], description="导出格式")
    
    # 论文支持配置
    reference_manager: str = Field(default="zotero", description="参考文献管理：zotero, endnote, mendeley")
    citation_style: str = Field(default="vancouver", description="引用格式")
    journal_templates: List[str] = Field(default_factory=list, description="期刊模板列表")
    
    class Config:
        json_schema_extra = {
            "module_name": "临床科研数据分析工作台",
            "module_id": "clinical_research"
        }


class LiteratureModuleConfig(BaseModel):
    """医学文献模块配置"""
    
    # 数据库对接配置
    pubmed_enabled: bool = Field(default=True, description="启用 PubMed")
    pubmed_api_key: str = Field(default="", description="PubMed API Key")
    cnki_enabled: bool = Field(default=True, description="启用 CNKI")
    wanfang_enabled: bool = Field(default=True, description="启用万方")
    vip_enabled: bool = Field(default=True, description="启用维普")
    
    # NLP 引擎配置
    nlp_provider: str = Field(default="local", description="NLP 提供商：local, azure, baidu, tencent")
    ner_enabled: bool = Field(default=True, description="启用命名实体识别")
    relation_extraction_enabled: bool = Field(default=True, description="启用关系抽取")
    summarization_enabled: bool = Field(default=True, description="启用自动摘要")
    
    # 知识库配置
    knowledge_base_url: str = Field(default="http://localhost:8888", description="知识库 URL")
    ontology_path: str = Field(default="data/ontology", description="本体库路径")
    auto_update: bool = Field(default=True, description="自动更新")
    
    class Config:
        json_schema_extra = {
            "module_name": "医学文献智能解读系统",
            "module_id": "literature_analysis"
        }


class QualityAuditConfig(BaseModel):
    """医疗质量审计模块配置"""
    
    # 质控规则配置
    rule_engine_url: str = Field(default="http://localhost:8088", description="规则引擎 URL")
    auto_audit: bool = Field(default=True, description="自动质控")
    audit_frequency: str = Field(default="daily", description="质控频率：realtime, hourly, daily, weekly")
    
    # 指标配置
    kpi_enabled: List[str] = Field(default=["diagnosis_accuracy", "treatment_timeliness", "complication_rate"], 
                                   description="启用的 KPI 指标")
    benchmark_values: Dict[str, float] = Field(default_factory=dict, description="基准值")
    
    # 报告配置
    report_format: str = Field(default="pdf", description="报告格式")
    auto_distribute: bool = Field(default=True, description="自动分发报告")
    distribution_list: List[str] = Field(default_factory=list, description="分发列表")
    
    class Config:
        json_schema_extra = {
            "module_name": "医疗质量智能审计系统",
            "module_id": "quality_audit"
        }


# ========== 配置管理器 ==========

class ModuleConfigManager:
    """模块配置管理器 - 单例模式"""
    
    _instance = None
    _configs: Dict[str, Any] = {}
    _config_file: Path = Path("config/modules_config.json")
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if not self._configs:
            self._init_default_configs()
    
    def _init_default_configs(self):
        """初始化默认配置"""
        self._configs = {
            "emr_generation": EMRModuleConfig(),
            "insurance_compliance": InsuranceModuleConfig(),
            "risk_prediction": RiskPredictionConfig(),
            "medical_imaging": ImagingModuleConfig(),
            "clinical_research": ResearchModuleConfig(),
            "literature_analysis": LiteratureModuleConfig(),
            "quality_audit": QualityAuditConfig(),
        }
    
    async def load(self, config_path: Optional[Path] = None) -> Dict[str, Any]:
        """加载配置"""
        if config_path:
            self._config_file = config_path
        
        if self._config_file.exists():
            try:
                with open(self._config_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                # 根据类型重建对象
                for module_id, config_data in data.items():
                    if module_id == "emr_generation":
                        self._configs[module_id] = EMRModuleConfig(**config_data)
                    elif module_id == "insurance_compliance":
                        self._configs[module_id] = InsuranceModuleConfig(**config_data)
                    elif module_id == "risk_prediction":
                        self._configs[module_id] = RiskPredictionConfig(**config_data)
                    elif module_id == "medical_imaging":
                        self._configs[module_id] = ImagingModuleConfig(**config_data)
                    elif module_id == "clinical_research":
                        self._configs[module_id] = ResearchModuleConfig(**config_data)
                    elif module_id == "literature_analysis":
                        self._configs[module_id] = LiteratureModuleConfig(**config_data)
                    elif module_id == "quality_audit":
                        self._configs[module_id] = QualityAuditConfig(**config_data)
                
                logger.info(f"模块配置加载成功：{self._config_file}")
            except Exception as e:
                logger.error(f"模块配置加载失败：{e}")
        else:
            logger.info("模块配置文件不存在，使用默认配置")
        
        return self._configs
    
    async def save(self, config_path: Optional[Path] = None) -> bool:
        """保存配置"""
        if config_path:
            self._config_file = config_path
        
        try:
            # 转换为字典
            data = {}
            for module_id, config in self._configs.items():
                data[module_id] = config.model_dump()
            
            # 确保目录存在
            self._config_file.parent.mkdir(parents=True, exist_ok=True)
            
            with open(self._config_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            
            logger.info(f"模块配置已保存：{self._config_file}")
            return True
        except Exception as e:
            logger.error(f"模块配置保存失败：{e}")
            return False
    
    def get_module_config(self, module_id: str) -> Any:
        """获取模块配置"""
        return self._configs.get(module_id)
    
    def update_module_config(self, module_id: str, config_data: Dict) -> bool:
        """更新模块配置"""
        if module_id not in self._configs:
            return False
        
        try:
            if module_id == "emr_generation":
                self._configs[module_id] = EMRModuleConfig(**config_data)
            elif module_id == "insurance_compliance":
                self._configs[module_id] = InsuranceModuleConfig(**config_data)
            elif module_id == "risk_prediction":
                self._configs[module_id] = RiskPredictionConfig(**config_data)
            elif module_id == "medical_imaging":
                self._configs[module_id] = ImagingModuleConfig(**config_data)
            elif module_id == "clinical_research":
                self._configs[module_id] = ResearchModuleConfig(**config_data)
            elif module_id == "literature_analysis":
                self._configs[module_id] = LiteratureModuleConfig(**config_data)
            elif module_id == "quality_audit":
                self._configs[module_id] = QualityAuditConfig(**config_data)
            
            return True
        except Exception as e:
            logger.error(f"更新模块配置失败：{e}")
            return False
    
    def get_all_configs(self) -> Dict[str, Any]:
        """获取所有配置"""
        return {
            module_id: config.model_dump() 
            for module_id, config in self._configs.items()
        }


# 全局配置管理器实例
module_config_manager = ModuleConfigManager()


__all__ = [
    # 配置类
    "DatabaseConnection",
    "APIEndpoint",
    "HL7Connection",
    "EMRModuleConfig",
    "InsuranceModuleConfig",
    "RiskPredictionConfig",
    "ImagingModuleConfig",
    "ResearchModuleConfig",
    "LiteratureModuleConfig",
    "QualityAuditConfig",
    # 管理器
    "ModuleConfigManager",
    "module_config_manager",
]
