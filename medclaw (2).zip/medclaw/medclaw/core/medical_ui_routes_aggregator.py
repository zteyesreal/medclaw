"""
MedClaw 医疗专用 UI API 路由聚合器
整合所有医疗模块的路由
"""

from fastapi import APIRouter, WebSocket, WebSocketDisconnect
import logging

from .medical_record_routes import router as medical_record_router
from .quality_insurance_prediction_routes import router as quality_insurance_router
from .imaging_research_paper_routes import router as imaging_research_router
from .medical_ui_websocket import manager

logger = logging.getLogger(__name__)

router = APIRouter()

router.include_router(medical_record_router)
router.include_router(quality_insurance_router)
router.include_router(imaging_research_router)


@router.get("/api/modules")
async def get_modules():
    """获取可用医疗模块列表"""
    return {
        "modules": [
            {
                "id": "medical_record",
                "name": "智能病历生成引擎",
                "description": "基于多模态数据融合的病历自动构建系统，支持实时语义理解与临床推理",
                "icon": "🧠",
                "color": "#6366F1"
            },
            {
                "id": "medical_quality",
                "name": "医疗质量智能审计系统",
                "description": "运用知识图谱技术的病历质控引擎，实现全方位医疗质量监控与风险预警",
                "icon": "🛡️",
                "color": "#EC4899"
            },
            {
                "id": "insurance_analysis",
                "name": "医保合规性智能评估平台",
                "description": "基于 DRG/DIP 分组的费用优化与风险管控系统，精准识别医保违规行为",
                "icon": "💎",
                "color": "#8B5CF6"
            },
            {
                "id": "clinical_prediction",
                "name": "临床风险预测与决策支持系统",
                "description": "融合深度学习与循证医学的智能预测引擎，提供精准风险评估与临床决策建议",
                "icon": "🔮",
                "color": "#F59E0B"
            },
            {
                "id": "ai_reading",
                "name": "医学影像 AI 辅助诊断平台",
                "description": "基于计算机视觉的影像智能分析系统，支持多模态影像识别与病灶自动检测",
                "icon": "👁️",
                "color": "#10B981"
            },
            {
                "id": "research_analysis",
                "name": "临床科研数据分析工作台",
                "description": "一站式统计分析与可视化平台，支持从数据清洗到论文图表的全流程科研服务",
                "icon": "📈",
                "color": "#3B82F6"
            },
            {
                "id": "paper_analysis",
                "name": "医学文献智能解读系统",
                "description": "基于 NLP 技术的文献自动解析引擎，实现关键信息提取与证据质量评价",
                "icon": "📚",
                "color": "#EF4444"
            }
        ]
    }


@router.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """WebSocket 连接"""
    await manager.connect(websocket)
    try:
        while True:
            data = await websocket.receive_json()
            logger.info(f"收到消息：{data}")
    except WebSocketDisconnect:
        manager.disconnect(websocket)
