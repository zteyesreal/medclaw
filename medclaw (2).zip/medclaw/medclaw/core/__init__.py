"""MedClaw 核心模块"""

# 基础核心（必须可用）
from .config import Config, ConfigManager, get_config_manager
from .mcp_client import MCPClient
from .module_base import ModuleBase
from .scheduler import TaskScheduler, Task, TaskStatus

# 监控和健康（必须可用）
from .monitor import SystemMonitor, get_monitor
from .health_check import HealthChecker, get_health_checker

# 可选功能（可能因依赖缺失不可用）
try:
    from .computer_use import ComputerUseAgent, get_computer_use_agent
    COMPUTER_USE_AVAILABLE = True
except ImportError:
    ComputerUseAgent = None
    get_computer_use_agent = None
    COMPUTER_USE_AVAILABLE = False

try:
    from .office_automation import OfficeAutomation, get_office_automation
    OFFICE_AUTOMATION_AVAILABLE = True
except ImportError:
    OfficeAutomation = None
    get_office_automation = None
    OFFICE_AUTOMATION_AVAILABLE = False

try:
    from .task_engine import AutonomousTaskEngine, get_autonomous_task_engine
    TASK_ENGINE_AVAILABLE = True
except ImportError:
    AutonomousTaskEngine = None
    get_autonomous_task_engine = None
    TASK_ENGINE_AVAILABLE = False

__all__ = [
    # 基础核心
    "Config",
    "ConfigManager",
    "get_config_manager",
    "MCPClient",
    "ModuleBase",
    "TaskScheduler",
    "Task",
    "TaskStatus",
    
    # 监控和健康
    "SystemMonitor",
    "get_monitor",
    "HealthChecker",
    "get_health_checker",
]

# 可选功能
if COMPUTER_USE_AVAILABLE:
    __all__.extend(["ComputerUseAgent", "get_computer_use_agent"])

if OFFICE_AUTOMATION_AVAILABLE:
    __all__.extend(["OfficeAutomation", "get_office_automation"])

if TASK_ENGINE_AVAILABLE:
    __all__.extend(["AutonomousTaskEngine", "get_autonomous_task_engine"])
