"""
MedClaw 医疗专用 UI HTML 模板（完整版）
功能完整的可操作界面 - 不受行数限制
"""

from .medical_ui_styles import get_medical_styles
from .medical_ui_scripts import get_medical_scripts


def get_enhanced_medical_html_template():
    """获取增强的医疗专用界面 HTML 模板（功能完整版）"""
    html_template = '''<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MedClaw - 医疗专用界面</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        STYLES_PLACEHOLDER
    </style>
</head>
<body class="bg-gray-100">
    <div id="app" class="min-h-screen">
        <!-- 顶部导航栏 -->
        <header class="gradient-bg text-white shadow-lg">
            <div class="container mx-auto px-4 py-6">
                <div class="flex items-center justify-between">
                    <div>
                        <h1 class="text-3xl font-bold">🏥 MedClaw 医疗专用界面</h1>
                        <p class="text-blue-100 mt-1">医学自动化助手 - 7×24 小时智能服务</p>
                    </div>
                    <div class="flex items-center space-x-4">
                        <button @click="currentPage = 'modules'" 
                                :class="['px-4 py-2 rounded-lg transition-colors', currentPage === 'modules' ? 'bg-white text-purple-600' : 'hover:bg-white hover:bg-opacity-20']">
                            <i class="fas fa-th-large mr-2"></i>功能模块
                        </button>
                        <button @click="currentPage = 'config'" 
                                :class="['px-4 py-2 rounded-lg transition-colors', currentPage === 'config' ? 'bg-white text-purple-600' : 'hover:bg-white hover:bg-opacity-20']">
                            <i class="fas fa-cog mr-2"></i>系统配置
                        </button>
                        <a href="/api/module-config/page" target="_blank"
                           class="px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-lg transition-colors">
                            <i class="fas fa-cogs mr-2"></i>模块配置
                        </a>
                        <a href="/api/settings/page" target="_blank"
                           class="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors">
                            <i class="fas fa-sliders-h mr-2"></i>统一设置
                        </a>
                        <div class="ml-4 text-right">
                            <div class="text-sm text-blue-100">系统状态</div>
                            <div class="flex items-center justify-end space-x-2">
                                <div class="w-3 h-3 bg-green-400 rounded-full pulse-dot"></div>
                                <span class="font-semibold">运行中</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- 主内容区 -->
        <main class="container mx-auto px-4 py-8">
            <!-- 功能模块页面 -->
            <div v-if="currentPage === 'modules'">
                <!-- 模块选择区 -->
                <section class="mb-8" v-if="!selectedModule">
                    <h2 class="text-2xl font-bold text-gray-800 mb-4">📋 医疗功能模块</h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                        <div v-for="module in modules" :key="module.id"
                             @click="selectModule(module)"
                             :class="['bg-white rounded-xl shadow-md p-6 cursor-pointer transition-all duration-300 card-hover',
                                      selectedModule?.id === module.id ? 'ring-2 ring-blue-500' : '']"
                             :style="'borderTop: 4px solid ' + module.color">
                            <div class="text-4xl mb-3">{{ module.icon }}</div>
                            <h3 class="text-xl font-bold text-gray-800 mb-2">{{ module.name }}</h3>
                            <p class="text-gray-600 text-sm">{{ module.description }}</p>
                        </div>
                    </div>
                </section>

                <!-- 模块详情和操作区 -->
                <section v-if="selectedModule" class="bg-white rounded-xl shadow-lg p-8">
                    <button @click="selectedModule = null; showForm = false; result = null" 
                            class="mb-4 text-blue-600 hover:text-blue-800 font-semibold">
                        <i class="fas fa-arrow-left mr-2"></i>返回模块选择
                    </button>
                    
                    <div class="mb-6">
                        <h2 class="text-2xl font-bold text-gray-800 mb-2">
                            <span class="text-3xl mr-2">{{ selectedModule.icon }}</span>
                            {{ selectedModule.name }}
                        </h2>
                        <p class="text-gray-600">{{ selectedModule.description }}</p>
                    </div>

                    <!-- 操作按钮 -->
                    <div class="mb-6">
                        <button @click="showForm = true" 
                                class="bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold">
                            <i class="fas fa-play-circle mr-2"></i>开始使用
                        </button>
                    </div>

                    <!-- 输入表单 -->
                    <div v-if="showForm" class="border-t pt-6">
                        <h3 class="text-lg font-bold text-gray-800 mb-4">📝 输入参数</h3>
                        
                        <!-- 病历书写表单 -->
                        <div v-if="selectedModule.id === 'medical_record'" class="space-y-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">患者姓名</label>
                                <input v-model="formData.patientName" type="text" class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500">
                            </div>
                            <div class="grid grid-cols-2 gap-4">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-1">性别</label>
                                    <select v-model="formData.patientGender" class="w-full px-3 py-2 border rounded-lg">
                                        <option value="">请选择</option>
                                        <option value="男">男</option>
                                        <option value="女">女</option>
                                    </select>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-1">年龄</label>
                                    <input v-model.number="formData.patientAge" type="number" class="w-full px-3 py-2 border rounded-lg">
                                </div>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">主诉</label>
                                <textarea v-model="formData.chiefComplaint" rows="3" class="w-full px-3 py-2 border rounded-lg" placeholder="患者主要症状..."></textarea>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">现病史</label>
                                <textarea v-model="formData.presentIllness" rows="4" class="w-full px-3 py-2 border rounded-lg" placeholder="疾病发展过程..."></textarea>
                            </div>
                            <div class="bg-blue-50 p-4 rounded-lg">
                                <p class="text-sm text-blue-800 font-semibold mb-2">💡 提示：支持检验检查结果</p>
                                <p class="text-xs text-blue-600">系统会自动分析血常规、生化、CT、MRI 等检验检查结果，并在病历中正确引用</p>
                            </div>
                            <button @click="executeMedicalRecord" :disabled="loading" 
                                    class="bg-green-500 hover:bg-green-600 text-white px-6 py-3 rounded-lg font-semibold disabled:opacity-50">
                                <i class="fas fa-spinner fa-spin mr-2" v-if="loading"></i>
                                <i class="fas fa-play mr-2" v-else></i>
                                {{ loading ? '生成中...' : '生成病历' }}
                            </button>
                        </div>

                        <!-- 病历质控表单 -->
                        <div v-if="selectedModule.id === 'medical_quality'" class="space-y-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">病历 ID</label>
                                <input v-model="formData.recordId" type="text" class="w-full px-3 py-2 border rounded-lg" placeholder="MR20240101001">
                            </div>
                            <div class="bg-blue-50 p-4 rounded-lg">
                                <p class="text-sm text-blue-800 font-semibold mb-2"> 质控内容</p>
                                <ul class="text-xs text-blue-600 list-disc list-inside space-y-1">
                                    <li>病历完整性检查</li>
                                    <li>及时性检查</li>
                                    <li>疾病编码 (ICD-10) 核对</li>
                                    <li>问题检测与反馈</li>
                                    <li>历史问题对比</li>
                                </ul>
                            </div>
                            <button @click="executeQualityCheck" :disabled="loading" 
                                    class="bg-green-500 hover:bg-green-600 text-white px-6 py-3 rounded-lg font-semibold disabled:opacity-50">
                                <i class="fas fa-spinner fa-spin mr-2" v-if="loading"></i>
                                <i class="fas fa-search mr-2" v-else></i>
                                {{ loading ? '质控中...' : '开始质控' }}
                            </button>
                        </div>

                        <!-- 医保分析表单 -->
                        <div v-if="selectedModule.id === 'insurance_analysis'" class="space-y-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">病历 ID</label>
                                <input v-model="formData.recordId" type="text" class="w-full px-3 py-2 border rounded-lg" placeholder="MR20240101001">
                            </div>
                            <div class="bg-blue-50 p-4 rounded-lg">
                                <p class="text-sm text-blue-800 font-semibold mb-2">💰 分析内容</p>
                                <ul class="text-xs text-blue-600 list-disc list-inside space-y-1">
                                    <li>DRG/DIP 分组</li>
                                    <li>费用结构分析</li>
                                    <li>高编风险检测</li>
                                    <li>医保政策符合性</li>
                                    <li>历史对比分析</li>
                                </ul>
                            </div>
                            <button @click="executeInsuranceAnalysis" :disabled="loading" 
                                    class="bg-green-500 hover:bg-green-600 text-white px-6 py-3 rounded-lg font-semibold disabled:opacity-50">
                                <i class="fas fa-spinner fa-spin mr-2" v-if="loading"></i>
                                <i class="fas fa-chart-line mr-2" v-else></i>
                                {{ loading ? '分析中...' : '开始分析' }}
                            </button>
                        </div>

                        <!-- 临床预测表单 -->
                        <div v-if="selectedModule.id === 'clinical_prediction'" class="space-y-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">预测模型</label>
                                <select v-model="formData.predictionType" class="w-full px-3 py-2 border rounded-lg">
                                    <option value="sepsis">脓毒症风险预测</option>
                                    <option value="cardiac">心脏事件预测</option>
                                    <option value="stroke">脑卒中预测</option>
                                </select>
                            </div>
                            <div class="grid grid-cols-2 gap-4">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-1">年龄</label>
                                    <input v-model.number="formData.age" type="number" class="w-full px-3 py-2 border rounded-lg">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-1">体温 (℃)</label>
                                    <input v-model.number="formData.temperature" type="number" step="0.1" class="w-full px-3 py-2 border rounded-lg">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-1">心率 (次/分)</label>
                                    <input v-model.number="formData.heartRate" type="number" class="w-full px-3 py-2 border rounded-lg">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-1">白细胞 (×10^9/L)</label>
                                    <input v-model.number="formData.wbc" type="number" step="0.1" class="w-full px-3 py-2 border rounded-lg">
                                </div>
                            </div>
                            <div class="bg-blue-50 p-4 rounded-lg">
                                <p class="text-sm text-blue-800 font-semibold mb-2">🔮 预测结果</p>
                                <p class="text-xs text-blue-600">基于深度学习模型，提供风险评分、风险分层和临床建议</p>
                            </div>
                            <button @click="executePrediction" :disabled="loading" 
                                    class="bg-green-500 hover:bg-green-600 text-white px-6 py-3 rounded-lg font-semibold disabled:opacity-50">
                                <i class="fas fa-spinner fa-spin mr-2" v-if="loading"></i>
                                <i class="fas fa-crystal-ball mr-2" v-else></i>
                                {{ loading ? '预测中...' : '开始预测' }}
                            </button>
                        </div>

                        <!-- AI 阅片表单 -->
                        <div v-if="selectedModule.id === 'ai_reading'" class="space-y-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">影像类型</label>
                                <select v-model="formData.imageType" class="w-full px-3 py-2 border rounded-lg">
                                    <option value="ct">CT</option>
                                    <option value="mri">MRI</option>
                                    <option value="xray">X 光</option>
                                    <option value="ultrasound">超声</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">影像路径/URL</label>
                                <input v-model="formData.imagePath" type="text" class="w-full px-3 py-2 border rounded-lg" placeholder="/path/to/image.dcm">
                            </div>
                            <div class="bg-blue-50 p-4 rounded-lg">
                                <p class="text-sm text-blue-800 font-semibold mb-2">👁️ AI 分析能力</p>
                                <ul class="text-xs text-blue-600 list-disc list-inside space-y-1">
                                    <li>病灶自动检测</li>
                                    <li>病灶测量和特征分析</li>
                                    <li>诊断建议生成</li>
                                    <li>报告自动生成</li>
                                </ul>
                            </div>
                            <button @click="executeAIReading" :disabled="loading" 
                                    class="bg-green-500 hover:bg-green-600 text-white px-6 py-3 rounded-lg font-semibold disabled:opacity-50">
                                <i class="fas fa-spinner fa-spin mr-2" v-if="loading"></i>
                                <i class="fas fa-eye mr-2" v-else></i>
                                {{ loading ? '分析中...' : '开始阅片' }}
                            </button>
                        </div>

                        <!-- 科研分析表单 -->
                        <div v-if="selectedModule.id === 'research_analysis'" class="space-y-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">分析类型</label>
                                <select v-model="formData.analysisType" class="w-full px-3 py-2 border rounded-lg">
                                    <option value="descriptive">描述性统计</option>
                                    <option value="comparative">组间比较</option>
                                    <option value="correlation">相关性分析</option>
                                    <option value="regression">回归分析</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">数据 (JSON 格式)</label>
                                <textarea v-model="formData.data" rows="6" class="w-full px-3 py-2 border rounded-lg font-mono text-sm" placeholder='{"group_a": [1,2,3], "group_b": [4,5,6]}'></textarea>
                            </div>
                            <div class="bg-blue-50 p-4 rounded-lg">
                                <p class="text-sm text-blue-800 font-semibold mb-2">📈 分析能力</p>
                                <ul class="text-xs text-blue-600 list-disc list-inside space-y-1">
                                    <li>描述性统计（均值、标准差等）</li>
                                    <li>组间比较（t 检验、方差分析）</li>
                                    <li>相关性分析（Pearson、Spearman）</li>
                                    <li>回归分析（线性、逻辑回归）</li>
                                    <li>图表自动生成</li>
                                </ul>
                            </div>
                            <button @click="executeResearchAnalysis" :disabled="loading" 
                                    class="bg-green-500 hover:bg-green-600 text-white px-6 py-3 rounded-lg font-semibold disabled:opacity-50">
                                <i class="fas fa-spinner fa-spin mr-2" v-if="loading"></i>
                                <i class="fas fa-chart-bar mr-2" v-else></i>
                                {{ loading ? '分析中...' : '开始分析' }}
                            </button>
                        </div>

                        <!-- 论文分析表单 -->
                        <div v-if="selectedModule.id === 'paper_analysis'" class="space-y-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">输入类型</label>
                                <select v-model="formData.inputType" class="w-full px-3 py-2 border rounded-lg">
                                    <option value="text">文本输入</option>
                                    <option value="url">URL 链接</option>
                                    <option value="doi">DOI 号</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">论文内容/URL/DOI</label>
                                <textarea v-model="formData.paperInput" rows="6" class="w-full px-3 py-2 border rounded-lg" placeholder="输入论文标题、摘要或全文..."></textarea>
                            </div>
                            <div class="bg-blue-50 p-4 rounded-lg">
                                <p class="text-sm text-blue-800 font-semibold mb-2">📚 分析能力</p>
                                <ul class="text-xs text-blue-600 list-disc list-inside space-y-1">
                                    <li>基本信息提取（标题、作者、期刊）</li>
                                    <li>研究方法提取</li>
                                    <li>关键发现总结</li>
                                    <li>质量评价</li>
                                    <li>证据等级评估</li>
                                </ul>
                            </div>
                            <button @click="executePaperAnalysis" :disabled="loading" 
                                    class="bg-green-500 hover:bg-green-600 text-white px-6 py-3 rounded-lg font-semibold disabled:opacity-50">
                                <i class="fas fa-spinner fa-spin mr-2" v-if="loading"></i>
                                <i class="fas fa-book-open mr-2" v-else></i>
                                {{ loading ? '分析中...' : '开始分析' }}
                            </button>
                        </div>
                    </div>

                    <!-- 执行过程日志 -->
                    <div v-if="logs.length > 0" class="border-t pt-6 mt-6">
                        <h3 class="text-lg font-bold text-gray-800 mb-4">📋 执行日志</h3>
                        <div class="bg-gray-900 text-green-400 p-4 rounded-lg font-mono text-xs max-h-64 overflow-y-auto">
                            <div v-for="(log, index) in logs" :key="index" class="mb-1">
                                <span class="text-gray-500">[{{ log.time }}]</span> {{ log.message }}
                            </div>
                        </div>
                    </div>

                    <!-- 执行结果 -->
                    <div v-if="result" class="border-t pt-6 mt-6">
                        <h3 class="text-lg font-bold text-gray-800 mb-4">📊 执行结果</h3>
                        <div :class="['p-4 rounded-lg', result.success ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200']">
                            <div class="flex items-start">
                                <i :class="['fas mr-2 mt-1', result.success ? 'fa-check-circle text-green-600' : 'fa-exclamation-circle text-red-600']"></i>
                                <div class="flex-1">
                                    <p class="font-semibold" :class="result.success ? 'text-green-800' : 'text-red-800'">
                                        {{ result.success ? '执行成功' : '执行失败' }}
                                    </p>
                                    <pre class="mt-2 text-sm overflow-auto max-h-96 bg-white p-3 rounded">{{ JSON.stringify(result.data || result.error, null, 2) }}</pre>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>

            <!-- 配置页面 -->
            <div v-if="currentPage === 'config'" class="space-y-8">
                <div class="bg-white rounded-xl shadow-lg p-8">
                    <h2 class="text-3xl font-bold text-gray-800 mb-6">⚙️ 系统配置</h2>
                    <p class="text-gray-600 mb-6">配置 MedClaw 运行参数，无需代码基础即可轻松设置</p>
                    
                    <div class="space-y-4">
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">应用名称</label>
                                <input v-model="config.app.name" type="text" class="w-full px-3 py-2 border rounded-lg">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">调试模式</label>
                                <select v-model="config.app.debug" class="w-full px-3 py-2 border rounded-lg">
                                    <option :value="false">关闭</option>
                                    <option :value="true">开启</option>
                                </select>
                            </div>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">数据库连接</label>
                            <input v-model="config.database.url" type="text" class="w-full px-3 py-2 border rounded-lg font-mono">
                        </div>

                        <div class="border-t pt-4">
                            <h3 class="text-lg font-semibold text-gray-800 mb-3">MCP 服务器配置</h3>
                            <div class="grid grid-cols-3 gap-4">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-1">服务器地址</label>
                                    <input v-model="config.mcp.server_url" type="text" class="w-full px-3 py-2 border rounded-lg">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-1">API Key</label>
                                    <input v-model="config.mcp.api_key" type="password" class="w-full px-3 py-2 border rounded-lg">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-1">超时时间 (秒)</label>
                                    <input v-model.number="config.mcp.timeout" type="number" class="w-full px-3 py-2 border rounded-lg">
                                </div>
                            </div>
                        </div>

                        <div class="flex gap-4 mt-6">
                            <button @click="validateConfig" class="bg-blue-500 hover:bg-blue-600 text-white px-6 py-2 rounded-lg">
                                <i class="fas fa-check mr-2"></i>验证配置
                            </button>
                            <button @click="saveConfig" class="bg-green-500 hover:bg-green-600 text-white px-6 py-2 rounded-lg">
                                <i class="fas fa-save mr-2"></i>保存配置
                            </button>
                            <button @click="resetConfig" class="bg-gray-500 hover:bg-gray-600 text-white px-6 py-2 rounded-lg">
                                <i class="fas fa-undo mr-2"></i>重置配置
                            </button>
                        </div>

                        <!-- 验证结果 -->
                        <div v-if="validationResult" class="mt-4 p-4 rounded-lg" :class="validationResult.valid ? 'bg-green-50 border border-green-200' : 'bg-yellow-50 border border-yellow-200'">
                            <p class="font-semibold" :class="validationResult.valid ? 'text-green-800' : 'text-yellow-800'">
                                {{ validationResult.valid ? '✓ 配置验证通过' : '⚠ 配置存在问题' }}
                            </p>
                            <pre class="mt-2 text-sm overflow-auto bg-white p-3 rounded">{{ JSON.stringify(validationResult, null, 2) }}</pre>
                        </div>

                        <!-- 保存结果 -->
                        <div v-if="saveResult" class="mt-4 p-4 rounded-lg" :class="saveResult.success ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'">
                            <p :class="saveResult.success ? 'text-green-800' : 'text-red-800'">
                                {{ saveResult.message || saveResult.detail }}
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </main>

        <!-- 页脚 -->
        <footer class="bg-gray-800 text-white py-6 mt-8">
            <div class="container mx-auto px-4 text-center">
                <p>MedClaw v1.0.0 - 医疗专业版 AI 助手</p>
                <p class="text-gray-400 text-sm mt-2">Powered by OpenClaw + Medical Modules</p>
            </div>
        </footer>
    </div>

    <script>
        SCRIPTS_PLACEHOLDER
    </script>
</body>
</html>'''
    
    return html_template.replace('STYLES_PLACEHOLDER', get_medical_styles()).replace('SCRIPTS_PLACEHOLDER', get_medical_scripts())
