"""
任务自主拆解引擎
Goal-Driven 自主任务规划、多步骤任务自动执行
"""

import asyncio
import json
from datetime import datetime
from typing import Dict, List, Optional, Any, Callable
from enum import Enum
import logging

logger = logging.getLogger(__name__)


class TaskStatus(Enum):
    """任务状态"""
    PENDING = "pending"
    PLANNING = "planning"
    EXECUTING = "executing"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class Task:
    """任务类"""
    
    def __init__(self, task_id: str, goal: str, parent_id: Optional[str] = None):
        self.task_id = task_id
        self.goal = goal
        self.parent_id = parent_id
        self.subtasks: List[Task] = []
        self.status = TaskStatus.PENDING
        self.result: Optional[str] = None
        self.error: Optional[str] = None
        self.created_at = datetime.now()
        self.started_at: Optional[datetime] = None
        self.completed_at: Optional[datetime] = None
        self.steps: List[Dict[str, Any]] = []
        self.current_step = 0
    
    def add_subtask(self, subtask: 'Task'):
        """添加子任务"""
        self.subtasks.append(subtask)
        subtask.parent_id = self.task_id
    
    def add_step(self, step: Dict[str, Any]):
        """添加执行步骤"""
        self.steps.append(step)
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "task_id": self.task_id,
            "goal": self.goal,
            "status": self.status.value,
            "subtasks": [st.to_dict() for st in self.subtasks],
            "steps": self.steps,
            "current_step": self.current_step,
            "result": self.result,
            "error": self.error,
            "created_at": self.created_at.isoformat(),
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
        }


class TaskPlanner:
    """任务规划器"""
    
    def __init__(self, mcp_client=None):
        self.mcp_client = mcp_client
        logger.info("任务规划器已初始化")
    
    async def decompose_goal(self, goal: str) -> List[Dict[str, Any]]:
        """
        将目标拆解为可执行的步骤
        
        Args:
            goal: 目标描述
            
        Returns:
            步骤列表
        """
        if self.mcp_client:
            # 使用 MCP/AI 进行智能拆解
            prompt = f"""请将以下目标拆解为具体的执行步骤：

目标：{goal}

要求：
1. 每个步骤都应该是可执行的原子操作
2. 步骤之间应该有清晰的依赖关系
3. 返回 JSON 格式的步骤列表

示例格式：
[
  {{"action": "open_application", "params": {{"app": "Chrome"}}}},
  {{"action": "navigate_to", "params": {{"url": "https://example.com"}}}},
  {{"action": "click", "params": {{"element": "button#submit"}}}}
]"""
            
            response = await self.mcp_client.query(prompt)
            try:
                steps = json.loads(response)
                logger.info(f"AI 拆解目标为 {len(steps)} 个步骤")
                return steps
            except:
                pass
        
        # 默认拆解逻辑
        return self._simple_decompose(goal)
    
    def _simple_decompose(self, goal: str) -> List[Dict[str, Any]]:
        """简单拆解逻辑"""
        goal_lower = goal.lower()
        
        if "整理" in goal and "文件" in goal:
            return [
                {"action": "organize_files", "params": {}},
                {"action": "report_result", "params": {"message": "文件整理完成"}}
            ]
        elif "邮件" in goal:
            return [
                {"action": "check_emails", "params": {}},
                {"action": "organize_emails", "params": {}},
                {"action": "report_result", "params": {"message": "邮件处理完成"}}
            ]
        elif "搜索" in goal:
            return [
                {"action": "search_files", "params": {"pattern": goal}},
                {"action": "report_result", "params": {"message": "搜索完成"}}
            ]
        else:
            return [
                {"action": "execute_custom", "params": {"goal": goal}}
            ]


class TaskExecutor:
    """任务执行器"""
    
    def __init__(self, computer_use_agent=None, office_automation=None):
        self.computer_use = computer_use_agent
        self.office = office_automation
        self.actions: Dict[str, Callable] = self._register_actions()
        logger.info("任务执行器已初始化")
    
    def _register_actions(self) -> Dict[str, Callable]:
        """注册可用的操作"""
        return {
            "open_application": self._open_application,
            "click": self._click,
            "type_text": self._type_text,
            "press_key": self._press_key,
            "hotkey": self._hotkey,
            "navigate_to": self._navigate_to,
            "organize_files": self._organize_files,
            "search_files": self._search_files,
            "check_emails": self._check_emails,
            "execute_custom": self._execute_custom,
            "report_result": self._report_result,
            "wait": self._wait,
        }
    
    async def execute_step(self, step: Dict[str, Any]) -> Any:
        """执行单个步骤"""
        action_name = step.get("action")
        params = step.get("params", {})
        
        if action_name not in self.actions:
            logger.error(f"未知操作：{action_name}")
            return None
        
        action_func = self.actions[action_name]
        
        try:
            logger.info(f"执行操作：{action_name}")
            if asyncio.iscoroutinefunction(action_func):
                result = await action_func(**params)
            else:
                result = action_func(**params)
            return result
        except Exception as e:
            logger.error(f"执行操作失败：{e}")
            raise
    
    # ========== 具体操作实现 ==========
    
    def _open_application(self, app: str):
        """打开应用"""
        if self.computer_use:
            self.computer_use.open_application(app)
    
    def _click(self, x: int, y: int, button: str = "left"):
        """点击"""
        if self.computer_use:
            self.computer_use.click(x, y, button)
    
    def _type_text(self, text: str):
        """输入文本"""
        if self.computer_use:
            self.computer_use.type_text(text)
    
    def _press_key(self, key: str):
        """按键"""
        if self.computer_use:
            self.computer_use.press_key(key)
    
    def _hotkey(self, keys: List[str]):
        """快捷键"""
        if self.computer_use:
            self.computer_use.hotkey(*keys)
    
    def _navigate_to(self, url: str, browser: str = "chrome"):
        """打开网页"""
        if self.office:
            self.office.open_browser(url, browser)
    
    def _organize_files(self, **kwargs):
        """整理文件"""
        if self.office:
            return self.office.organize_files(**kwargs)
    
    def _search_files(self, pattern: str, **kwargs):
        """搜索文件"""
        if self.office:
            return self.office.search_files(pattern, **kwargs)
    
    def _check_emails(self):
        """检查邮件"""
        if self.office:
            return self.office.organize_emails()
    
    def _execute_custom(self, goal: str):
        """执行自定义任务"""
        logger.info(f"执行自定义任务：{goal}")
        # 这里可以调用 AI 进行更复杂的操作
    
    def _report_result(self, message: str):
        """报告结果"""
        logger.info(f"任务结果：{message}")
        return message
    
    def _wait(self, seconds: int):
        """等待"""
        import time
        time.sleep(seconds)


class AutonomousTaskEngine:
    """自主任务引擎"""
    
    def __init__(self, mcp_client=None, computer_use_agent=None, office_automation=None):
        self.planner = TaskPlanner(mcp_client)
        self.executor = TaskExecutor(computer_use_agent, office_automation)
        self.tasks: Dict[str, Task] = {}
        self.running = False
        logger.info("自主任务引擎已初始化")
    
    async def create_task(self, goal: str) -> Task:
        """
        创建任务
        
        Args:
            goal: 任务目标
            
        Returns:
            任务对象
        """
        task_id = f"task_{datetime.now().strftime('%Y%m%d%H%M%S')}"
        task = Task(task_id, goal)
        
        # 拆解目标
        task.status = TaskStatus.PLANNING
        steps = await self.planner.decompose_goal(goal)
        
        for step in steps:
            task.add_step(step)
        
        self.tasks[task_id] = task
        logger.info(f"创建任务：{task_id}, 共 {len(steps)} 个步骤")
        
        return task
    
    async def execute_task(self, task_id: str) -> Optional[str]:
        """
        执行任务
        
        Args:
            task_id: 任务 ID
            
        Returns:
            执行结果
        """
        if task_id not in self.tasks:
            logger.error(f"任务不存在：{task_id}")
            return None
        
        task = self.tasks[task_id]
        task.status = TaskStatus.EXECUTING
        task.started_at = datetime.now()
        
        self.running = True
        
        try:
            result = None
            for i, step in enumerate(task.steps):
                if not self.running:
                    task.status = TaskStatus.CANCELLED
                    logger.info("任务已取消")
                    return None
                
                task.current_step = i
                logger.info(f"执行步骤 {i+1}/{len(task.steps)}")
                
                result = await self.executor.execute_step(step)
                
                # 步骤间短暂等待
                await asyncio.sleep(0.5)
            
            task.status = TaskStatus.COMPLETED
            task.result = str(result) if result else "任务完成"
            task.completed_at = datetime.now()
            
            logger.info(f"任务完成：{task_id}")
            return task.result
            
        except Exception as e:
            task.status = TaskStatus.FAILED
            task.error = str(e)
            task.completed_at = datetime.now()
            logger.error(f"任务失败：{e}")
            return None
    
    async def execute_goal(self, goal: str) -> Optional[str]:
        """
        执行目标（创建并执行任务）
        
        Args:
            goal: 目标描述
            
        Returns:
            执行结果
        """
        task = await self.create_task(goal)
        return await self.execute_task(task.task_id)
    
    def cancel_task(self, task_id: str):
        """取消任务"""
        self.running = False
        if task_id in self.tasks:
            self.tasks[task_id].status = TaskStatus.CANCELLED
            logger.info(f"任务已取消：{task_id}")
    
    def get_task_status(self, task_id: str) -> Optional[Dict[str, Any]]:
        """获取任务状态"""
        if task_id in self.tasks:
            return self.tasks[task_id].to_dict()
        return None
    
    def get_all_tasks(self) -> List[Dict[str, Any]]:
        """获取所有任务"""
        return [task.to_dict() for task in self.tasks.values()]


# 全局实例
autonomous_task_engine = AutonomousTaskEngine()


def get_autonomous_task_engine() -> AutonomousTaskEngine:
    """获取自主任务引擎实例"""
    return autonomous_task_engine
