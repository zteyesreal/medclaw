"""
MedClaw MCP 客户端
实现 Model Context Protocol，支持工具调用、资源访问、提示词模板
"""

import asyncio
import json
from typing import Dict, List, Optional, Any, Callable, Union
from datetime import datetime
import logging
import uuid
from enum import Enum

logger = logging.getLogger(__name__)


class MCPMessageType(str, Enum):
    """MCP 消息类型"""
    REQUEST = "request"
    RESPONSE = "response"
    NOTIFICATION = "notification"
    ERROR = "error"


class MCPError(Exception):
    """MCP 错误"""
    def __init__(self, code: int, message: str, data: Optional[Any] = None):
        self.code = code
        self.message = message
        self.data = data
        super().__init__(message)


# MCP 标准错误码
class MCPErrorCode:
    PARSE_ERROR = -32700
    INVALID_REQUEST = -32600
    METHOD_NOT_FOUND = -32601
    INVALID_PARAMS = -32602
    INTERNAL_ERROR = -32603
    TOOL_NOT_FOUND = -32001
    RESOURCE_NOT_FOUND = -32002


class MCPTool:
    """MCP 工具定义"""
    
    def __init__(
        self,
        name: str,
        description: str,
        input_schema: Dict[str, Any],
        handler: Optional[Callable] = None
    ):
        self.name = name
        self.description = description
        self.input_schema = input_schema
        self.handler = handler
        self.enabled = True
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "inputSchema": self.input_schema,
        }
    
    async def execute(self, **kwargs) -> Any:
        """执行工具"""
        if not self.enabled:
            raise MCPError(MCPErrorCode.TOOL_NOT_FOUND, f"工具 {self.name} 已禁用")
        
        if not self.handler:
            raise MCPError(MCPErrorCode.INTERNAL_ERROR, f"工具 {self.name} 没有处理器")
        
        # 验证参数
        self._validate_input(kwargs)
        
        # 执行处理器
        if asyncio.iscoroutinefunction(self.handler):
            return await self.handler(**kwargs)
        else:
            return self.handler(**kwargs)
    
    def _validate_input(self, params: Dict[str, Any]):
        """验证输入参数"""
        if not self.input_schema:
            return
        
        required = self.input_schema.get("required", [])
        properties = self.input_schema.get("properties", {})
        
        for param_name in required:
            if param_name not in params:
                raise MCPError(
                    MCPErrorCode.INVALID_PARAMS,
                    f"缺少必需参数：{param_name}"
                )
        
        # 类型检查（简化版）
        for param_name, param_value in params.items():
            if param_name in properties:
                expected_type = properties[param_name].get("type")
                if expected_type == "string" and not isinstance(param_value, str):
                    raise MCPError(
                        MCPErrorCode.INVALID_PARAMS,
                        f"参数 {param_name} 应该是字符串类型"
                    )
                elif expected_type == "integer" and not isinstance(param_value, int):
                    raise MCPError(
                        MCPErrorCode.INVALID_PARAMS,
                        f"参数 {param_name} 应该是整数类型"
                    )
                elif expected_type == "boolean" and not isinstance(param_value, bool):
                    raise MCPError(
                        MCPErrorCode.INVALID_PARAMS,
                        f"参数 {param_name} 应该是布尔类型"
                    )
                elif expected_type == "array" and not isinstance(param_value, list):
                    raise MCPError(
                        MCPErrorCode.INVALID_PARAMS,
                        f"参数 {param_name} 应该是数组类型"
                    )
                elif expected_type == "object" and not isinstance(param_value, dict):
                    raise MCPError(
                        MCPErrorCode.INVALID_PARAMS,
                        f"参数 {param_name} 应该是对象类型"
                    )


class MCPResource:
    """MCP 资源定义"""
    
    def __init__(
        self,
        uri: str,
        name: str,
        description: str,
        mime_type: str = "text/plain",
        content_provider: Optional[Callable] = None
    ):
        self.uri = uri
        self.name = name
        self.description = description
        self.mime_type = mime_type
        self.content_provider = content_provider
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "uri": self.uri,
            "name": self.name,
            "description": self.description,
            "mimeType": self.mime_type,
        }
    
    async def get_content(self) -> str:
        """获取资源内容"""
        if not self.content_provider:
            raise MCPError(MCPErrorCode.RESOURCE_NOT_FOUND, f"资源 {self.uri} 没有内容提供者")
        
        if asyncio.iscoroutinefunction(self.content_provider):
            return await self.content_provider()
        else:
            return self.content_provider()


class MCPPromptTemplate:
    """MCP 提示词模板"""
    
    def __init__(
        self,
        name: str,
        description: str,
        template: str,
        arguments: Optional[List[Dict[str, Any]]] = None
    ):
        self.name = name
        self.description = description
        self.template = template
        self.arguments = arguments or []
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "arguments": self.arguments,
        }
    
    def render(self, **kwargs) -> str:
        """渲染模板"""
        result = self.template
        for key, value in kwargs.items():
            result = result.replace(f"{{{key}}}", str(value))
        return result


class MCPClient:
    """MCP 客户端"""
    
    def __init__(
        self,
        client_id: Optional[str] = None,
        server_url: Optional[str] = None,
        api_key: Optional[str] = None,
        timeout: int = 30
    ):
        self.client_id = client_id or str(uuid.uuid4())
        self.server_url = server_url
        self.api_key = api_key
        self.timeout = timeout
        self.tools: Dict[str, MCPTool] = {}
        self.resources: Dict[str, MCPResource] = {}
        self.prompt_templates: Dict[str, MCPPromptTemplate] = {}
        self.initialized = False
        self.server_capabilities: Dict[str, Any] = {}
        self.orchestrator = None
        
        logger.info(f"MCP 客户端已创建：{self.client_id}")
    
    def register_tool(
        self,
        name: str,
        description: str,
        input_schema: Dict[str, Any],
        handler: Callable
    ) -> MCPTool:
        """注册工具"""
        tool = MCPTool(name, description, input_schema, handler)
        self.tools[name] = tool
        logger.info(f"已注册 MCP 工具：{name}")
        return tool
    
    def register_resource(
        self,
        uri: str,
        name: str,
        description: str,
        mime_type: str,
        content_provider: Callable
    ) -> MCPResource:
        """注册资源"""
        resource = MCPResource(uri, name, description, mime_type, content_provider)
        self.resources[uri] = resource
        logger.info(f"已注册 MCP 资源：{uri}")
        return resource
    
    def register_prompt_template(
        self,
        name: str,
        description: str,
        template: str,
        arguments: Optional[List[Dict[str, Any]]] = None
    ) -> MCPPromptTemplate:
        """注册提示词模板"""
        prompt = MCPPromptTemplate(name, description, template, arguments)
        self.prompt_templates[name] = prompt
        logger.info(f"已注册 MCP 提示词模板：{name}")
        return prompt
    
    async def initialize(self, server_capabilities: Optional[Dict[str, Any]] = None):
        """初始化客户端"""
        self.server_capabilities = server_capabilities or {}
        self.initialized = True
        logger.info("MCP 客户端已初始化")
    
    async def call_tool(self, tool_name: str, **kwargs) -> Any:
        """
        调用工具
        
        Args:
            tool_name: 工具名称
            **kwargs: 工具参数
            
        Returns:
            工具执行结果
        """
        if not self.initialized:
            raise MCPError(MCPErrorCode.INTERNAL_ERROR, "MCP 客户端未初始化")
        
        if tool_name not in self.tools:
            raise MCPError(MCPErrorCode.TOOL_NOT_FOUND, f"工具不存在：{tool_name}")
        
        tool = self.tools[tool_name]
        
        try:
            result = await tool.execute(**kwargs)
            logger.info(f"工具调用成功：{tool_name}")
            return result
        except MCPError:
            raise
        except Exception as e:
            logger.error(f"工具调用失败：{tool_name}, 错误：{e}")
            raise MCPError(MCPErrorCode.INTERNAL_ERROR, str(e))
    
    async def call_tool_with_orchestration(
        self,
        tool_name: str,
        enable_orchestration: bool = True,
        bypass_cache: bool = False,
        bypass_permission: bool = False,
        **kwargs
    ) -> Any:
        """
        带编排的工具调用
        
        Args:
            tool_name: 工具名称
            enable_orchestration: 是否启用编排
            bypass_cache: 是否绕过缓存
            bypass_permission: 是否绕过权限检查
            **kwargs: 工具参数
            
        Returns:
            工具执行结果
        """
        if not enable_orchestration:
            return await self.call_tool(tool_name, **kwargs)
        
        if not self.initialized:
            raise MCPError(MCPErrorCode.INTERNAL_ERROR, "MCP 客户端未初始化")
        
        if tool_name not in self.tools:
            raise MCPError(MCPErrorCode.TOOL_NOT_FOUND, f"工具不存在：{tool_name}")
        
        if self.orchestrator is None:
            from medclaw.core.tool_orchestrator import ToolOrchestrator
            self.orchestrator = ToolOrchestrator(self)
        
        try:
            result = await self.orchestrator.execute_tool(
                tool_name=tool_name,
                bypass_cache=bypass_cache,
                bypass_permission=bypass_permission,
                **kwargs
            )
            logger.info(f"编排工具调用成功：{tool_name}")
            return result
        except Exception as e:
            logger.error(f"编排工具调用失败：{tool_name}, 错误：{e}")
            raise
    
    async def get_resource(self, uri: str) -> str:
        """获取资源"""
        if not self.initialized:
            raise MCPError(MCPErrorCode.INTERNAL_ERROR, "MCP 客户端未初始化")
        
        if uri not in self.resources:
            raise MCPError(MCPErrorCode.RESOURCE_NOT_FOUND, f"资源不存在：{uri}")
        
        resource = self.resources[uri]
        
        try:
            content = await resource.get_content()
            logger.info(f"资源获取成功：{uri}")
            return content
        except MCPError:
            raise
        except Exception as e:
            logger.error(f"资源获取失败：{uri}, 错误：{e}")
            raise MCPError(MCPErrorCode.INTERNAL_ERROR, str(e))
    
    def render_prompt(self, template_name: str, **kwargs) -> str:
        """渲染提示词模板"""
        if template_name not in self.prompt_templates:
            raise MCPError(MCPErrorCode.INVALID_PARAMS, f"提示词模板不存在：{template_name}")
        
        prompt = self.prompt_templates[template_name]
        return prompt.render(**kwargs)
    
    def list_tools(self) -> List[Dict[str, Any]]:
        """列出所有工具"""
        return [tool.to_dict() for tool in self.tools.values() if tool.enabled]
    
    def list_resources(self) -> List[Dict[str, Any]]:
        """列出所有资源"""
        return [resource.to_dict() for resource in self.resources.values()]
    
    def list_prompt_templates(self) -> List[Dict[str, Any]]:
        """列出所有提示词模板"""
        return [prompt.to_dict() for prompt in self.prompt_templates.values()]
    
    def enable_tool(self, tool_name: str) -> bool:
        """启用工具"""
        if tool_name in self.tools:
            self.tools[tool_name].enabled = True
            logger.info(f"工具已启用：{tool_name}")
            return True
        return False
    
    def disable_tool(self, tool_name: str) -> bool:
        """禁用工具"""
        if tool_name in self.tools:
            self.tools[tool_name].enabled = False
            logger.info(f"工具已禁用：{tool_name}")
            return True
        return False
    
    def unregister_tool(self, tool_name: str) -> bool:
        """注销工具"""
        if tool_name in self.tools:
            del self.tools[tool_name]
            logger.info(f"工具已注销：{tool_name}")
            return True
        return False
    
    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        return {
            "client_id": self.client_id,
            "initialized": self.initialized,
            "tools_count": len(self.tools),
            "resources_count": len(self.resources),
            "prompt_templates_count": len(self.prompt_templates),
            "enabled_tools_count": sum(1 for t in self.tools.values() if t.enabled),
        }


class MCPMessageBuilder:
    """MCP 消息构建器"""
    
    @staticmethod
    def create_request(
        method: str,
        params: Optional[Dict[str, Any]] = None,
        request_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """创建请求消息"""
        return {
            "jsonrpc": "2.0",
            "id": request_id or str(uuid.uuid4()),
            "method": method,
            "params": params or {},
        }
    
    @staticmethod
    def create_response(
        result: Any,
        request_id: str
    ) -> Dict[str, Any]:
        """创建响应消息"""
        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "result": result,
        }
    
    @staticmethod
    def create_error(
        code: int,
        message: str,
        request_id: Optional[str] = None,
        data: Optional[Any] = None
    ) -> Dict[str, Any]:
        """创建错误消息"""
        error = {
            "jsonrpc": "2.0",
            "id": request_id,
            "error": {
                "code": code,
                "message": message,
            }
        }
        if data:
            error["error"]["data"] = data
        return error
    
    @staticmethod
    def create_notification(
        method: str,
        params: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """创建通知消息"""
        return {
            "jsonrpc": "2.0",
            "method": method,
            "params": params or {},
        }


# ========== 导出符号 ==========

__all__ = [
    "MCPClient",
    "MCPTool",
    "MCPResource",
    "MCPPromptTemplate",
    "MCPMessageBuilder",
    "MCPError",
    "MCPErrorCode",
    "MCPMessageType",
]
