"""
配置管理模块
负责加载和验证配置文件
"""

import yaml
from pathlib import Path
from typing import Any, Dict, Optional
from pydantic import BaseModel, Field


class AppConfig(BaseModel):
    """应用配置"""
    name: str = "MedClaw"
    debug: bool = False


class DatabaseConfig(BaseModel):
    """数据库配置"""
    url: str = "sqlite:///./medclaw.db"


class MCPConfig(BaseModel):
    """MCP 配置"""
    server_url: str = "http://localhost:8001"
    api_key: Optional[str] = None
    timeout: int = 30


class QQBotConfig(BaseModel):
    """QQBot 配置"""
    type: str = "nonebot"
    driver: Optional[str] = "~fastapi+~websockets"
    host: Optional[str] = "127.0.0.1"
    port: Optional[int] = 8080
    websocket: Optional[str] = "ws://127.0.0.1:6700"


class ModuleConfig(BaseModel):
    """模块配置"""
    enabled: list[str] = Field(default_factory=list)
    
    medical_record: Dict[str, Any] = Field(default_factory=lambda: {"template_dir": "./templates/medical_record"})
    medical_quality: Dict[str, Any] = Field(default_factory=lambda: {"rule_dir": "./rules/medical_quality"})
    insurance_analysis: Dict[str, Any] = Field(default_factory=lambda: {"drg_dict_path": "./data/drg_dict.json", "rule_dir": "./rules/insurance"})
    clinical_prediction: Dict[str, Any] = Field(default_factory=lambda: {"model_dir": "./models/clinical"})
    ai_reading: Dict[str, Any] = Field(default_factory=lambda: {"model_name": "resnet50", "weights_path": "./models/ai_reading/model.pth", "device": "cuda", "dicom_cache": "./cache/dicom"})
    research_analysis: Dict[str, Any] = Field(default_factory=lambda: {"data_dir": "./data/research"})
    paper_analysis: Dict[str, Any] = Field(default_factory=lambda: {"cache_dir": "./cache/papers"})


class Config(BaseModel):
    """主配置类"""
    app: AppConfig = Field(default_factory=AppConfig)
    database: DatabaseConfig = Field(default_factory=DatabaseConfig)
    mcp: MCPConfig = Field(default_factory=MCPConfig)
    qqbot: QQBotConfig = Field(default_factory=QQBotConfig)
    modules: ModuleConfig = Field(default_factory=ModuleConfig)


class ConfigManager:
    """配置管理器"""
    
    def __init__(self, config_path: str = "config.yaml"):
        self.config_path = Path(config_path)
        self.config: Optional[Config] = None
    
    def load(self) -> Config:
        """加载配置文件"""
        if not self.config_path.exists():
            raise FileNotFoundError(f"配置文件不存在：{self.config_path}")
        
        with open(self.config_path, 'r', encoding='utf-8') as f:
            config_data = yaml.safe_load(f)
        
        self.config = Config(**config_data)
        return self.config
    
    def get(self) -> Optional[Config]:
        """获取配置"""
        return self.config
    
    def reload(self) -> Config:
        """重新加载配置"""
        return self.load()


def get_config_manager() -> ConfigManager:
    """获取配置管理器实例"""
    return ConfigManager()
