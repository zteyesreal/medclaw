"""
MedClaw 任务分发器和容错机制
支持负载均衡、任务重试、死信队列
"""

import asyncio
import time
from typing import Dict, List, Optional, Any, Callable, Set
from datetime import datetime, timedelta
import logging
import uuid
from collections import defaultdict

from .task_queue import (
    BaseTaskQueue,
    MemoryTaskQueue,
    QueueItem,
    TaskPriority,
    TaskStatus,
)

logger = logging.getLogger(__name__)


class WorkerInfo:
    """Worker 信息"""
    
    def __init__(self, worker_id: str, capabilities: List[str]):
        self.worker_id = worker_id
        self.capabilities = capabilities
        self.status = "idle"  # idle, busy, offline
        self.current_task_id: Optional[str] = None
        self.tasks_completed = 0
        self.tasks_failed = 0
        self.last_heartbeat = datetime.now()
        self.registered_at = datetime.now()
    
    def is_healthy(self, timeout_seconds: int = 30) -> bool:
        """检查 Worker 是否健康"""
        return (datetime.now() - self.last_heartbeat).total_seconds() < timeout_seconds
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "worker_id": self.worker_id,
            "status": self.status,
            "capabilities": self.capabilities,
            "current_task_id": self.current_task_id,
            "tasks_completed": self.tasks_completed,
            "tasks_failed": self.tasks_failed,
            "last_heartbeat": self.last_heartbeat.isoformat(),
            "is_healthy": self.is_healthy(),
        }


class DeadLetterQueue:
    """死信队列"""
    
    def __init__(self, max_size: int = 1000):
        self.max_size = max_size
        self.items: List[Dict[str, Any]] = []
    
    def add(self, item: QueueItem, error: str, reason: str):
        """添加失败任务到死信队列"""
        self.items.append({
            "task_id": item.task_id,
            "task_data": item.task_data,
            "attempts": item.attempts,
            "error": error,
            "reason": reason,
            "failed_at": datetime.now().isoformat(),
        })
        
        # 限制队列大小
        if len(self.items) > self.max_size:
            self.items.pop(0)  # 移除最早的
        
        logger.warning(f"任务 {item.task_id} 已加入死信队列（原因：{reason}）")
    
    def get_all(self) -> List[Dict[str, Any]]:
        """获取所有死信任务"""
        return self.items.copy()
    
    def clear(self):
        """清空死信队列"""
        self.items.clear()
    
    def size(self) -> int:
        """死信队列大小"""
        return len(self.items)


class TaskDispatcher:
    """任务分发器"""
    
    def __init__(self, queue: BaseTaskQueue):
        self.queue = queue
        self.workers: Dict[str, WorkerInfo] = {}
        self.dead_letter_queue = DeadLetterQueue()
        self.task_results: Dict[str, Any] = {}
        self.task_callbacks: Dict[str, List[Callable]] = defaultdict(list)
        self._running = False
        self._dispatch_task: Optional[asyncio.Task] = None
        
        # 分发策略
        self.dispatch_strategy = "round_robin"  # round_robin, least_connections, priority
        self._worker_index = 0  # 用于轮询
    
    def register_worker(
        self,
        worker_id: str,
        capabilities: List[str]
    ) -> bool:
        """注册 Worker"""
        if worker_id in self.workers:
            logger.warning(f"Worker {worker_id} 已存在")
            return False
        
        worker = WorkerInfo(worker_id, capabilities)
        self.workers[worker_id] = worker
        
        logger.info(f"Worker {worker_id} 已注册（能力：{capabilities}）")
        return True
    
    def unregister_worker(self, worker_id: str) -> bool:
        """注销 Worker"""
        if worker_id in self.workers:
            del self.workers[worker_id]
            logger.info(f"Worker {worker_id} 已注销")
            return True
        return False
    
    def update_worker_heartbeat(self, worker_id: str):
        """更新 Worker 心跳"""
        if worker_id in self.workers:
            self.workers[worker_id].last_heartbeat = datetime.now()
    
    async def submit_task(
        self,
        task_data: Any,
        priority: TaskPriority = TaskPriority.NORMAL,
        task_id: Optional[str] = None,
        scheduled_at: Optional[datetime] = None
    ) -> str:
        """
        提交任务
        
        Args:
            task_data: 任务数据
            priority: 优先级
            task_id: 任务 ID（可选，自动生成）
            scheduled_at: 计划执行时间（可选）
            
        Returns:
            任务 ID
        """
        if task_id is None:
            task_id = str(uuid.uuid4())
        
        item = QueueItem(
            task_id=task_id,
            task_data=task_data,
            priority=priority,
            scheduled_at=scheduled_at,
        )
        
        success = await self.queue.enqueue(item)
        
        if success:
            logger.info(f"任务 {task_id} 已提交（优先级：{priority}）")
        else:
            logger.error(f"任务 {task_id} 提交失败")
        
        return task_id
    
    async def start(self):
        """启动分发器"""
        if self._running:
            logger.warning("分发器已在运行")
            return
        
        self._running = True
        self._dispatch_task = asyncio.create_task(self._dispatch_loop())
        logger.info("任务分发器已启动")
    
    async def stop(self):
        """停止分发器"""
        self._running = False
        
        if self._dispatch_task:
            self._dispatch_task.cancel()
            try:
                await self._dispatch_task
            except asyncio.CancelledError:
                pass
        
        logger.info("任务分发器已停止")
    
    async def _dispatch_loop(self):
        """分发循环"""
        while self._running:
            try:
                await self._dispatch_next_task()
                await asyncio.sleep(0.1)  # 避免空转
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"分发循环错误：{e}")
                await asyncio.sleep(1)
    
    async def _dispatch_next_task(self):
        """分发下一个任务"""
        # 获取队列中的任务
        item = await self.queue.dequeue()
        if not item:
            return
        
        # 检查是否到了执行时间
        if item.scheduled_at and item.scheduled_at > datetime.now():
            # 还没到执行时间，重新入队
            await self.queue.enqueue(item)
            await asyncio.sleep(0.5)
            return
        
        # 查找合适的 Worker
        worker = self._find_suitable_worker(item)
        
        if not worker:
            # 没有合适的 Worker，重新入队
            logger.warning(f"没有可用的 Worker 执行任务 {item.task_id}，重新入队")
            await self.queue.enqueue(item)
            await asyncio.sleep(1)
            return
        
        # 分配任务给 Worker
        await self._assign_task_to_worker(item, worker)
    
    def _find_suitable_worker(self, item: QueueItem) -> Optional[WorkerInfo]:
        """查找合适的 Worker"""
        # 获取所有健康的空闲 Worker
        available_workers = [
            w for w in self.workers.values()
            if w.status == "idle" and w.is_healthy()
        ]
        
        if not available_workers:
            return None
        
        # 根据分发策略选择 Worker
        if self.dispatch_strategy == "round_robin":
            return self._select_round_robin(available_workers)
        elif self.dispatch_strategy == "least_connections":
            return self._select_least_connections(available_workers)
        else:
            # 默认轮询
            return self._select_round_robin(available_workers)
    
    def _select_round_robin(self, workers: List[WorkerInfo]) -> WorkerInfo:
        """轮询选择"""
        worker = workers[self._worker_index % len(workers)]
        self._worker_index += 1
        return worker
    
    def _select_least_connections(self, workers: List[WorkerInfo]) -> WorkerInfo:
        """最少连接选择"""
        # 选择完成任务数最少的 Worker（负载均衡）
        return min(workers, key=lambda w: w.tasks_completed)
    
    async def _assign_task_to_worker(self, item: QueueItem, worker: WorkerInfo):
        """分配任务给 Worker"""
        worker.status = "busy"
        worker.current_task_id = item.task_id
        
        logger.info(f"任务 {item.task_id} 已分配给 Worker {worker.worker_id}")
    
    async def complete_task(
        self,
        worker_id: str,
        task_id: str,
        result: Any,
        success: bool = True
    ):
        """
        完成任务
        
        Args:
            worker_id: Worker ID
            task_id: 任务 ID
            result: 执行结果
            success: 是否成功
        """
        if worker_id not in self.workers:
            logger.error(f"Worker {worker_id} 不存在")
            return
        
        worker = self.workers[worker_id]
        
        # 更新 Worker 状态
        worker.status = "idle"
        worker.current_task_id = None
        
        if success:
            worker.tasks_completed += 1
            self.task_results[task_id] = {
                "status": "completed",
                "result": result,
                "completed_at": datetime.now().isoformat(),
            }
            logger.info(f"任务 {task_id} 执行成功")
        else:
            worker.tasks_failed += 1
            logger.error(f"任务 {task_id} 执行失败")
        
        # 调用回调
        for callback in self.task_callbacks.get(task_id, []):
            try:
                if asyncio.iscoroutinefunction(callback):
                    await callback(task_id, result, success)
                else:
                    callback(task_id, result, success)
            except Exception as e:
                logger.error(f"任务回调执行失败：{e}")
        
        # 清理回调
        if task_id in self.task_callbacks:
            del self.task_callbacks[task_id]
    
    async def fail_task(
        self,
        worker_id: str,
        task_id: str,
        error: str,
        should_retry: bool = True
    ):
        """
        任务失败
        
        Args:
            worker_id: Worker ID
            task_id: 任务 ID
            error: 错误信息
            should_retry: 是否重试
        """
        if worker_id not in self.workers:
            return
        
        worker = self.workers[worker_id]
        worker.status = "idle"
        worker.current_task_id = None
        
        if should_retry:
            # 重新入队（已经在 QueueItem 中处理重试逻辑）
            logger.info(f"任务 {task_id} 将重试")
        else:
            # 加入死信队列
            self.dead_letter_queue.add(
                QueueItem(task_id=task_id, task_data=None),
                error,
                "多次重试失败"
            )
            worker.tasks_failed += 1
    
    def set_task_callback(self, task_id: str, callback: Callable):
        """设置任务完成回调"""
        self.task_callbacks[task_id].append(callback)
    
    def get_worker_status(self, worker_id: str) -> Optional[Dict[str, Any]]:
        """获取 Worker 状态"""
        if worker_id in self.workers:
            return self.workers[worker_id].to_dict()
        return None
    
    def get_all_worker_status(self) -> List[Dict[str, Any]]:
        """获取所有 Worker 状态"""
        return [w.to_dict() for w in self.workers.values()]
    
    def get_queue_stats(self) -> Dict[str, Any]:
        """获取队列统计"""
        return {
            "queue_size": self.queue.size,
            "queue_stats": self.queue.get_stats(),
            "dead_letter_queue_size": self.dead_letter_queue.size(),
            "worker_count": len(self.workers),
            "idle_workers": sum(1 for w in self.workers.values() if w.status == "idle"),
            "busy_workers": sum(1 for w in self.workers.values() if w.status == "busy"),
        }
    
    def get_task_result(self, task_id: str) -> Optional[Dict[str, Any]]:
        """获取任务结果"""
        return self.task_results.get(task_id)
    
    def cleanup_dead_workers(self, timeout_seconds: int = 60):
        """清理失联的 Worker"""
        dead_workers = []
        
        for worker_id, worker in self.workers.items():
            if not worker.is_healthy(timeout_seconds):
                dead_workers.append(worker_id)
                
                # 如果 Worker 有正在执行的任务，重新入队
                if worker.current_task_id:
                    logger.warning(f"Worker {worker_id} 失联，任务 {worker.current_task_id} 将重新入队")
                    # 这里需要重新创建任务并入队（简化处理）
                
                worker.status = "offline"
        
        for worker_id in dead_workers:
            logger.warning(f"Worker {worker_id} 已标记为离线")
        
        return dead_workers


# ========== 导出符号 ==========

__all__ = [
    "WorkerInfo",
    "DeadLetterQueue",
    "TaskDispatcher",
]
