"""
MedClaw 工具审计日志
记录所有工具调用
"""

import asyncio
import json
from typing import Dict, List, Optional, Any
from datetime import datetime
from pathlib import Path
import logging
import csv

logger = logging.getLogger(__name__)


class AuditLogEntry:
    """审计日志条目"""
    
    def __init__(
        self,
        tool_name: str,
        params: Dict[str, Any],
        result: Any,
        duration: float,
        caller: str,
        status: str = "success"
    ):
        self.timestamp = datetime.now()
        self.tool_name = tool_name
        self.params = params
        self.result = result
        self.duration = duration
        self.caller = caller
        self.status = status
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "timestamp": self.timestamp.isoformat(),
            "tool_name": self.tool_name,
            "params": self.params,
            "result": self.result,
            "duration": self.duration,
            "caller": self.caller,
            "status": self.status,
        }


class ToolAuditLogger:
    """工具审计日志器"""
    
    def __init__(
        self,
        log_file: Optional[str] = None,
        max_queue_size: int = 1000,
        flush_interval: int = 10
    ):
        self.log_file = log_file or "tool_audit.log"
        self.max_queue_size = max_queue_size
        self.flush_interval = flush_interval
        
        self.log_queue: asyncio.Queue = asyncio.Queue(maxsize=max_queue_size)
        self._running = False
        self._flush_task: Optional[asyncio.Task] = None
        
        # 内存中的日志（最近 N 条）
        self.recent_logs: List[AuditLogEntry] = []
        self.max_recent = 100
        
        # 统计信息
        self.stats = {
            "total_logs": 0,
            "success_count": 0,
            "error_count": 0,
            "flushed_count": 0,
        }
        
        logger.info(f"工具审计日志器已初始化：{self.log_file}")
    
    async def initialize(self):
        """初始化"""
        self._running = True
        self._flush_task = asyncio.create_task(self._flush_loop())
        logger.info("审计日志器已启动")
    
    async def log_call(
        self,
        tool_name: str,
        params: Dict[str, Any],
        result: Any,
        duration: float,
        caller: str,
        status: str = "success"
    ):
        """记录工具调用"""
        entry = AuditLogEntry(
            tool_name=tool_name,
            params=params,
            result=result,
            duration=duration,
            caller=caller,
            status=status
        )
        
        self.stats["total_logs"] += 1
        if status == "success":
            self.stats["success_count"] += 1
        else:
            self.stats["error_count"] += 1
        
        # 添加到内存队列
        if self.log_queue.full():
            # 队列满时，丢弃最旧的日志
            try:
                self.log_queue.get_nowait()
            except asyncio.QueueEmpty:
                pass
        
        await self.log_queue.put(entry)
        
        # 添加到最近日志
        self.recent_logs.append(entry)
        if len(self.recent_logs) > self.max_recent:
            self.recent_logs.pop(0)
        
        logger.debug(f"审计日志：{tool_name} by {caller}")
    
    async def _flush_loop(self):
        """定期刷新日志"""
        while self._running:
            try:
                await asyncio.sleep(self.flush_interval)
                await self._flush_to_file()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"审计日志刷新失败：{e}")
    
    async def _flush_to_file(self):
        """刷新到文件"""
        if self.log_queue.empty():
            return
        
        entries = []
        while not self.log_queue.empty():
            try:
                entry = await self.log_queue.get_nowait()
                entries.append(entry)
            except asyncio.QueueEmpty:
                break
        
        if not entries:
            return
        
        try:
            # 追加写入文件
            log_path = Path(self.log_file)
            log_path.parent.mkdir(parents=True, exist_ok=True)
            
            with open(log_path, 'a', encoding='utf-8') as f:
                for entry in entries:
                    log_line = json.dumps(entry.to_dict(), ensure_ascii=False)
                    f.write(log_line + '\n')
            
            self.stats["flushed_count"] += len(entries)
            logger.debug(f"已刷新 {len(entries)} 条审计日志到文件")
            
        except Exception as e:
            logger.error(f"写入审计日志文件失败：{e}")
    
    def query_logs(
        self,
        tool_name: Optional[str] = None,
        caller: Optional[str] = None,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        limit: int = 100
    ) -> List[Dict[str, Any]]:
        """
        查询日志
        
        Args:
            tool_name: 工具名称过滤
            caller: 调用者过滤
            start_time: 开始时间
            end_time: 结束时间
            limit: 返回数量限制
            
        Returns:
            日志列表
        """
        results = []
        
        for entry in self.recent_logs:
            # 过滤
            if tool_name and entry.tool_name != tool_name:
                continue
            if caller and entry.caller != caller:
                continue
            if start_time and entry.timestamp < start_time:
                continue
            if end_time and entry.timestamp > end_time:
                continue
            
            results.append(entry.to_dict())
            if len(results) >= limit:
                break
        
        return results
    
    def export_to_csv(self, output_file: str):
        """导出为 CSV"""
        entries = self.recent_logs
        
        if not entries:
            logger.warning("没有日志可导出")
            return
        
        try:
            with open(output_file, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                
                # 写入表头
                writer.writerow([
                    "timestamp", "tool_name", "caller", "status",
                    "duration", "params", "result"
                ])
                
                # 写入数据
                for entry in entries:
                    writer.writerow([
                        entry.timestamp.isoformat(),
                        entry.tool_name,
                        entry.caller,
                        entry.status,
                        f"{entry.duration:.4f}",
                        json.dumps(entry.params, ensure_ascii=False),
                        json.dumps(entry.result, ensure_ascii=False)
                    ])
            
            logger.info(f"已导出 {len(entries)} 条日志到 CSV: {output_file}")
            
        except Exception as e:
            logger.error(f"导出 CSV 失败：{e}")
    
    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        return self.stats.copy()
    
    async def cleanup(self):
        """清理"""
        self._running = False
        
        if self._flush_task:
            self._flush_task.cancel()
            try:
                await self._flush_task
            except asyncio.CancelledError:
                pass
        
        # 最后刷新一次
        await self._flush_to_file()
        
        logger.info("审计日志器已清理")


# ========== 导出符号 ==========

__all__ = [
    "AuditLogEntry",
    "ToolAuditLogger",
]
