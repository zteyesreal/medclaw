"""
MedClaw 并行任务执行引擎
支持并行执行、条件执行、动态调整、多 Agent 协作
"""

import asyncio
import time
from typing import Dict, List, Optional, Any, Callable
from datetime import datetime
import logging

from .distributed_task_framework import (
    Task,
    TaskStep,
    TaskStatus,
    ExecutionPolicy,
    ConditionEvaluator,
    DependencyResolver,
    RetryPolicy,
)

logger = logging.getLogger(__name__)


class ParallelTaskExecutor:
    """并行任务执行引擎"""
    
    def __init__(self):
        self.skills: Dict[str, Callable] = {}  # 注册的技能
        self.agents: Dict[str, Any] = {}  # 注册的 Agent
        self.execution_context: Dict[str, Any] = {}  # 执行上下文
        
    def register_skill(self, skill_name: str, skill_func: Callable):
        """注册技能"""
        self.skills[skill_name] = skill_func
        logger.info(f"已注册技能：{skill_name}")
        
    def register_agent(self, agent_id: str, agent):
        """注册 Agent"""
        self.agents[agent_id] = agent
        logger.info(f"已注册 Agent: {agent_id}")
    
    async def execute_task(self, task: Task) -> Task:
        """
        执行任务（主入口）
        
        Args:
            task: 任务对象
            
        Returns:
            执行后的任务对象
        """
        task.status = TaskStatus.RUNNING
        task.started_at = datetime.now().isoformat()
        task.total_steps = len(task.steps)
        
        logger.info(f"开始执行任务：{task.name} ({task.id})")
        
        try:
            # 验证依赖关系
            DependencyResolver.validate_dependencies(task.steps)
            
            # 拓扑排序，获取可并行执行的步骤组
            execution_levels = DependencyResolver.topological_sort(task.steps)
            
            # 按层级执行
            for level_idx, level in enumerate(execution_levels):
                logger.info(f"执行第 {level_idx + 1} 层，包含 {len(level)} 个步骤")
                
                # 并行执行当前层级的所有步骤
                await self._execute_level(task, level)
                
                # 检查是否有步骤失败
                if any(step.status == "failed" for step in task.steps if step.id in level):
                    logger.warning(f"第 {level_idx + 1} 层有步骤失败，停止执行")
                    break
            
            # 更新任务状态
            self._update_task_status(task)
            
        except Exception as e:
            task.status = TaskStatus.FAILED
            task.error = str(e)
            logger.error(f"任务执行失败：{e}")
        
        task.completed_at = datetime.now().isoformat()
        logger.info(f"任务执行完成：{task.name}, 状态：{task.status}")
        
        return task
    
    async def _execute_level(self, task: Task, level: List[str]):
        """
        并行执行一个层级的所有步骤
        
        Args:
            task: 任务对象
            level: 步骤 ID 列表
        """
        # 获取当前层级的步骤对象
        steps_to_execute = [
            step for step in task.steps 
            if step.id in level and not step.skipped
        ]
        
        if not steps_to_execute:
            return
        
        # 检查是否都是并行步骤
        if all(step.execution_policy == ExecutionPolicy.PARALLEL for step in steps_to_execute):
            # 并行执行
            await self._execute_parallel(task, steps_to_execute)
        else:
            # 顺序执行
            await self._execute_sequential(task, steps_to_execute)
    
    async def _execute_parallel(self, task: Task, steps: List[TaskStep]):
        """
        并行执行多个步骤
        
        Args:
            task: 任务对象
            steps: 步骤对象列表
        """
        logger.info(f"并行执行 {len(steps)} 个步骤")
        
        # 创建所有步骤的协程
        coroutines = []
        for step in steps:
            coroutines.append(self._execute_step_with_retry(task, step))
        
        # 并行执行所有步骤
        results = await asyncio.gather(*coroutines, return_exceptions=True)
        
        # 处理结果
        for step, result in zip(steps, results):
            if isinstance(result, Exception):
                step.status = "failed"
                step.error = str(result)
                task.failed_steps += 1
                logger.error(f"步骤 {step.id} 执行失败：{result}")
            else:
                step.result = result
                step.status = "completed"
                step.completed_at = datetime.now().isoformat()
                task.completed_steps += 1
                logger.info(f"步骤 {step.id} 执行完成")
    
    async def _execute_sequential(self, task: Task, steps: List[TaskStep]):
        """
        顺序执行多个步骤
        
        Args:
            task: 任务对象
            steps: 步骤对象列表
        """
        for step in steps:
            await self._execute_step_with_retry(task, step)
    
    async def _execute_step_with_retry(self, task: Task, step: TaskStep):
        """
        执行单个步骤（带重试）
        
        Args:
            task: 任务对象
            step: 步骤对象
        """
        # 检查条件
        if step.condition:
            context = self._build_context(task)
            if not ConditionEvaluator.evaluate(step.condition, context):
                logger.info(f"步骤 {step.id} 条件不满足，跳过")
                step.skipped = True
                step.status = "skipped"
                task.skipped_steps += 1
                return
        
        # 重试策略
        retry_policy = step.retry_policy or RetryPolicy()
        last_error = None
        
        for attempt in range(retry_policy.max_retries + 1):
            try:
                step.status = "running"
                step.started_at = datetime.now().isoformat()
                step.retries = attempt
                
                # 执行步骤（带超时）
                if step.timeout:
                    result = await asyncio.wait_for(
                        self._execute_step(task, step),
                        timeout=step.timeout
                    )
                else:
                    result = await self._execute_step(task, step)
                
                # 执行成功
                step.result = result
                step.status = "completed"
                step.completed_at = datetime.now().isoformat()
                task.completed_steps += 1
                logger.info(f"步骤 {step.id} 执行成功")
                return
                
            except asyncio.TimeoutError:
                last_error = f"步骤执行超时（{step.timeout}秒）"
                logger.warning(f"步骤 {step.id} 执行超时，尝试 {attempt + 1}/{retry_policy.max_retries + 1}")
                
            except Exception as e:
                last_error = str(e)
                logger.warning(f"步骤 {step.id} 执行失败：{e}，尝试 {attempt + 1}/{retry_policy.max_retries + 1}")
            
            # 等待重试
            if attempt < retry_policy.max_retries:
                delay = min(
                    retry_policy.delay * (retry_policy.backoff ** attempt),
                    retry_policy.max_delay
                )
                logger.info(f"等待 {delay:.2f}秒后重试")
                await asyncio.sleep(delay)
        
        # 所有重试都失败
        step.status = "failed"
        step.error = last_error
        step.completed_at = datetime.now().isoformat()
        task.failed_steps += 1
        logger.error(f"步骤 {step.id} 最终执行失败：{last_error}")
    
    async def _execute_step(self, task: Task, step: TaskStep) -> Any:
        """
        执行单个步骤
        
        Args:
            task: 任务对象
            step: 步骤对象
            
        Returns:
            执行结果
        """
        action = step.action
        params = step.params
        
        logger.info(f"执行步骤：{action}, 参数：{params}")
        
        # 查找并执行技能
        if action in self.skills:
            skill_func = self.skills[action]
            if asyncio.iscoroutinefunction(skill_func):
                result = await skill_func(**params)
            else:
                result = skill_func(**params)
            return result
        else:
            # 模拟执行（用于测试）
            logger.warning(f"技能 {action} 未注册，模拟执行")
            await asyncio.sleep(0.1)  # 模拟执行延迟
            return {"status": "completed", "action": action, "params": params}
    
    def _build_context(self, task: Task) -> Dict[str, Any]:
        """
        构建执行上下文（包含所有已完成步骤的结果）
        
        Args:
            task: 任务对象
            
        Returns:
            上下文字典
        """
        context = {
            "task_id": task.id,
            "task_name": task.name,
            "task_goal": task.goal,
        }
        
        # 添加已完成步骤的结果
        for step in task.steps:
            if step.status == "completed" and step.result:
                context[step.id] = step.result
        
        return context
    
    def _update_task_status(self, task: Task):
        """更新任务状态"""
        if task.failed_steps > 0:
            task.status = TaskStatus.FAILED
            task.error = f"有 {task.failed_steps} 个步骤执行失败"
        elif task.completed_steps + task.skipped_steps == task.total_steps:
            task.status = TaskStatus.COMPLETED
            task.result = {
                "total_steps": task.total_steps,
                "completed_steps": task.completed_steps,
                "skipped_steps": task.skipped_steps,
                "failed_steps": task.failed_steps,
            }
        else:
            task.status = TaskStatus.FAILED
            task.error = "任务未完全执行"


class DynamicTaskAdjuster:
    """动态任务调整器"""
    
    def __init__(self, executor: ParallelTaskExecutor):
        self.executor = executor
    
    def skip_step(self, task: Task, step_id: str) -> bool:
        """
        跳过指定步骤
        
        Args:
            task: 任务对象
            step_id: 步骤 ID
            
        Returns:
            是否成功
        """
        for step in task.steps:
            if step.id == step_id:
                if step.status == "pending":
                    step.skipped = True
                    step.status = "skipped"
                    logger.info(f"已跳过步骤：{step_id}")
                    return True
                else:
                    logger.warning(f"步骤 {step_id} 已在执行，无法跳过")
                    return False
        
        logger.error(f"步骤 {step_id} 不存在")
        return False
    
    def insert_step(
        self,
        task: Task,
        after_step_id: str,
        new_step: TaskStep
    ) -> bool:
        """
        在指定步骤后插入新步骤
        
        Args:
            task: 任务对象
            after_step_id: 在哪个步骤后插入
            new_step: 新步骤对象
            
        Returns:
            是否成功
        """
        # 找到插入位置
        insert_idx = None
        for i, step in enumerate(task.steps):
            if step.id == after_step_id:
                insert_idx = i + 1
                break
        
        if insert_idx is None:
            logger.error(f"步骤 {after_step_id} 不存在")
            return False
        
        # 插入新步骤
        task.steps.insert(insert_idx, new_step)
        task.total_steps += 1
        
        # 更新依赖关系
        new_step.dependencies = [after_step_id]
        
        # 更新后续步骤的依赖
        for step in task.steps[insert_idx + 1:]:
            if after_step_id in step.dependencies:
                step.dependencies.append(new_step.id)
        
        logger.info(f"已在步骤 {after_step_id} 后插入新步骤 {new_step.id}")
        return True
    
    def modify_step_params(
        self,
        task: Task,
        step_id: str,
        new_params: Dict[str, Any]
    ) -> bool:
        """
        修改步骤参数
        
        Args:
            task: 任务对象
            step_id: 步骤 ID
            new_params: 新参数
            
        Returns:
            是否成功
        """
        for step in task.steps:
            if step.id == step_id:
                if step.status == "pending":
                    step.params = new_params
                    logger.info(f"已修改步骤 {step_id} 的参数")
                    return True
                else:
                    logger.warning(f"步骤 {step_id} 已在执行，无法修改参数")
                    return False
        
        logger.error(f"步骤 {step_id} 不存在")
        return False


# ========== 导出符号 ==========

__all__ = [
    "ParallelTaskExecutor",
    "DynamicTaskAdjuster",
]
