"""
健康检查和自动恢复模块
"""

import asyncio
import logging
from datetime import datetime
from typing import Callable, Any, Optional
import time

logger = logging.getLogger(__name__)


class HealthChecker:
    """健康检查器"""
    
    def __init__(self, check_interval: int = 60):
        """
        初始化健康检查器
        
        Args:
            check_interval: 检查间隔（秒）
        """
        self.check_interval = check_interval
        self.checks = []
        self.running = False
        self.last_check_time = None
        self.consecutive_failures = 0
        self.max_failures = 3
    
    def register_check(self, name: str, check_func: Callable, recovery_func: Optional[Callable] = None):
        """
        注册健康检查
        
        Args:
            name: 检查名称
            check_func: 检查函数（返回 bool）
            recovery_func: 恢复函数（可选）
        """
        self.checks.append({
            "name": name,
            "check": check_func,
            "recovery": recovery_func
        })
        logger.info(f"已注册健康检查：{name}")
    
    async def start(self):
        """启动健康检查"""
        self.running = True
        logger.info(f"健康检查已启动（间隔：{self.check_interval}秒）")
        
        while self.running:
            try:
                await self._run_checks()
                self.last_check_time = datetime.now()
                await asyncio.sleep(self.check_interval)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"健康检查错误：{e}")
                await asyncio.sleep(self.check_interval)
    
    async def stop(self):
        """停止健康检查"""
        self.running = False
        logger.info("健康检查已停止")
    
    async def _run_checks(self):
        """执行所有检查"""
        results = []
        
        for check in self.checks:
            try:
                is_healthy = check["check"]()
                results.append({
                    "name": check["name"],
                    "healthy": is_healthy,
                    "time": datetime.now().isoformat()
                })
                
                if not is_healthy:
                    logger.warning(f"健康检查失败：{check['name']}")
                    self.consecutive_failures += 1
                    
                    # 执行恢复函数
                    if check["recovery"]:
                        try:
                            logger.info(f"执行恢复操作：{check['name']}")
                            if asyncio.iscoroutinefunction(check["recovery"]):
                                await check["recovery"]()
                            else:
                                check["recovery"]()
                            logger.info(f"恢复操作完成：{check['name']}")
                        except Exception as e:
                            logger.error(f"恢复操作失败：{e}")
                    
                    # 连续失败过多，重启系统
                    if self.consecutive_failures >= self.max_failures:
                        logger.critical("连续健康检查失败，建议重启系统")
                        self.consecutive_failures = 0
                else:
                    self.consecutive_failures = 0
                    
            except Exception as e:
                logger.error(f"执行健康检查 {check['name']} 时出错：{e}")
                results.append({
                    "name": check["name"],
                    "healthy": False,
                    "error": str(e),
                    "time": datetime.now().isoformat()
                })
        
        # 记录结果
        healthy_count = sum(1 for r in results if r.get("healthy", False))
        total_count = len(results)
        
        if healthy_count == total_count:
            logger.debug(f"健康检查通过：{healthy_count}/{total_count}")
        else:
            logger.warning(f"健康检查结果：{healthy_count}/{total_count} 通过")
        
        return results
    
    def get_status(self) -> dict:
        """获取检查状态"""
        return {
            "running": self.running,
            "last_check": self.last_check_time.isoformat() if self.last_check_time else None,
            "consecutive_failures": self.consecutive_failures,
            "checks_count": len(self.checks)
        }


# 全局健康检查实例
health_checker = HealthChecker()


def get_health_checker() -> HealthChecker:
    """获取健康检查实例"""
    return health_checker
