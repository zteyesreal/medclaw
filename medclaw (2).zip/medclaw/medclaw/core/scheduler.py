"""
任务调度器
负责任务的调度、执行和管理
"""

import asyncio
from typing import Any, Callable, Dict, List, Optional
from datetime import datetime
import logging
from enum import Enum

logger = logging.getLogger(__name__)


class TaskStatus(Enum):
    """任务状态"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


class Task:
    """任务类"""
    
    def __init__(self, task_id: str, module_name: str, func: Callable, **kwargs):
        self.task_id = task_id
        self.module_name = module_name
        self.func = func
        self.params = kwargs
        self.status = TaskStatus.PENDING
        self.result: Optional[Any] = None
        self.error: Optional[str] = None
        self.created_at = datetime.now()
        self.started_at: Optional[datetime] = None
        self.completed_at: Optional[datetime] = None
    
    async def execute(self) -> Any:
        """执行任务"""
        try:
            self.status = TaskStatus.RUNNING
            self.started_at = datetime.now()
            
            if asyncio.iscoroutinefunction(self.func):
                self.result = await self.func(**self.params)
            else:
                self.result = self.func(**self.params)
            
            self.status = TaskStatus.COMPLETED
            self.completed_at = datetime.now()
            return self.result
        except Exception as e:
            self.status = TaskStatus.FAILED
            self.error = str(e)
            self.completed_at = datetime.now()
            logger.error(f"任务 {self.task_id} 执行失败：{e}")
            raise


class TaskScheduler:
    """任务调度器"""
    
    def __init__(self):
        self.tasks: Dict[str, Task] = {}
        self.task_queue: asyncio.Queue = asyncio.Queue()
        self._running = False
    
    def register_task(self, task_id: str, module_name: str, func: Callable, **kwargs) -> Task:
        """
        注册任务
        
        Args:
            task_id: 任务 ID
            module_name: 模块名称
            func: 执行函数
            **kwargs: 参数
            
        Returns:
            任务对象
        """
        task = Task(task_id, module_name, func, **kwargs)
        self.tasks[task_id] = task
        logger.info(f"任务 {task_id} 已注册，模块：{module_name}")
        return task
    
    async def execute_task(self, task_id: str) -> Any:
        """
        执行任务
        
        Args:
            task_id: 任务 ID
            
        Returns:
            执行结果
        """
        if task_id not in self.tasks:
            raise ValueError(f"任务 {task_id} 不存在")
        
        task = self.tasks[task_id]
        return await task.execute()
    
    async def execute_all(self) -> Dict[str, Any]:
        """
        执行所有待处理任务
        
        Returns:
            所有任务结果
        """
        results = {}
        for task_id, task in self.tasks.items():
            if task.status == TaskStatus.PENDING:
                try:
                    results[task_id] = await self.execute_task(task_id)
                except Exception as e:
                    results[task_id] = {"error": str(e)}
        return results
    
    def get_task_status(self, task_id: str) -> Optional[TaskStatus]:
        """获取任务状态"""
        if task_id in self.tasks:
            return self.tasks[task_id].status
        return None
    
    def get_task_result(self, task_id: str) -> Optional[Any]:
        """获取任务结果"""
        if task_id in self.tasks:
            return self.tasks[task_id].result
        return None
    
    def clear_completed(self):
        """清理已完成的任务"""
        completed_tasks = [
            tid for tid, task in self.tasks.items()
            if task.status in [TaskStatus.COMPLETED, TaskStatus.FAILED]
        ]
        for task_id in completed_tasks:
            del self.tasks[task_id]
        logger.info(f"清理了 {len(completed_tasks)} 个已完成的任务")
