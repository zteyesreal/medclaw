"""
MedClaw Web UI - 真实世界医疗流程优化版
基于中国医院实际工作流程设计
"""

from fastapi import FastAPI, WebSocket
from fastapi.responses import HTMLResponse
from .config_api import router as config_router

app = FastAPI()
app.include_router(config_router)

class ConnectionManager:
    def __init__(self):
        self.connections = []
    async def connect(self, ws):
        await ws.accept()
        self.connections.append(ws)
    def disconnect(self, ws):
        self.connections.remove(ws)

manager = ConnectionManager()

@app.get("/", response_class=HTMLResponse)
async def index():
    return get_html()

@app.websocket("/ws")
async def ws_endpoint(ws):
    await manager.connect(ws)
    try:
        while True:
            await ws.receive_json()
    except:
        manager.disconnect(ws)

def get_html():
    return '''<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MedClaw 医疗专用界面</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .gradient-bg{background:linear-gradient(135deg,#1e40af 0%,#3b82f6 100%)}
        .step-active{border-color:#10B981;background:#ECFDF5}
        .step-done{border-color:#3B82F6;background:#EFF6FF}
        .step-wait{border-color:#E5E7EB;background:#F9FAFB}
        .card:hover{transform:translateY(-2px);box-shadow:0 8px 16px rgba(0,0,0,0.1)}
        .btn-primary{background:#3B82F6;color:white;font-weight:600;padding:0.75rem 1.5rem;border-radius:0.5rem;transition:all 0.2s}
        .btn-primary:hover{background:#2563EB}
    </style>
</head>
<body class="bg-gray-50">
    <div id="app" class="min-h-screen">
        <!-- 顶部导航 -->
        <header class="gradient-bg text-white shadow-lg py-5">
            <div class="container mx-auto px-4 flex justify-between items-center">
                <div>
                    <h1 class="text-2xl font-bold">🏥 MedClaw 医疗助手</h1>
                    <p class="text-blue-100 text-sm mt-1">基于真实医疗工作流程</p>
                </div>
                <div class="flex gap-2 text-sm">
                    <span class="bg-white/20 px-3 py-1 rounded-full">📋 门急诊/住院</span>
                    <span class="bg-white/20 px-3 py-1 rounded-full">✅ 医保合规</span>
                </div>
            </div>
        </header>

        <!-- 主内容 -->
        <main class="container mx-auto px-4 py-6">
            <!-- 模块选择 -->
            <div v-if="page==='home' && !module">
                <div class="mb-6">
                    <h2 class="text-xl font-bold text-gray-800 mb-2">📋 临床工作区</h2>
                    <p class="text-gray-600 text-sm">选择您要进行的医疗工作</p>
                </div>
                <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
                    <div v-for="m in modules" :key="m.id" @click="select(m)"
                         class="bg-white rounded-xl shadow-md p-5 cursor-pointer card transition-all border-l-4"
                         :style="{borderLeftColor:m.color}">
                        <div class="flex items-start justify-between mb-3">
                            <div>
                                <h3 class="text-lg font-bold text-gray-800">{{m.name}}</h3>
                                <p class="text-gray-600 text-sm mt-1">{{m.realWorld}}</p>
                            </div>
                            <span class="text-4xl">{{m.icon}}</span>
                        </div>
                        <div class="flex items-center text-xs text-gray-500">
                            <i class="fas fa-clock mr-1"></i>
                            <span>预计耗时：{{m.duration}}</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 任务界面 -->
            <div v-if="module">
                <button @click="module=null;step=0;form={}" class="mb-4 text-blue-600 hover:text-blue-800 font-medium flex items-center">
                    <i class="fas fa-arrow-left mr-2"></i>返回模块选择
                </button>
                
                <!-- 标题和进度 -->
                <div class="bg-white rounded-xl shadow-lg p-6 mb-5">
                    <div class="flex items-center gap-4 mb-5">
                        <span class="text-4xl">{{module.icon}}</span>
                        <div class="flex-1">
                            <h2 class="text-2xl font-bold text-gray-800">{{module.name}}</h2>
                            <p class="text-gray-600 text-sm">{{module.realWorld}}</p>
                        </div>
                        <div class="text-right">
                            <div class="text-sm text-gray-500">当前步骤</div>
                            <div class="text-lg font-bold text-blue-600">{{step+1}}/{{module.steps.length}}</div>
                        </div>
                    </div>
                    <div class="flex gap-2 overflow-x-auto">
                        <div v-for="(s,i) in module.steps" :key="i"
                             :class="['flex items-center px-3 py-2 rounded-lg border-2 text-sm whitespace-nowrap',
                                      i===step?'step-active':i<step?'step-done':'step-wait']">
                            <div :class="['w-6 h-6 rounded-full flex items-center justify-center mr-2 font-bold text-xs',
                                          i===step?'bg-green-500 text-white':i<step?'bg-blue-500 text-white':'bg-gray-300']">
                                <i v-if="i<step" class="fas fa-check text-xs"></i>
                                <span v-else>{{i+1}}</span>
                            </div>
                            <span class="font-medium">{{s}}</span>
                        </div>
                    </div>
                </div>

                <!-- 动态表单 -->
                <div class="bg-white rounded-xl shadow-lg p-6">
                    <!-- 1. 病历书写 - 真实流程 -->
                    <div v-if="module.id==='medical_record'">
                        <div v-if="step===0">
                            <div class="flex items-center justify-between mb-4">
                                <h3 class="text-lg font-bold text-gray-800"><i class="fas fa-user-injured mr-2 text-blue-500"></i>患者登记</h3>
                                <span class="text-xs text-gray-500 bg-blue-50 px-3 py-1 rounded-full">门急诊/住院通用</span>
                            </div>
                            <div class="grid md:grid-cols-3 gap-4">
                                <div>
                                    <label class="block text-sm font-semibold text-gray-700 mb-2">姓名</label>
                                    <input v-model="form.name" class="w-full border-2 border-gray-300 rounded-lg px-3 py-2.5 focus:border-blue-500">
                                </div>
                                <div>
                                    <label class="block text-sm font-semibold text-gray-700 mb-2">性别</label>
                                    <select v-model="form.gender" class="w-full border-2 border-gray-300 rounded-lg px-3 py-2.5">
                                        <option value="">请选择</option>
                                        <option value="男">男</option>
                                        <option value="女">女</option>
                                    </select>
                                </div>
                                <div>
                                    <label class="block text-sm font-semibold text-gray-700 mb-2">年龄</label>
                                    <input v-model.number="form.age" type="number" class="w-full border-2 border-gray-300 rounded-lg px-3 py-2.5">
                                </div>
                                <div>
                                    <label class="block text-sm font-semibold text-gray-700 mb-2">就诊类型</label>
                                    <select v-model="form.visitType" class="w-full border-2 border-gray-300 rounded-lg px-3 py-2.5">
                                        <option value="">请选择</option>
                                        <option value="门诊">门诊</option>
                                        <option value="急诊">急诊</option>
                                        <option value="住院">住院</option>
                                    </select>
                                </div>
                                <div>
                                    <label class="block text-sm font-semibold text-gray-700 mb-2">科室</label>
                                    <select v-model="form.department" class="w-full border-2 border-gray-300 rounded-lg px-3 py-2.5">
                                        <option value="">请选择</option>
                                        <option value="内科">内科</option>
                                        <option value="外科">外科</option>
                                        <option value="儿科">儿科</option>
                                        <option value="急诊科">急诊科</option>
                                    </select>
                                </div>
                                <div>
                                    <label class="block text-sm font-semibold text-gray-700 mb-2">就诊卡号</label>
                                    <input v-model="form.cardNo" class="w-full border-2 border-gray-300 rounded-lg px-3 py-2.5">
                                </div>
                            </div>
                            <div class="mt-4 p-3 bg-blue-50 rounded-lg">
                                <p class="text-sm text-blue-800"><i class="fas fa-info-circle mr-2"></i>请核对患者身份信息，确保与医保卡一致</p>
                            </div>
                        </div>

                        <div v-if="step===1">
                            <h3 class="text-lg font-bold text-gray-800 mb-4"><i class="fas fa-file-medical mr-2 text-blue-500"></i>主诉</h3>
                            <div class="mb-4">
                                <label class="block text-sm font-semibold text-gray-700 mb-2">主诉内容</label>
                                <input v-model="form.complaint" placeholder="症状/体征 + 时间，如：发热、咳嗽 3 天"
                                       class="w-full border-2 border-gray-300 rounded-lg px-3 py-2.5 text-base">
                                <p class="text-xs text-gray-500 mt-1">要求：简明扼要，不超过 20 个字</p>
                            </div>
                            <div class="grid md:grid-cols-2 gap-4">
                                <div class="p-3 bg-gray-50 rounded-lg">
                                    <p class="text-sm font-semibold text-gray-700 mb-2">示例：</p>
                                    <ul class="text-sm text-gray-600 space-y-1">
                                        <li>• 发热伴咳嗽 3 天</li>
                                        <li>• 腹痛 2 小时</li>
                                        <li>• 发现血压升高 1 月</li>
                                    </ul>
                                </div>
                                <div class="p-3 bg-red-50 rounded-lg">
                                    <p class="text-sm font-semibold text-red-700 mb-2">避免：</p>
                                    <ul class="text-sm text-red-600 space-y-1">
                                        <li>• 时间过长</li>
                                        <li>• 使用诊断术语</li>
                                        <li>• 描述模糊</li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <div v-if="step===2">
                            <h3 class="text-lg font-bold text-gray-800 mb-4"><i class="fas fa-notes-medical mr-2 text-purple-500"></i>现病史</h3>
                            <div class="mb-4">
                                <label class="block text-sm font-semibold text-gray-700 mb-2">详细描述</label>
                                <textarea v-model="form.illness" rows="8" placeholder="按时间顺序描述发病过程..."
                                          class="w-full border-2 border-gray-300 rounded-lg px-3 py-2.5"></textarea>
                            </div>
                            <div class="grid md:grid-cols-3 gap-3">
                                <div class="p-3 bg-purple-50 rounded-lg">
                                    <p class="text-sm font-semibold text-purple-800 mb-2">✓ 起病情况</p>
                                    <p class="text-xs text-purple-700">时间、地点、诱因</p>
                                </div>
                                <div class="p-3 bg-purple-50 rounded-lg">
                                    <p class="text-sm font-semibold text-purple-800 mb-2">✓ 主要症状</p>
                                    <p class="text-xs text-purple-700">部位、性质、程度</p>
                                </div>
                                <div class="p-3 bg-purple-50 rounded-lg">
                                    <p class="text-sm font-semibold text-purple-800 mb-2">✓ 诊疗经过</p>
                                    <p class="text-xs text-purple-700">已做检查和治疗</p>
                                </div>
                            </div>
                        </div>

                        <div v-if="step===3">
                            <h3 class="text-lg font-bold text-gray-800 mb-4"><i class="fas fa-history mr-2 text-orange-500"></i>既往史</h3>
                            <div class="space-y-3">
                                <div>
                                    <label class="block text-sm font-semibold text-gray-700 mb-2">既往疾病</label>
                                    <div class="flex gap-2 mb-2 flex-wrap">
                                        <span @click="toggleTag('高血压')" :class="['px-3 py-1 rounded-full text-sm cursor-pointer',form.diseases?.includes('高血压')?'bg-red-500 text-white':'bg-gray-200']">高血压</span>
                                        <span @click="toggleTag('糖尿病')" :class="['px-3 py-1 rounded-full text-sm cursor-pointer',form.diseases?.includes('糖尿病')?'bg-red-500 text-white':'bg-gray-200']">糖尿病</span>
                                        <span @click="toggleTag('冠心病')" :class="['px-3 py-1 rounded-full text-sm cursor-pointer',form.diseases?.includes('冠心病')?'bg-red-500 text-white':'bg-gray-200']">冠心病</span>
                                        <span @click="toggleTag('无')" :class="['px-3 py-1 rounded-full text-sm cursor-pointer',form.diseases?.includes('无')?'bg-green-500 text-white':'bg-gray-200']">无特殊</span>
                                    </div>
                                    <textarea v-model="form.diseaseDetail" rows="2" placeholder="其他疾病..."
                                              class="w-full border-2 border-gray-300 rounded-lg px-3 py-2.5"></textarea>
                                </div>
                                <div>
                                    <label class="block text-sm font-semibold text-gray-700 mb-2">过敏史 <span class="text-red-500">*</span></label>
                                    <input v-model="form.allergy" placeholder="无，或详细描述过敏药物/食物"
                                           class="w-full border-2 border-gray-300 rounded-lg px-3 py-2.5">
                                </div>
                            </div>
                        </div>

                        <div v-if="step===4">
                            <h3 class="text-lg font-bold text-gray-800 mb-4"><i class="fas fa-stethoscope mr-2 text-red-500"></i>体格检查</h3>
                            <div class="grid md:grid-cols-4 gap-3 mb-4">
                                <div>
                                    <label class="block text-sm font-semibold text-gray-700 mb-2">T(℃)</label>
                                    <input v-model.number="form.temp" type="number" step="0.1" placeholder="36.5"
                                           class="w-full border-2 border-gray-300 rounded-lg px-3 py-2.5">
                                </div>
                                <div>
                                    <label class="block text-sm font-semibold text-gray-700 mb-2">P(次/分)</label>
                                    <input v-model.number="form.pulse" type="number" placeholder="80"
                                           class="w-full border-2 border-gray-300 rounded-lg px-3 py-2.5">
                                </div>
                                <div>
                                    <label class="block text-sm font-semibold text-gray-700 mb-2">R(次/分)</label>
                                    <input v-model.number="form.resp" type="number" placeholder="18"
                                           class="w-full border-2 border-gray-300 rounded-lg px-3 py-2.5">
                                </div>
                                <div>
                                    <label class="block text-sm font-semibold text-gray-700 mb-2">BP(mmHg)</label>
                                    <input v-model="form.bp" placeholder="120/80"
                                           class="w-full border-2 border-gray-300 rounded-lg px-3 py-2.5">
                                </div>
                            </div>
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">专科检查</label>
                                <textarea v-model="form.exam" rows="4" placeholder="神志清楚，精神可。心肺腹未见明显异常..."
                                          class="w-full border-2 border-gray-300 rounded-lg px-3 py-2.5"></textarea>
                            </div>
                        </div>

                        <div v-if="step===5">
                            <h3 class="text-lg font-bold text-gray-800 mb-4"><i class="fas fa-user-md mr-2 text-green-500"></i>初步诊断</h3>
                            <div class="mb-4">
                                <label class="block text-sm font-semibold text-gray-700 mb-2">诊断名称</label>
                                <input v-model="form.diagnosis" placeholder="例：急性上呼吸道感染"
                                       class="w-full border-2 border-gray-300 rounded-lg px-3 py-2.5 text-lg">
                                <p class="text-xs text-gray-500 mt-1">建议使用 ICD-10 标准诊断名称</p>
                            </div>
                            <div class="mb-4">
                                <label class="block text-sm font-semibold text-gray-700 mb-2">诊断依据</label>
                                <textarea v-model="form.diagnosisBasis" rows="3" placeholder="1. 患者青年男性，急性起病&#10;2. 以发热、咳嗽为主要表现&#10;3. 查体：咽部充血，扁桃体 II 度肿大..."
                                          class="w-full border-2 border-gray-300 rounded-lg px-3 py-2.5"></textarea>
                            </div>
                        </div>

                        <div v-if="step===6">
                            <h3 class="text-lg font-bold text-gray-800 mb-4"><i class="fas fa-prescription mr-2 text-green-500"></i>治疗方案</h3>
                            <div class="space-y-4">
                                <div>
                                    <label class="block text-sm font-semibold text-gray-700 mb-2">药物治疗</label>
                                    <textarea v-model="form.medication" rows="4" placeholder="1. 布洛芬缓释胶囊 300mg 口服 每日 2 次&#10;2. 阿莫西林胶囊 500mg 口服 每日 3 次&#10;3. 复方甘草片 2 片 口服 每日 3 次"
                                              class="w-full border-2 border-gray-300 rounded-lg px-3 py-2.5"></textarea>
                                </div>
                                <div>
                                    <label class="block text-sm font-semibold text-gray-700 mb-2">检查建议</label>
                                    <input v-model="form.examAdvice" placeholder="血常规、C 反应蛋白、胸部 CT"
                                           class="w-full border-2 border-gray-300 rounded-lg px-3 py-2.5">
                                </div>
                                <div>
                                    <label class="block text-sm font-semibold text-gray-700 mb-2">随访计划</label>
                                    <input v-model="form.followup" placeholder="3 天后复诊，不适随诊"
                                           class="w-full border-2 border-gray-300 rounded-lg px-3 py-2.5">
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- 2. 病历质控 - 真实流程 -->
                    <div v-if="module.id==='medical_quality'">
                        <div v-if="step===0">
                            <h3 class="text-lg font-bold text-gray-800 mb-4"><i class="fas fa-folder-open mr-2 text-blue-500"></i>选择病历</h3>
                            <div class="grid md:grid-cols-2 gap-4 mb-4">
                                <div>
                                    <label class="block text-sm font-semibold text-gray-700 mb-2">科室</label>
                                    <select v-model="form.department" class="w-full border-2 border-gray-300 rounded-lg px-3 py-2.5">
                                        <option value="">全部科室</option>
                                        <option value="内科">内科</option>
                                        <option value="外科">外科</option>
                                    </select>
                                </div>
                                <div>
                                    <label class="block text-sm font-semibold text-gray-700 mb-2">病历类型</label>
                                    <select v-model="form.recordType" class="w-full border-2 border-gray-300 rounded-lg px-3 py-2.5">
                                        <option value="">全部类型</option>
                                        <option value="入院记录">入院记录</option>
                                        <option value="首次病程">首次病程</option>
                                        <option value="出院记录">出院记录</option>
                                    </select>
                                </div>
                            </div>
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">搜索</label>
                                <input v-model="form.search" placeholder="病历号、患者姓名、诊断..."
                                       class="w-full border-2 border-gray-300 rounded-lg px-3 py-2.5">
                            </div>
                        </div>
                        <div v-if="step===1">
                            <h3 class="text-lg font-bold text-gray-800 mb-4"><i class="fas fa-clipboard-check mr-2 text-green-500"></i>完整性评分</h3>
                            <div class="space-y-3">
                                <div class="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                                    <span class="font-medium text-green-800">基本信息完整</span>
                                    <span class="text-green-600 font-bold">✓ 通过</span>
                                </div>
                                <div class="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
                                    <span class="font-medium text-yellow-800">过敏史记录</span>
                                    <span class="text-yellow-600 font-bold">⚠ 待完善</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- 3. 医保分析 - 真实流程 -->
                    <div v-if="module.id==='insurance_analysis'">
                        <div v-if="step===0">
                            <h3 class="text-lg font-bold text-gray-800 mb-4"><i class="fas fa-file-invoice-dollar mr-2 text-orange-500"></i>选择病例</h3>
                            <input v-model="form.recordId" placeholder="病历号" class="w-full border-2 border-gray-300 rounded-lg px-3 py-2.5">
                        </div>
                        <div v-if="step===1">
                            <h3 class="text-lg font-bold text-gray-800 mb-4"><i class="fas fa-calculator mr-2 text-green-500"></i>费用明细</h3>
                            <div class="grid md:grid-cols-3 gap-3">
                                <div class="p-3 bg-gray-50 rounded-lg">
                                    <p class="text-sm text-gray-600 mb-1">药品费</p>
                                    <p class="text-xl font-bold text-gray-800">¥{{form.drugCost||0}}</p>
                                </div>
                                <div class="p-3 bg-gray-50 rounded-lg">
                                    <p class="text-sm text-gray-600 mb-1">检查费</p>
                                    <p class="text-xl font-bold text-gray-800">¥{{form.examCost||0}}</p>
                                </div>
                                <div class="p-3 bg-gray-50 rounded-lg">
                                    <p class="text-sm text-gray-600 mb-1">总费用</p>
                                    <p class="text-xl font-bold text-blue-600">¥{{(form.drugCost||0)+(form.examCost||0)}}</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- 4. 临床预测 - 真实流程 -->
                    <div v-if="module.id==='clinical_prediction'">
                        <div v-if="step===0">
                            <h3 class="text-lg font-bold text-gray-800 mb-4"><i class="fas fa-brain mr-2 text-purple-500"></i>风险评估</h3>
                            <div class="space-y-3">
                                <div @click="form.riskType='sepsis'" :class="['p-4 rounded-lg border-2 cursor-pointer',form.riskType==='sepsis'?'border-purple-500 bg-purple-50':'border-gray-300']">
                                    <div class="flex items-center justify-between">
                                        <div>
                                            <p class="font-bold text-gray-800">脓毒症风险</p>
                                            <p class="text-sm text-gray-600">适用于感染患者</p>
                                        </div>
                                        <i class="fas fa-chevron-right text-purple-500"></i>
                                    </div>
                                </div>
                                <div @click="form.riskType='complication'" :class="['p-4 rounded-lg border-2 cursor-pointer',form.riskType==='complication'?'border-purple-500 bg-purple-50':'border-gray-300']">
                                    <div class="flex items-center justify-between">
                                        <div>
                                            <p class="font-bold text-gray-800">术后并发症</p>
                                            <p class="text-sm text-gray-600">适用于术后患者</p>
                                        </div>
                                        <i class="fas fa-chevron-right text-purple-500"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div v-if="step===1">
                            <h3 class="text-lg font-bold text-gray-800 mb-4"><i class="fas fa-heartbeat mr-2 text-red-500"></i>生命体征</h3>
                            <div class="grid md:grid-cols-2 gap-4">
                                <div>
                                    <label class="block text-sm font-semibold text-gray-700 mb-2">体温 (℃)</label>
                                    <input v-model.number="form.temp" type="number" step="0.1" class="w-full border-2 border-gray-300 rounded-lg px-3 py-2.5">
                                </div>
                                <div>
                                    <label class="block text-sm font-semibold text-gray-700 mb-2">心率 (次/分)</label>
                                    <input v-model.number="form.hr" type="number" class="w-full border-2 border-gray-300 rounded-lg px-3 py-2.5">
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- 5. AI 阅片 - 真实流程 -->
                    <div v-if="module.id==='ai_reading'">
                        <div v-if="step===0">
                            <h3 class="text-lg font-bold text-gray-800 mb-4"><i class="fas fa-upload mr-2 text-blue-500"></i>影像上传</h3>
                            <div class="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                                <i class="fas fa-cloud-upload-alt text-5xl text-gray-400 mb-3"></i>
                                <p class="text-gray-600 mb-3">支持 DICOM、JPG 格式</p>
                                <button class="btn-primary">选择文件</button>
                            </div>
                        </div>
                        <div v-if="step===1">
                            <h3 class="text-lg font-bold text-gray-800 mb-4"><i class="fas fa-tags mr-2 text-green-500"></i>检查类型</h3>
                            <div class="grid md:grid-cols-3 gap-3">
                                <div @click="form.imageType='ct'" :class="['p-4 rounded-lg border-2 cursor-pointer text-center',form.imageType==='ct'?'border-blue-500 bg-blue-50':'border-gray-300']">
                                    <i class="fas fa-circle-notch text-3xl text-blue-500 mb-2"></i>
                                    <p class="font-medium">CT</p>
                                </div>
                                <div @click="form.imageType='xray'" :class="['p-4 rounded-lg border-2 cursor-pointer text-center',form.imageType==='xray'?'border-blue-500 bg-blue-50':'border-gray-300']">
                                    <i class="fas fa-bone text-3xl text-blue-500 mb-2"></i>
                                    <p class="font-medium">X 光</p>
                                </div>
                                <div @click="form.imageType='mri'" :class="['p-4 rounded-lg border-2 cursor-pointer text-center',form.imageType==='mri'?'border-blue-500 bg-blue-50':'border-gray-300']">
                                    <i class="fas fa-brain text-3xl text-blue-500 mb-2"></i>
                                    <p class="font-medium">MRI</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- 6. 科研分析 - 真实流程 -->
                    <div v-if="module.id==='research_analysis'">
                        <div v-if="step===0">
                            <h3 class="text-lg font-bold text-gray-800 mb-4"><i class="fas fa-database mr-2 text-cyan-500"></i>数据导入</h3>
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">数据类型</label>
                                <select v-model="form.dataType" class="w-full border-2 border-gray-300 rounded-lg px-3 py-2.5">
                                    <option value="">请选择</option>
                                    <option value="csv">CSV 文件</option>
                                    <option value="excel">Excel 文件</option>
                                </select>
                            </div>
                        </div>
                        <div v-if="step===1">
                            <h3 class="text-lg font-bold text-gray-800 mb-4"><i class="fas fa-chart-bar mr-2 text-purple-500"></i>统计方法</h3>
                            <div class="space-y-3">
                                <div @click="form.method='descriptive'" :class="['p-4 rounded-lg border-2 cursor-pointer',form.method==='descriptive'?'border-purple-500 bg-purple-50':'border-gray-300']">
                                    <p class="font-bold text-gray-800">描述性统计</p>
                                    <p class="text-sm text-gray-600">均值、标准差、频数等</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- 7. 论文分析 - 真实流程 -->
                    <div v-if="module.id==='paper_analysis'">
                        <div v-if="step===0">
                            <h3 class="text-lg font-bold text-gray-800 mb-4"><i class="fas fa-file-upload mr-2 text-yellow-500"></i>论文上传</h3>
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">输入方式</label>
                                <select v-model="form.inputType" class="w-full border-2 border-gray-300 rounded-lg px-3 py-2.5">
                                    <option value="file">PDF 文件</option>
                                    <option value="doi">DOI 号</option>
                                </select>
                            </div>
                        </div>
                        <div v-if="step===1">
                            <h3 class="text-lg font-bold text-gray-800 mb-4"><i class="fas fa-search mr-2 text-blue-500"></i>信息提取</h3>
                            <p class="text-gray-600">正在分析论文信息...</p>
                        </div>
                    </div>

                    <!-- 导航按钮 -->
                    <div class="mt-6 flex justify-between gap-3">
                        <button v-if="step>0" @click="step--" class="px-6 py-2.5 border-2 border-gray-300 rounded-lg hover:bg-gray-50 font-medium">
                            <i class="fas fa-chevron-left mr-2"></i>上一步
                        </button>
                        <button v-if="step<module.steps.length-1" @click="step++" class="flex-1 px-6 py-2.5 btn-primary">
                            下一步 <i class="fas fa-chevron-right ml-2"></i>
                        </button>
                        <button v-if="step===module.steps.length-1" @click="execute" class="flex-1 px-6 py-2.5 bg-gradient-to-r from-green-500 to-blue-500 text-white rounded-lg font-semibold shadow-lg">
                            <i class="fas fa-check-circle mr-2"></i>完成
                        </button>
                    </div>
                </div>

                <!-- 结果 -->
                <div v-if="loading" class="mt-5 bg-white rounded-xl shadow-lg p-6 text-center">
                    <div class="animate-spin rounded-full h-10 w-10 border-b-2 border-blue-500 mx-auto"></div>
                    <p class="mt-3 text-gray-600">处理中...</p>
                </div>
                <div v-if="result" class="mt-5 bg-white rounded-xl shadow-lg p-6">
                    <div class="flex justify-between items-center mb-4">
                        <h3 class="text-lg font-bold text-gray-800">📊 结果</h3>
                        <button @click="result=null" class="text-gray-500 hover:text-gray-700"><i class="fas fa-times"></i></button>
                    </div>
                    <pre class="bg-gray-50 rounded-lg p-4 overflow-auto text-sm">{{JSON.stringify(result,null,2)}}</pre>
                </div>
            </div>
        </main>

        <footer class="bg-gray-800 text-white py-4 mt-8"><div class="container mx-auto px-4 text-center text-sm"><p>MedClaw v1.0.0 - 基于真实医疗流程</p></div></footer>
    </div>

    <script>
        const {createApp}=Vue
        createApp({
            data(){return{
                page:'home',
                module:null,
                step:0,
                loading:false,
                result:null,
                form:{},
                modules:[
                    {id:'medical_record',name:'病历书写',realWorld:'门急诊/住院病历',icon:'📝',color:'#3B82F6',duration:'5-10 分钟',steps:['患者登记','主诉','现病史','既往史','体格检查','初步诊断','治疗方案']},
                    {id:'medical_quality',name:'病历质控',realWorld:'科室质控员工作',icon:'✅',color:'#10B981',duration:'3-5 分钟',steps:['选择病历','完整性评分','合理性分析','ICD 编码','质控报告']},
                    {id:'insurance_analysis',name:'医保分析',realWorld:'医保办审核',icon:'💰',color:'#F59E0B',duration:'2-3 分钟',steps:['选择病例','费用明细','DRG 分组','合规性','风险评估']},
                    {id:'clinical_prediction',name:'临床预测',realWorld:'风险评估',icon:'🔮',color:'#8B5CF6',duration:'3-5 分钟',steps:['选择模型','生命体征','检验结果','风险评分','干预建议']},
                    {id:'ai_reading',name:'AI 阅片',realWorld:'放射科工作',icon:'🖼️',color:'#EF4444',duration:'2-3 分钟',steps:['影像上传','检查类型','AI 分析','病灶标注','报告生成']},
                    {id:'research_analysis',name:'科研分析',realWorld:'科研数据处理',icon:'📊',color:'#06B6D4',duration:'10-15 分钟',steps:['数据导入','选择方法','统计分析','结果解读','图表生成']},
                    {id:'paper_analysis',name:'论文分析',realWorld:'文献阅读',icon:'📄',color:'#D97706',duration:'5-8 分钟',steps:['论文上传','信息提取','关键发现','质量评估','综述生成']}
                ]
            }},
            methods:{
                select(m){this.module=m;this.step=0;this.form={}},
                toggleTag(tag){
                    if(!this.form.diseases)this.form.diseases=[]
                    const i=this.form.diseases.indexOf(tag)
                    i>-1?this.form.diseases.splice(i,1):this.form.diseases.push(tag)
                },
                async execute(){
                    this.loading=true
                    setTimeout(()=>{this.loading=false;this.result={success:true,data:this.form}},1500)
                }
            }
        }).mount('#app')
    </script>
</body>
</html>'''
