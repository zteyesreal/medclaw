"""
MedClaw 医疗专用 UI JavaScript 脚本
"""


def get_medical_scripts():
    """获取医疗界面 JavaScript 脚本"""
    return """
        const { createApp } = Vue

        createApp({
            data() {
                return {
                    currentPage: 'modules',
                    modules: [],
                    selectedModule: null,
                    showForm: false,
                    loading: false,
                    result: null,
                    logs: [],
                    formData: {
                        patientName: '',
                        patientGender: '',
                        patientAge: null,
                        chiefComplaint: '',
                        presentIllness: '',
                        recordId: '',
                        predictionType: 'sepsis',
                        age: null,
                        temperature: null,
                        heartRate: null,
                        wbc: null,
                        imagePath: '',
                        imageType: 'ct',
                        analysisType: 'descriptive',
                        data: '',
                        inputType: 'text',
                        paperInput: ''
                    },
                    config: {
                        app: { name: 'MedClaw', debug: false },
                        database: { url: 'sqlite:///./medclaw.db' },
                        mcp: { server_url: '', api_key: '', timeout: 30 },
                        qqbot: { type: 'go-cqhttp', websocket: '' },
                        modules: { enabled: [] }
                    },
                    configPath: '',
                    availableModules: [],
                    validationResult: null,
                    saveResult: null
                }
            },
            async mounted() {
                await this.loadModules()
                await this.loadConfig()
                await this.loadAvailableModules()
                this.connectWebSocket()
                this.addLog('系统初始化完成')
            },
            methods: {
                async loadModules() {
                    try {
                        const response = await fetch('/api/modules')
                        const data = await response.json()
                        this.modules = data.modules
                    } catch (error) {
                        this.addLog('加载模块失败：' + error.message)
                    }
                },
                connectWebSocket() {
                    const ws = new WebSocket(`ws://${window.location.host}/ws`)
                    ws.onmessage = (event) => {
                        const data = JSON.parse(event.data)
                        if (data.type === 'task_update') {
                            this.addLog(`任务更新：${data.task_id} - ${data.status}`)
                        }
                    }
                    ws.onopen = () => this.addLog('WebSocket 连接成功')
                    ws.onclose = () => {
                        this.addLog('WebSocket 连接关闭')
                        setTimeout(() => this.connectWebSocket(), 3000)
                    }
                },
                selectModule(module) {
                    this.selectedModule = module
                    this.result = null
                    this.addLog(`选择模块：${module.name}`)
                },
                async executeMedicalRecord() {
                    await this.execute('/api/medical_record', {
                        patient_info: {
                            name: this.formData.patientName,
                            gender: this.formData.patientGender,
                            age: this.formData.patientAge
                        },
                        chief_complaint: this.formData.chiefComplaint,
                        present_illness: this.formData.presentIllness
                    })
                },
                async executeQualityCheck() {
                    await this.execute('/api/quality_check', {
                        medical_record_id: this.formData.recordId,
                        medical_record: {}
                    })
                },
                async executeInsuranceAnalysis() {
                    await this.execute('/api/insurance_analysis', {
                        medical_record_id: this.formData.recordId,
                        medical_record: {}
                    })
                },
                async executePrediction() {
                    await this.execute('/api/clinical_prediction', {
                        model_name: this.formData.predictionType,
                        patient_data: {
                            age: this.formData.age,
                            temperature: this.formData.temperature,
                            heart_rate: this.formData.heartRate,
                            wbc: this.formData.wbc
                        }
                    })
                },
                async executeAIReading() {
                    await this.execute('/api/ai_reading', {
                        image_path: this.formData.imagePath,
                        image_type: this.formData.imageType
                    })
                },
                async executeResearchAnalysis() {
                    await this.execute('/api/research_analysis', {
                        analysis_type: this.formData.analysisType,
                        data: this.formData.data ? JSON.parse(this.formData.data) : {}
                    })
                },
                async executePaperAnalysis() {
                    await this.execute('/api/paper_analysis', {
                        paper_input: this.formData.paperInput,
                        input_type: this.formData.inputType
                    })
                },
                async execute(endpoint, data) {
                    this.loading = true
                    this.result = null
                    this.addLog(`执行 ${this.selectedModule.name}`)
                    
                    try {
                        const response = await fetch(endpoint, {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify(data)
                        })
                        const result = await response.json()
                        this.result = result
                        this.addLog(result.success ? '执行成功' : '执行失败：' + result.error)
                    } catch (error) {
                        this.addLog('执行错误：' + error.message)
                    } finally {
                        this.loading = false
                    }
                },
                addLog(message) {
                    const now = new Date()
                    const time = now.toLocaleTimeString('zh-CN')
                    this.logs.unshift({ time, message })
                    if (this.logs.length > 100) this.logs.pop()
                },
                async loadConfig() {
                    try {
                        const response = await fetch('/api/config')
                        const data = await response.json()
                        if (data.success) {
                            this.config = data.data
                            this.configPath = data.config_path
                            this.addLog('配置加载成功')
                        }
                    } catch (error) {
                        this.addLog('加载配置失败：' + error.message)
                    }
                },
                async loadAvailableModules() {
                    try {
                        const response = await fetch('/api/config/modules')
                        const data = await response.json()
                        if (data.success) {
                            this.availableModules = data.modules
                        }
                    } catch (error) {
                        this.addLog('加载模块列表失败：' + error.message)
                    }
                },
                toggleModule(moduleId) {
                    const index = this.config.modules.enabled.indexOf(moduleId)
                    if (index > -1) {
                        this.config.modules.enabled.splice(index, 1)
                    } else {
                        this.config.modules.enabled.push(moduleId)
                    }
                },
                async validateConfig() {
                    this.validationResult = null
                    try {
                        const response = await fetch('/api/config/validate', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify(this.config)
                        })
                        const data = await response.json()
                        if (data.success) {
                            this.validationResult = data.validation
                            this.addLog(`配置验证：${this.validationResult.valid ? '通过' : '失败'}`)
                        }
                    } catch (error) {
                        this.addLog('验证配置失败：' + error.message)
                    }
                },
                async saveConfig() {
                    this.saveResult = null
                    try {
                        const response = await fetch('/api/config', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify(this.config)
                        })
                        const data = await response.json()
                        this.saveResult = data
                        if (data.success) {
                            this.addLog('配置保存成功')
                            setTimeout(() => { this.saveResult = null }, 5000)
                        } else {
                            this.addLog('配置保存失败：' + data.detail)
                        }
                    } catch (error) {
                        this.addLog('保存配置失败：' + error.message)
                    }
                },
                async resetConfig() {
                    if (!confirm('确定要重置为默认配置吗？当前配置将会丢失。')) {
                        return
                    }
                    try {
                        const response = await fetch('/api/config/reset', {
                            method: 'POST'
                        })
                        const data = await response.json()
                        if (data.success) {
                            this.config = data.data
                            this.saveResult = {
                                success: true,
                                message: '配置已重置为默认值'
                            }
                            this.addLog('配置已重置')
                            setTimeout(() => { this.saveResult = null }, 5000)
                        }
                    } catch (error) {
                        this.addLog('重置配置失败：' + error.message)
                    }
                }
            }
        }).mount('#app')
    """
