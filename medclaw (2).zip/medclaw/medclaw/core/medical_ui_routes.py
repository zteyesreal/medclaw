"""
MedClaw 医疗专用 UI API 路由（向后兼容的转发器）
所有路由已拆分到独立模块文件
"""

from .medical_ui_routes_aggregator import router, get_modules, websocket_endpoint

__all__ = ["router", "get_modules", "websocket_endpoint"]
