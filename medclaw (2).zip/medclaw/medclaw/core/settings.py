"""
MedClaw 统一设置模块
提供全局配置管理，所有模块共享
"""

from pydantic import BaseModel, Field
from typing import Dict, List, Optional, Any
import json
import asyncio
from pathlib import Path
import logging

logger = logging.getLogger(__name__)


class APISettings(BaseModel):
    """API 接口设置"""
    
    base_url: str = Field(default="http://localhost:8000", description="API 基础 URL")
    timeout: int = Field(default=30, description="请求超时时间（秒）")
    retry_count: int = Field(default=3, description="重试次数")
    api_key: Optional[str] = Field(default=None, description="API 密钥")
    enable_auth: bool = Field(default=False, description="是否启用认证")
    
    class Config:
        json_schema_extra = {
            "example": {
                "base_url": "http://localhost:8000",
                "timeout": 30,
                "retry_count": 3,
                "api_key": "your-api-key",
                "enable_auth": False
            }
        }


class DatabaseSettings(BaseModel):
    """数据库设置"""
    
    driver: str = Field(default="sqlite", description="数据库驱动")
    host: str = Field(default="localhost", description="数据库主机")
    port: int = Field(default=3306, description="数据库端口")
    database: str = Field(default="medclaw", description="数据库名")
    username: Optional[str] = Field(default=None, description="用户名")
    password: Optional[str] = Field(default=None, description="密码")
    pool_size: int = Field(default=5, description="连接池大小")
    
    @property
    def connection_string(self) -> str:
        """生成连接字符串"""
        if self.driver == "sqlite":
            return f"sqlite:///{self.database}.db"
        elif self.driver == "mysql":
            return f"mysql://{self.username}:{self.password}@{self.host}:{self.port}/{self.database}"
        elif self.driver == "postgresql":
            return f"postgresql://{self.username}:{self.password}@{self.host}:{self.port}/{self.database}"
        else:
            raise ValueError(f"不支持的数据库驱动：{self.driver}")
    
    class Config:
        json_schema_extra = {
            "example": {
                "driver": "sqlite",
                "host": "localhost",
                "port": 3306,
                "database": "medclaw",
                "username": "root",
                "password": "password",
                "pool_size": 5
            }
        }


class ModuleSettings(BaseModel):
    """模块通用设置"""
    
    enabled: bool = Field(default=True, description="是否启用模块")
    log_level: str = Field(default="INFO", description="日志级别")
    cache_enabled: bool = Field(default=True, description="是否启用缓存")
    cache_ttl: int = Field(default=300, description="缓存过期时间（秒）")
    max_concurrent_tasks: int = Field(default=5, description="最大并发任务数")
    
    class Config:
        json_schema_extra = {
            "example": {
                "enabled": True,
                "log_level": "INFO",
                "cache_enabled": True,
                "cache_ttl": 300,
                "max_concurrent_tasks": 5
            }
        }


class GlobalSettings(BaseModel):
    """全局设置"""
    
    app_name: str = Field(default="MedClaw", description="应用名称")
    version: str = Field(default="1.0.0", description="版本号")
    debug: bool = Field(default=False, description="调试模式")
    language: str = Field(default="zh-CN", description="语言")
    timezone: str = Field(default="Asia/Shanghai", description="时区")
    
    api: APISettings = Field(default_factory=APISettings, description="API 设置")
    database: DatabaseSettings = Field(default_factory=DatabaseSettings, description="数据库设置")
    module: ModuleSettings = Field(default_factory=ModuleSettings, description="模块设置")
    
    class Config:
        json_schema_extra = {
            "example": {
                "app_name": "MedClaw",
                "version": "1.0.0",
                "debug": False,
                "language": "zh-CN",
                "timezone": "Asia/Shanghai",
                "api": {
                    "base_url": "http://localhost:8000",
                    "timeout": 30
                },
                "database": {
                    "driver": "sqlite",
                    "database": "medclaw"
                },
                "module": {
                    "enabled": True,
                    "log_level": "INFO"
                }
            }
        }


class SettingsManager:
    """设置管理器 - 单例模式"""
    
    _instance = None
    _settings: Optional[GlobalSettings] = None
    _config_file: Path = Path("config.json")
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if self._settings is None:
            self._settings = GlobalSettings()
    
    async def load(self, config_path: Optional[Path] = None) -> GlobalSettings:
        """加载配置"""
        if config_path:
            self._config_file = config_path
        
        if self._config_file.exists():
            try:
                with open(self._config_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                self._settings = GlobalSettings(**data)
                logger.info(f"配置加载成功：{self._config_file}")
            except Exception as e:
                logger.error(f"配置加载失败：{e}")
                self._settings = GlobalSettings()
        else:
            logger.info("配置文件不存在，使用默认配置")
            self._settings = GlobalSettings()
        
        return self._settings
    
    async def save(self, config_path: Optional[Path] = None) -> bool:
        """保存配置"""
        if config_path:
            self._config_file = config_path
        
        try:
            with open(self._config_file, 'w', encoding='utf-8') as f:
                json.dump(self._settings.model_dump(), f, indent=2, ensure_ascii=False)
            logger.info(f"配置已保存：{self._config_file}")
            return True
        except Exception as e:
            logger.error(f"配置保存失败：{e}")
            return False
    
    def get(self) -> GlobalSettings:
        """获取当前配置"""
        return self._settings
    
    def update(self, **kwargs) -> GlobalSettings:
        """更新配置"""
        if 'api' in kwargs:
            self._settings.api = APISettings(**kwargs['api'])
        if 'database' in kwargs:
            self._settings.database = DatabaseSettings(**kwargs['database'])
        if 'module' in kwargs:
            self._settings.module = ModuleSettings(**kwargs['module'])
        
        for key, value in kwargs.items():
            if key not in ['api', 'database', 'module']:
                setattr(self._settings, key, value)
        
        return self._settings
    
    def get_api_settings(self) -> APISettings:
        """获取 API 设置"""
        return self._settings.api
    
    def get_database_settings(self) -> DatabaseSettings:
        """获取数据库设置"""
        return self._settings.database
    
    def get_module_settings(self) -> ModuleSettings:
        """获取模块设置"""
        return self._settings.module


# 全局设置管理器实例
settings_manager = SettingsManager()


# ========== FastAPI 路由 ==========

from fastapi import APIRouter, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel

from .settings_template import get_settings_html_template

router = APIRouter(prefix="/api/settings", tags=["设置管理"])


class SettingsResponse(BaseModel):
    success: bool
    data: Optional[Dict[str, Any]] = None
    message: str = ""


@router.get("", response_model=SettingsResponse)
async def get_settings():
    """获取全部设置"""
    try:
        settings = settings_manager.get()
        return SettingsResponse(
            success=True,
            data=settings.model_dump(),
            message="获取设置成功"
        )
    except Exception as e:
        return SettingsResponse(
            success=False,
            message=f"获取设置失败：{str(e)}"
        )


@router.get("/api", response_model=SettingsResponse)
async def get_api_settings():
    """获取 API 设置"""
    try:
        settings = settings_manager.get_api_settings()
        return SettingsResponse(
            success=True,
            data=settings.model_dump(),
            message="获取 API 设置成功"
        )
    except Exception as e:
        return SettingsResponse(
            success=False,
            message=f"获取 API 设置失败：{str(e)}"
        )


@router.put("/api", response_model=SettingsResponse)
async def update_api_settings(api_settings: APISettings):
    """更新 API 设置"""
    try:
        settings_manager.update(api=api_settings.model_dump())
        await settings_manager.save()
        return SettingsResponse(
            success=True,
            data=api_settings.model_dump(),
            message="API 设置更新成功"
        )
    except Exception as e:
        return SettingsResponse(
            success=False,
            message=f"更新 API 设置失败：{str(e)}"
        )


@router.get("/database", response_model=SettingsResponse)
async def get_database_settings():
    """获取数据库设置"""
    try:
        settings = settings_manager.get_database_settings()
        return SettingsResponse(
            success=True,
            data=settings.model_dump(),
            message="获取数据库设置成功"
        )
    except Exception as e:
        return SettingsResponse(
            success=False,
            message=f"获取数据库设置失败：{str(e)}"
        )


@router.put("/database", response_model=SettingsResponse)
async def update_database_settings(db_settings: DatabaseSettings):
    """更新数据库设置"""
    try:
        settings_manager.update(database=db_settings.model_dump())
        await settings_manager.save()
        return SettingsResponse(
            success=True,
            data=db_settings.model_dump(),
            message="数据库设置更新成功"
        )
    except Exception as e:
        return SettingsResponse(
            success=False,
            message=f"更新数据库设置失败：{str(e)}"
        )


@router.get("/module", response_model=SettingsResponse)
async def get_module_settings():
    """获取模块设置"""
    try:
        settings = settings_manager.get_module_settings()
        return SettingsResponse(
            success=True,
            data=settings.model_dump(),
            message="获取模块设置成功"
        )
    except Exception as e:
        return SettingsResponse(
            success=False,
            message=f"获取模块设置失败：{str(e)}"
        )


@router.put("/module", response_model=SettingsResponse)
async def update_module_settings(module_settings: ModuleSettings):
    """更新模块设置"""
    try:
        settings_manager.update(module=module_settings.model_dump())
        await settings_manager.save()
        return SettingsResponse(
            success=True,
            data=module_settings.model_dump(),
            message="模块设置更新成功"
        )
    except Exception as e:
        return SettingsResponse(
            success=False,
            message=f"更新模块设置失败：{str(e)}"
        )


@router.put("", response_model=SettingsResponse)
async def update_all_settings(settings: GlobalSettings):
    """更新全部设置"""
    try:
        settings_manager.update(**settings.model_dump())
        await settings_manager.save()
        return SettingsResponse(
            success=True,
            data=settings.model_dump(),
            message="全部设置更新成功"
        )
    except Exception as e:
        return SettingsResponse(
            success=False,
            message=f"更新全部设置失败：{str(e)}"
        )


@router.post("/reset", response_model=SettingsResponse)
async def reset_settings():
    """重置为默认设置"""
    try:
        settings_manager._settings = GlobalSettings()
        return SettingsResponse(
            success=True,
            data=settings_manager.get().model_dump(),
            message="设置已重置为默认值"
        )
    except Exception as e:
        return SettingsResponse(
            success=False,
            message=f"重置设置失败：{str(e)}"
        )


@router.get("/page", response_class=HTMLResponse)
async def get_settings_page():
    """获取设置管理页面"""
    return get_settings_html_template()


def get_settings_manager() -> SettingsManager:
    """获取设置管理器实例"""
    return settings_manager


__all__ = [
    "GlobalSettings",
    "APISettings",
    "DatabaseSettings",
    "ModuleSettings",
    "SettingsManager",
    "settings_manager",
    "get_settings_manager",
    "router",
]
