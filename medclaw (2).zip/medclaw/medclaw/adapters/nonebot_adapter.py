"""
QQBot 适配器 - NoneBot2 实现
支持通过 QQ 消息收发执行 MedClaw 功能
"""

import logging
from typing import Any, Callable, Dict, Optional
from datetime import datetime

logger = logging.getLogger(__name__)


class NoneBotAdapter:
    """NoneBot2 QQBot 适配器"""
    
    def __init__(self, config: Dict[str, Any], medclaw_core: Any):
        """
        初始化 NoneBot 适配器
        
        Args:
            config: QQBot 配置
            medclaw_core: MedClaw 核心实例
        """
        self.config = config
        self.medclaw = medclaw_core
        self.app = None
        self.commands = {}
        
        self._register_commands()
    
    def _register_commands(self):
        """注册命令"""
        self.commands = {
            "病历": self._handle_medical_record,
            "质控": self._handle_quality_check,
            "医保": self._handle_insurance_analysis,
            "预测": self._handle_prediction,
            "阅片": self._handle_ai_reading,
            "科研": self._handle_research,
            "论文": self._handle_paper,
            "帮助": self._handle_help,
        }
    
    async def initialize(self):
        """初始化 NoneBot 应用"""
        try:
            from nonebot import init, on_command, on_message
            from nonebot.adapters import Message
            from nonebot.params import CommandArg, MessageText
            from nonebot.plugin import PluginMetadata
            
            init(driver=self.config.get("driver", "~fastapi+~websockets"))
            
            @on_command("病历", aliases={"病历书写", "生成病历"}).handle()
            async def _(bot, event, args: Message = CommandArg()):
                input_text = str(args).strip()
                response = await self._handle_medical_record(input_text)
                await bot.send(event, response)
            
            @on_command("质控", aliases={"病历质控", "质量检查"}).handle()
            async def _(bot, event, args: Message = CommandArg()):
                input_text = str(args).strip()
                response = await self._handle_quality_check(input_text)
                await bot.send(event, response)
            
            @on_command("医保", aliases={"医保分析", "费用分析"}).handle()
            async def _(bot, event, args: Message = CommandArg()):
                input_text = str(args).strip()
                response = await self._handle_insurance_analysis(input_text)
                await bot.send(event, response)
            
            @on_command("预测", aliases={"临床预测", "风险预测"}).handle()
            async def _(bot, event, args: Message = CommandArg()):
                input_text = str(args).strip()
                response = await self._handle_prediction(input_text)
                await bot.send(event, response)
            
            @on_command("阅片", aliases={"AI 阅片", "影像分析"}).handle()
            async def _(bot, event, args: Message = CommandArg()):
                input_text = str(args).strip()
                response = await self._handle_ai_reading(input_text)
                await bot.send(event, response)
            
            @on_command("科研", aliases={"科研分析", "统计分析"}).handle()
            async def _(bot, event, args: Message = CommandArg()):
                input_text = str(args).strip()
                response = await self._handle_research(input_text)
                await bot.send(event, response)
            
            @on_command("论文", aliases={"论文分析", "文献分析"}).handle()
            async def _(bot, event, args: Message = CommandArg()):
                input_text = str(args).strip()
                response = await self._handle_paper(input_text)
                await bot.send(event, response)
            
            @on_command("帮助", aliases={"help", "HELP"}).handle()
            async def _(bot, event, args: Message = CommandArg()):
                response = await self._handle_help("")
                await bot.send(event, response)
            
            logger.info("NoneBot 命令注册完成")
            
        except Exception as e:
            logger.error(f"初始化 NoneBot 失败：{e}")
    
    async def _handle_medical_record(self, input_text: str) -> str:
        """处理病历书写命令"""
        try:
            module = self.medclaw.get_module("medical_record")
            input_data = self._parse_input(input_text)
            result = await module.execute(action="generate", input_data=input_data)
            return module.format_output(result)
        except Exception as e:
            return f"病历生成失败：{str(e)}"
    
    async def _handle_quality_check(self, input_text: str) -> str:
        """处理质控命令"""
        try:
            module = self.medclaw.get_module("medical_quality")
            medical_record_id = input_text.replace("病历 ID", "").strip()
            
            medical_record = self._get_medical_record(medical_record_id)
            result = await module.execute(medical_record=medical_record)
            return module.format_output(result)
        except Exception as e:
            return f"质控失败：{str(e)}"
    
    async def _handle_insurance_analysis(self, input_text: str) -> str:
        """处理医保分析命令"""
        try:
            module = self.medclaw.get_module("insurance_analysis")
            medical_record_id = input_text.replace("病历 ID", "").replace("分析", "").strip()
            
            medical_record = self._get_medical_record(medical_record_id)
            result = await module.execute(medical_record=medical_record)
            return module.format_output(result)
        except Exception as e:
            return f"医保分析失败：{str(e)}"
    
    async def _handle_prediction(self, input_text: str) -> str:
        """处理临床预测命令"""
        try:
            module = self.medclaw.get_module("clinical_prediction")
            prediction_data = self._parse_prediction_input(input_text)
            result = await module.execute(**prediction_data)
            return module.format_output(result)
        except Exception as e:
            return f"预测失败：{str(e)}"
    
    async def _handle_ai_reading(self, input_text: str) -> str:
        """处理 AI 阅片命令"""
        try:
            module = self.medclaw.get_module("ai_reading")
            
            if "http" in input_text:
                image_path = input_text.split()[-1]
            else:
                image_path = input_text.replace("图片：", "").strip()
            
            result = await module.execute(image_path=image_path, image_type="ct")
            return module.format_output(result)
        except Exception as e:
            return f"AI 阅片失败：{str(e)}"
    
    async def _handle_research(self, input_text: str) -> str:
        """处理科研分析命令"""
        try:
            module = self.medclaw.get_module("research_analysis")
            
            if ".csv" in input_text or ".xlsx" in input_text:
                data_file = input_text.split()[-1]
                data = self._load_data_file(data_file)
            else:
                data = self._parse_research_input(input_text)
            
            result = await module.execute(data=data, analysis_type="descriptive")
            return module.format_output(result)
        except Exception as e:
            return f"科研分析失败：{str(e)}"
    
    async def _handle_paper(self, input_text: str) -> str:
        """处理论文分析命令"""
        try:
            module = self.medclaw.get_module("paper_analysis")
            
            if "http" in input_text:
                result = await module.execute(paper_input=input_text, input_type="url")
            elif ".pdf" in input_text or ".txt" in input_text:
                result = await module.execute(paper_input=input_text, input_type="file")
            else:
                result = await module.execute(paper_input=input_text, input_type="text")
            
            return module.format_output(result)
        except Exception as e:
            return f"论文分析失败：{str(e)}"
    
    async def _handle_help(self, _: str) -> str:
        """处理帮助命令"""
        help_text = """MedClaw 医学自动化助手 - 使用帮助

可用命令:
  /病历 [患者信息]          - 生成病历
  /质控 [病历 ID]           - 病历质量检查
  /医保 [病历 ID]           - 医保费用分析
  /预测 [预测类型] [参数]    - 临床风险预测
  /阅片 [图片/URL]          - AI 影像分析
  /科研 [数据文件/数据]      - 统计分析
  /论文 [文件/URL/文本]      - 论文分析
  /帮助                     - 显示此帮助信息

示例:
  /病历 患者张三，男性，45 岁，主诉头痛三天
  /质控 病历 ID 12345
  /预测 败血症风险 年龄:70, 体温:39, 心率:110
  /阅片 图片：https://example.com/ct.dcm
  /科研 分析 data.csv 中的血压变化
  /论文 摘要：https://example.com/paper.pdf

MedClaw v1.0.0"""
        return help_text
    
    def _parse_input(self, text: str) -> Dict[str, Any]:
        """解析输入文本"""
        data = {
            "patient_info": {},
            "chief_complaint": "",
            "present_illness": ""
        }
        
        if "患者" in text:
            parts = text.split("，")
            for part in parts:
                if "患者" in part:
                    name_part = part.replace("患者", "").strip()
                    data["patient_info"]["name"] = name_part.split(",")[0]
                elif "男性" in part or "女性" in part:
                    data["patient_info"]["gender"] = "男" if "男性" in part else "女"
                elif "岁" in part:
                    age = int(part.replace("岁", "").strip())
                    data["patient_info"]["age"] = age
                elif "主诉" in part:
                    data["chief_complaint"] = part.replace("主诉", "").strip()
                else:
                    data["present_illness"] += part + " "
        
        return data
    
    def _parse_prediction_input(self, text: str) -> Dict[str, Any]:
        """解析预测输入"""
        parts = text.split()
        model_name = "sepsis"
        patient_data = {}
        
        if "败血症" in text:
            model_name = "sepsis"
        elif "并发症" in text:
            model_name = "complication"
        elif "再入院" in text:
            model_name = "readmission"
        
        for part in parts:
            if ":" in part or "：" in part:
                key, value = part.replace("：", ":").split(":", 1)
                key = key.strip().lower()
                value = value.strip()
                
                if key == "年龄":
                    patient_data["age"] = float(value)
                elif key == "体温":
                    patient_data["temperature"] = float(value)
                elif key == "心率":
                    patient_data["heart_rate"] = float(value)
                elif key == "呼吸":
                    patient_data["respiratory_rate"] = float(value)
                elif key == "白细胞":
                    patient_data["wbc"] = float(value)
        
        return {"model_name": model_name, "patient_data": patient_data}
    
    def _get_medical_record(self, record_id: str) -> Dict[str, Any]:
        """获取病历数据（模拟）"""
        return {
            "id": record_id,
            "chief_complaint": "头痛三天",
            "present_illness": "患者三天前无明显诱因出现头痛...",
            "diagnosis": "紧张性头痛",
            "patient_age": 45,
            "cost_details": {
                "total": 5000,
                "drugs": 1500,
                "examinations": 2000,
                "consumables": 500
            }
        }
    
    def _load_data_file(self, filepath: str) -> Dict[str, Any]:
        """加载数据文件"""
        import pandas as pd
        try:
            if filepath.endswith('.csv'):
                df = pd.read_csv(filepath)
            elif filepath.endswith('.xlsx'):
                df = pd.read_excel(filepath)
            else:
                return {}
            
            data = {}
            for col in df.columns:
                data[col] = df[col].dropna().tolist()
            return data
        except Exception as e:
            logger.error(f"加载数据文件失败：{e}")
            return {}
    
    def run(self):
        """运行 NoneBot 应用"""
        import nonebot
        from nonebot.adapters import Adapter
        
        nonebot.run(host=self.config.get("host", "127.0.0.1"), 
                   port=self.config.get("port", 8080))
