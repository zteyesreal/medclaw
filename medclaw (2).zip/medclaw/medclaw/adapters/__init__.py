"""MedClaw 适配器模块"""

try:
    from .nonebot_adapter import NoneBotAdapter
    __all__ = ["NoneBotAdapter"]
except ImportError:
    NoneBotAdapter = None

try:
    from .gocqhttp_adapter import GoCQHTTPAdapter
    __all__.append("GoCQHTTPAdapter")
except ImportError:
    GoCQHTTPAdapter = None
