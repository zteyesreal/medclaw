"""
QQBot 适配器 - go-cqhttp 实现
通过 WebSocket 与 go-cqhttp 通信
"""

import json
import asyncio
import logging
from typing import Any, Callable, Dict, Optional
from datetime import datetime
import websockets

logger = logging.getLogger(__name__)


class GoCQHTTPAdapter:
    """go-cqhttp QQBot 适配器"""
    
    def __init__(self, config: Dict[str, Any], medclaw_core: Any):
        """
        初始化 go-cqhttp 适配器
        
        Args:
            config: QQBot 配置
            medclaw_core: MedClaw 核心实例
        """
        self.config = config
        self.medclaw = medclaw_core
        self.websocket_url = config.get("websocket", "ws://127.0.0.1:6700")
        self.ws = None
        self.running = False
        self.commands = {}
        
        self._register_commands()
    
    def _register_commands(self):
        """注册命令"""
        self.commands = {
            "/病历": self._handle_medical_record,
            "/质控": self._handle_quality_check,
            "/医保": self._handle_insurance_analysis,
            "/预测": self._handle_prediction,
            "/阅片": self._handle_ai_reading,
            "/科研": self._handle_research,
            "/论文": self._handle_paper,
            "/帮助": self._handle_help,
        }
    
    async def connect(self):
        """连接到 go-cqhttp"""
        try:
            self.ws = await websockets.connect(self.websocket_url)
            logger.info(f"成功连接到 go-cqhttp: {self.websocket_url}")
            return True
        except Exception as e:
            logger.error(f"连接 go-cqhttp 失败：{e}")
            return False
    
    async def disconnect(self):
        """断开连接"""
        self.running = False
        if self.ws:
            await self.ws.close()
    
    async def send_message(self, user_id: Optional[int], group_id: Optional[int], message: str):
        """
        发送消息
        
        Args:
            user_id: 用户 QQ 号
            group_id: 群号
            message: 消息内容
        """
        if not self.ws:
            logger.error("WebSocket 未连接")
            return
        
        if group_id:
            payload = {
                "action": "send_group_msg",
                "params": {
                    "group_id": group_id,
                    "message": message
                }
            }
        else:
            payload = {
                "action": "send_private_msg",
                "params": {
                    "user_id": user_id,
                    "message": message
                }
            }
        
        await self.ws.send(json.dumps(payload))
    
    async def start_listening(self):
        """开始监听消息"""
        if not self.ws:
            connected = await self.connect()
            if not connected:
                return
        
        self.running = True
        logger.info("开始监听 QQ 消息...")
        
        try:
            async for message in self.ws:
                if not self.running:
                    break
                
                data = json.loads(message)
                
                if data.get("post_type") == "message":
                    await self._process_message(data)
        except Exception as e:
            logger.error(f"监听消息时出错：{e}")
        finally:
            await self.disconnect()
    
    async def _process_message(self, data: Dict[str, Any]):
        """
        处理收到的消息
        
        Args:
            data: 消息数据
        """
        message_type = data.get("message_type")
        user_id = data.get("user_id")
        group_id = data.get("group_id")
        raw_message = data.get("message", "")
        
        message = raw_message.strip()
        
        for cmd, handler in self.commands.items():
            if message.startswith(cmd):
                input_text = message[len(cmd):].strip()
                
                try:
                    response = await handler(input_text)
                    
                    await self.send_message(user_id, group_id, response)
                except Exception as e:
                    error_msg = f"执行命令失败：{str(e)}"
                    await self.send_message(user_id, group_id, error_msg)
                
                break
    
    async def _handle_medical_record(self, input_text: str) -> str:
        """处理病历书写命令"""
        try:
            module = self.medclaw.get_module("medical_record")
            input_data = self._parse_input(input_text)
            result = await module.execute(action="generate", input_data=input_data)
            return module.format_output(result)
        except Exception as e:
            return f"病历生成失败：{str(e)}"
    
    async def _handle_quality_check(self, input_text: str) -> str:
        """处理质控命令"""
        try:
            module = self.medclaw.get_module("medical_quality")
            medical_record_id = input_text.replace("病历 ID", "").strip()
            medical_record = self._get_medical_record(medical_record_id)
            result = await module.execute(medical_record=medical_record)
            return module.format_output(result)
        except Exception as e:
            return f"质控失败：{str(e)}"
    
    async def _handle_insurance_analysis(self, input_text: str) -> str:
        """处理医保分析命令"""
        try:
            module = self.medclaw.get_module("insurance_analysis")
            medical_record_id = input_text.replace("病历 ID", "").replace("分析", "").strip()
            medical_record = self._get_medical_record(medical_record_id)
            result = await module.execute(medical_record=medical_record)
            return module.format_output(result)
        except Exception as e:
            return f"医保分析失败：{str(e)}"
    
    async def _handle_prediction(self, input_text: str) -> str:
        """处理临床预测命令"""
        try:
            module = self.medclaw.get_module("clinical_prediction")
            prediction_data = self._parse_prediction_input(input_text)
            result = await module.execute(**prediction_data)
            return module.format_output(result)
        except Exception as e:
            return f"预测失败：{str(e)}"
    
    async def _handle_ai_reading(self, input_text: str) -> str:
        """处理 AI 阅片命令"""
        try:
            module = self.medclaw.get_module("ai_reading")
            image_path = input_text.replace("图片：", "").strip()
            result = await module.execute(image_path=image_path, image_type="ct")
            return module.format_output(result)
        except Exception as e:
            return f"AI 阅片失败：{str(e)}"
    
    async def _handle_research(self, input_text: str) -> str:
        """处理科研分析命令"""
        try:
            module = self.medclaw.get_module("research_analysis")
            data = self._parse_research_input(input_text)
            result = await module.execute(data=data, analysis_type="descriptive")
            return module.format_output(result)
        except Exception as e:
            return f"科研分析失败：{str(e)}"
    
    async def _handle_paper(self, input_text: str) -> str:
        """处理论文分析命令"""
        try:
            module = self.medclaw.get_module("paper_analysis")
            
            if "http" in input_text:
                result = await module.execute(paper_input=input_text, input_type="url")
            elif ".pdf" in input_text or ".txt" in input_text:
                result = await module.execute(paper_input=input_text, input_type="file")
            else:
                result = await module.execute(paper_input=input_text, input_type="text")
            
            return module.format_output(result)
        except Exception as e:
            return f"论文分析失败：{str(e)}"
    
    async def _handle_help(self, _: str) -> str:
        """处理帮助命令"""
        help_text = """MedClaw 医学自动化助手 - 使用帮助

可用命令:
  /病历 [患者信息]          - 生成病历
  /质控 [病历 ID]           - 病历质量检查
  /医保 [病历 ID]           - 医保费用分析
  /预测 [预测类型] [参数]    - 临床风险预测
  /阅片 [图片/URL]          - AI 影像分析
  /科研 [数据文件/数据]      - 统计分析
  /论文 [文件/URL/文本]      - 论文分析
  /帮助                     - 显示此帮助信息

示例:
  /病历 患者张三，男性，45 岁，主诉头痛三天
  /质控 病历 ID 12345
  /预测 败血症风险 年龄:70, 体温:39, 心率:110
  /阅片 图片：https://example.com/ct.dcm

MedClaw v1.0.0"""
        return help_text
    
    def _parse_input(self, text: str) -> Dict[str, Any]:
        """解析输入文本"""
        data = {
            "patient_info": {},
            "chief_complaint": "",
            "present_illness": ""
        }
        
        if "患者" in text:
            parts = text.split("，")
            for part in parts:
                if "患者" in part:
                    name_part = part.replace("患者", "").strip()
                    data["patient_info"]["name"] = name_part.split(",")[0]
                elif "男性" in part or "女性" in part:
                    data["patient_info"]["gender"] = "男" if "男性" in part else "女"
                elif "岁" in part:
                    age = int(part.replace("岁", "").strip())
                    data["patient_info"]["age"] = age
                elif "主诉" in part:
                    data["chief_complaint"] = part.replace("主诉", "").strip()
                else:
                    data["present_illness"] += part + " "
        
        return data
    
    def _parse_prediction_input(self, text: str) -> Dict[str, Any]:
        """解析预测输入"""
        parts = text.split()
        model_name = "sepsis"
        patient_data = {}
        
        if "败血症" in text:
            model_name = "sepsis"
        elif "并发症" in text:
            model_name = "complication"
        elif "再入院" in text:
            model_name = "readmission"
        
        for part in parts:
            if ":" in part or "：" in part:
                key, value = part.replace("：", ":").split(":", 1)
                key = key.strip().lower()
                value = value.strip()
                
                if key == "年龄":
                    patient_data["age"] = float(value)
                elif key == "体温":
                    patient_data["temperature"] = float(value)
                elif key == "心率":
                    patient_data["heart_rate"] = float(value)
                elif key == "呼吸":
                    patient_data["respiratory_rate"] = float(value)
                elif key == "白细胞":
                    patient_data["wbc"] = float(value)
        
        return {"model_name": model_name, "patient_data": patient_data}
    
    def _get_medical_record(self, record_id: str) -> Dict[str, Any]:
        """获取病历数据（模拟）"""
        return {
            "id": record_id,
            "chief_complaint": "头痛三天",
            "present_illness": "患者三天前无明显诱因出现头痛...",
            "diagnosis": "紧张性头痛",
            "patient_age": 45,
            "cost_details": {
                "total": 5000,
                "drugs": 1500,
                "examinations": 2000,
                "consumables": 500
            }
        }
    
    def _parse_research_input(self, text: str) -> Dict[str, Any]:
        """解析科研分析输入"""
        data = {}
        
        if "血压" in text:
            data["blood_pressure"] = [120, 125, 130, 128, 135, 140, 138]
            data["time_points"] = ["第 1 天", "第 2 天", "第 3 天", "第 4 天", "第 5 天", "第 6 天", "第 7 天"]
        
        return data
