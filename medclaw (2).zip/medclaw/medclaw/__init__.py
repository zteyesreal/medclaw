"""
MedClaw - 医学自动化助手
医疗场景设计的自动化助手，辅助医生完成病历书写、质控、医保分析等工作
"""

__version__ = "1.0.0"
__author__ = "MedClaw Team"
