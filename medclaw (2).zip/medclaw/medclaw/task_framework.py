"""
MedClaw 任务执行框架 - 基于 OpenClaw 模式
七个医疗职业场景的任务模板
"""

from typing import Dict, List, Optional, Any
from pydantic import BaseModel
from datetime import datetime
import json


# ========== 基础任务模型 ==========

class Task(BaseModel):
    """OpenClaw 风格的任务定义"""
    id: str
    name: str
    description: str
    profession: str  # 职业场景
    goal: str  # 任务目标
    steps: List[Dict[str, Any]]  # 执行步骤
    status: str = "pending"  # pending, running, completed, failed
    result: Optional[Any] = None
    created_at: str = ""
    completed_at: Optional[str] = None
    
    def __init__(self, **data):
        if 'created_at' not in data:
            data['created_at'] = datetime.now().isoformat()
        super().__init__(**data)


class TaskTemplate(BaseModel):
    """任务模板"""
    id: str
    name: str
    profession: str
    description: str
    goal_template: str
    default_steps: List[Dict[str, Any]]
    estimated_duration: str
    required_skills: List[str]


# ========== 七个医疗职业的任务模板 ==========

PROFESSION_TASK_TEMPLATES = {
    # 1. 临床医生任务模板
    "clinician": [
        TaskTemplate(
            id="clinician_001",
            name="门诊接诊",
            profession="clinician",
            description="完成一次完整的门诊接诊流程",
            goal_template="为患者 {patient_name} 完成门诊接诊，生成规范病历",
            default_steps=[
                {"action": "get_patient_info", "params": {"patient_id": "{patient_id}"}},
                {"action": "collect_chief_complaint", "params": {}},
                {"action": "analyze_present_illness", "params": {}},
                {"action": "review_past_history", "params": {}},
                {"action": "perform_physical_exam", "params": {}},
                {"action": "order_labs", "params": {"urgency": "routine"}},
                {"action": "make_diagnosis", "params": {"use_icd10": True}},
                {"action": "create_treatment_plan", "params": {}},
                {"action": "generate_medical_record", "params": {"template": "outpatient"}}
            ],
            estimated_duration="15 分钟",
            required_skills=["病历书写", "诊断思维", "处方开具"]
        ),
        TaskTemplate(
            id="clinician_002",
            name="住院查房",
            profession="clinician",
            description="完成住院患者查房并记录病程",
            goal_template="完成 {ward} 病区 {bed_count} 张床位的查房",
            default_steps=[
                {"action": "get_ward_patients", "params": {"ward": "{ward}"}},
                {"action": "check_vitals", "params": {}},
                {"action": "review_overnight_events", "params": {}},
                {"action": "perform_bedside_exam", "params": {}},
                {"action": "review_new_labs", "params": {}},
                {"action": "adjust_orders", "params": {}},
                {"action": "document_progress_note", "params": {}}
            ],
            estimated_duration="2 小时",
            required_skills=["查房流程", "病程记录", "医嘱调整"]
        ),
        TaskTemplate(
            id="clinician_003",
            name="急诊抢救",
            profession="clinician",
            description="急诊危重患者抢救",
            goal_template="抢救 {chief_complaint} 患者，稳定生命体征",
            default_steps=[
                {"action": "primary_survey", "params": {"protocol": "ABCDE"}},
                {"action": "monitor_vitals", "params": {"frequency": "continuous"}},
                {"action": "establish_iv_access", "params": {}},
                {"action": "order_emergency_labs", "params": {"priority": "stat"}},
                {"action": "initiate_treatment", "params": {"protocol": "{protocol}"}},
                {"action": "consult_specialists", "params": {}},
                {"action": "document_resuscitation", "params": {}}
            ],
            estimated_duration="30-60 分钟",
            required_skills=["ACLS", "气管插管", "深静脉穿刺"]
        )
    ],
    
    # 2. 病历质控员任务模板
    "quality_controller": [
        TaskTemplate(
            id="qc_001",
            name="运行病历质控",
            profession="quality_controller",
            description="对在院病历进行实时质控",
            goal_template="完成 {department} 科室 {record_count} 份运行病历的质控检查",
            default_steps=[
                {"action": "fetch_active_records", "params": {"department": "{department}"}},
                {"action": "check_completeness", "params": {"standard": "甲级病历"}},
                {"action": "check_timeliness", "params": {}},
                {"action": "validate_icd10", "params": {}},
                {"action": "detect_issues", "params": {}},
                {"action": "generate_feedback", "params": {}},
                {"action": "notify_physicians", "params": {}}
            ],
            estimated_duration="1 小时",
            required_skills=["病历规范", "ICD 编码", "质控标准"]
        ),
        TaskTemplate(
            id="qc_002",
            name="终末病历评审",
            profession="quality_controller",
            description="对出院病历进行终末质量评审",
            goal_template="评审 {month} 月份 {record_count} 份出院病历",
            default_steps=[
                {"action": "fetch_discharged_records", "params": {"month": "{month}"}},
                {"action": "score_quality", "params": {"standard": "评分标准 2024"}},
                {"action": "check_critical_items", "params": {}},
                {"action": "review_consultations", "params": {}},
                {"action": "validate_signatures", "params": {}},
                {"action": "generate_quality_report", "params": {}},
                {"action": "submit_to_committee", "params": {}}
            ],
            estimated_duration="2 小时",
            required_skills=["质量评分", "缺陷识别", "报告撰写"]
        )
    ],
    
    # 3. 医保审核员任务模板
    "insurance_auditor": [
        TaskTemplate(
            id="insurance_001",
            name="DRG 分组审核",
            profession="insurance_auditor",
            description="审核出院病例的 DRG 分组合理性",
            goal_template="审核 {month} 月份 {case_count} 个病例的 DRG 分组",
            default_steps=[
                {"action": "fetch_cases", "params": {"month": "{month}"}},
                {"action": "validate_main_diagnosis", "params": {}},
                {"action": "check_complications", "params": {}},
                {"action": "review_procedures", "params": {}},
                {"action": "calculate_dr_weight", "params": {}},
                {"action": "detect_upcoding", "params": {}},
                {"action": "generate_audit_report", "params": {}}
            ],
            estimated_duration="1.5 小时",
            required_skills=["DRG 分组", "病案首页", "医保政策"]
        ),
        TaskTemplate(
            id="insurance_002",
            name="费用合规性检查",
            profession="insurance_auditor",
            description="检查医疗费用的医保合规性",
            goal_template="检查 {department} 科室 {date_range} 的费用合规性",
            default_steps=[
                {"action": "fetch_cost_details", "params": {"department": "{department}"}},
                {"action": "check_drug_usage", "params": {"policy": "抗生素分级"}},
                {"action": "validate_examinations", "params": {}},
                {"action": "detect_overuse", "params": {}},
                {"action": "calculate_rejection_rate", "params": {}},
                {"action": "generate_compliance_report", "params": {}}
            ],
            estimated_duration="1 小时",
            required_skills=["费用审核", "医保目录", "合理用药"]
        )
    ],
    
    # 4. 放射科医师任务模板
    "radiologist": [
        TaskTemplate(
            id="radio_001",
            name="CT 报告书写",
            profession="radiologist",
            description="完成 CT 检查的报告书写",
            goal_template="完成 {body_part}CT{count} 例的报告书写",
            default_steps=[
                {"action": "fetch_exam_queue", "params": {"modality": "CT", "body_part": "{body_part}"}},
                {"action": "load_images", "params": {"study_id": "{study_id}"}},
                {"action": "ai_assisted_reading", "params": {"model": "lung_nodule_v2"}},
                {"action": "identify_findings", "params": {}},
                {"action": "measure_lesions", "params": {}},
                {"action": "dictate_report", "params": {"template": "standard"}},
                {"action": "review_and_sign", "params": {}},
                {"action": "send_to_clinician", "params": {}}
            ],
            estimated_duration="10 分钟/例",
            required_skills=["影像诊断", "解剖知识", "报告规范"]
        ),
        TaskTemplate(
            id="radio_002",
            name="急诊影像会诊",
            profession="radiologist",
            description="急诊影像紧急会诊",
            goal_template="完成 {emergency_type} 的急诊影像会诊",
            default_steps=[
                {"action": "receive_emergency_call", "params": {}},
                {"action": "prioritize_case", "params": {"level": "stat"}},
                {"action": "rapid_reading", "params": {"time_limit": "10 分钟"}},
                {"action": "identify_critical_findings", "params": {}},
                {"action": "call_clinician", "params": {}},
                {"action": "document_consultation", "params": {}}
            ],
            estimated_duration="15 分钟",
            required_skills=["急诊影像", "快速诊断", "危急值报告"]
        )
    ],
    
    # 5. 临床药师任务模板
    "clinical_pharmacist": [
        TaskTemplate(
            id="pharm_001",
            name="处方审核",
            profession="clinical_pharmacist",
            description="审核医师开具的处方合理性",
            goal_template="审核 {department} 科室 {prescription_count} 张处方",
            default_steps=[
                {"action": "fetch_prescriptions", "params": {"department": "{department}"}},
                {"action": "check_drug_interactions", "params": {}},
                {"action": "validate_dosage", "params": {}},
                {"action": "check_allergies", "params": {}},
                {"action": "review_renal_function", "params": {}},
                {"action": "flag_issues", "params": {}},
                {"action": "contact_physician", "params": {}},
                {"action": "document_intervention", "params": {}}
            ],
            estimated_duration="30 分钟",
            required_skills=["药理学", "药物相互作用", "处方审核"]
        ),
        TaskTemplate(
            id="pharm_002",
            name="抗菌药物专项点评",
            profession="clinical_pharmacist",
            description="抗菌药物使用专项点评",
            goal_template="点评 {month} 月份抗菌药物使用合理性",
            default_steps=[
                {"action": "fetch_antibiotic_cases", "params": {"month": "{month}"}},
                {"action": "check_indication", "params": {}},
                {"action": "validate_selection", "params": {"guideline": "抗菌药物指导原则"}},
                {"action": "review_duration", "params": {}},
                {"action": "calculate_aud", "params": {}},
                {"action": "generate_feedback", "params": {}},
                {"action": "present_to_committee", "params": {}}
            ],
            estimated_duration="2 小时",
            required_skills=["抗菌药物", "指南解读", "DDD 计算"]
        )
    ],
    
    # 6. 科研人员任务模板
    "researcher": [
        TaskTemplate(
            id="research_001",
            name="临床数据提取",
            profession="researcher",
            description="从 EMR 系统提取临床研究数据",
            goal_template="提取 {disease} 患者 {sample_size} 例的临床数据",
            default_steps=[
                {"action": "define_inclusion_criteria", "params": {"disease": "{disease}"}},
                {"action": "query_emr", "params": {"date_range": "{date_range}"}},
                {"action": "extract_demographics", "params": {}},
                {"action": "extract_labs", "params": {}},
                {"action": "extract_outcomes", "params": {}},
                {"action": "deidentify_data", "params": {}},
                {"action": "export_to_csv", "params": {}},
                {"action": "document_extraction", "params": {}}
            ],
            estimated_duration="3 小时",
            required_skills=["数据提取", "SQL", "伦理规范"]
        ),
        TaskTemplate(
            id="research_002",
            name="统计分析",
            profession="researcher",
            description="完成临床研究的统计分析",
            goal_template="完成 {study_name} 的统计分析",
            default_steps=[
                {"action": "load_dataset", "params": {"file": "{data_file}"}},
                {"action": "data_cleaning", "params": {}},
                {"action": "descriptive_stats", "params": {}},
                {"action": "univariate_analysis", "params": {}},
                {"action": "multivariate_analysis", "params": {"method": "logistic"}},
                {"action": "survival_analysis", "params": {}},
                {"action": "generate_tables", "params": {}},
                {"action": "interpret_results", "params": {}}
            ],
            estimated_duration="1 天",
            required_skills=["统计学", "R/Python", "研究设计"]
        )
    ],
    
    # 7. 护士任务模板
    "nurse": [
        TaskTemplate(
            id="nurse_001",
            name="入院评估",
            profession="nurse",
            description="完成新入院患者的护理评估",
            goal_template="完成 {patient_name} 的入院护理评估",
            default_steps=[
                {"action": "receive_admission_order", "params": {}},
                {"action": "prepare_room", "params": {}},
                {"action": "greet_patient", "params": {}},
                {"action": "collect_nursing_history", "params": {}},
                {"action": "assess_adl", "params": {"scale": "Barthel"}},
                {"action": "assess_fall_risk", "params": {"scale": "Morse"}},
                {"action": "create_nursing_plan", "params": {}},
                {"action": "document_assessment", "params": {}}
            ],
            estimated_duration="30 分钟",
            required_skills=["护理评估", "沟通技巧", "护理计划"]
        ),
        TaskTemplate(
            id="nurse_002",
            name="执行医嘱",
            profession="nurse",
            description="执行医师开具的医嘱",
            goal_template="执行 {shift} 班次的所有医嘱",
            default_steps=[
                {"action": "fetch_orders", "params": {"shift": "{shift}"}},
                {"action": "verify_orders", "params": {}},
                {"action": "prepare_medications", "params": {}},
                {"action": "administer_medications", "params": {"check": "三查七对"}},
                {"action": "perform_treatments", "params": {}},
                {"action": "document_execution", "params": {}},
                {"action": "monitor_response", "params": {}}
            ],
            estimated_duration="8 小时班次",
            required_skills=["给药技术", "无菌操作", "医嘱执行"]
        )
    ],
    
    # 8. 急诊科医师任务模板 (新增)
    "emergency_physician": [
        TaskTemplate(
            id="emergency_001",
            name="急诊分诊",
            profession="emergency_physician",
            description="对急诊患者进行快速分诊和优先级评估",
            goal_template="完成急诊患者 {patient_name} 的分诊评估",
            default_steps=[
                {"action": "primary_survey", "params": {}},
                {"action": "assess_vital_signs", "params": {}},
                {"action": "collect_chief_complaint", "params": {}},
                {"action": "triage_level_assessment", "params": {}},
                {"action": "assign_treatment_area", "params": {}},
                {"action": "notify_team", "params": {}},
                {"action": "initiate_monitoring", "params": {}}
            ],
            estimated_duration="5 分钟",
            required_skills=["急诊分诊", "生命体征评估", "优先级判断"]
        ),
        TaskTemplate(
            id="emergency_002",
            name="心肺复苏",
            profession="emergency_physician",
            description="对心跳骤停患者进行心肺复苏抢救",
            goal_template="对心跳骤停患者 {patient_name} 进行心肺复苏",
            default_steps=[
                {"action": "assess_responsiveness", "params": {}},
                {"action": "call_for_help", "params": {}},
                {"action": "check_pulse", "params": {}},
                {"action": "start_chest_compressions", "params": {}},
                {"action": "manage_airway", "params": {}},
                {"action": "provide_ventilation", "params": {}},
                {"action": "attach_defibrillator", "params": {}},
                {"action": "administer_emergency_drugs", "params": {}},
                {"action": "document_resuscitation", "params": {}}
            ],
            estimated_duration="30 分钟",
            required_skills=["心肺复苏", "高级气道管理", "急救药物使用"]
        ),
        TaskTemplate(
            id="emergency_003",
            name="创伤评估",
            profession="emergency_physician",
            description="对创伤患者进行系统化评估和处理",
            goal_template="完成创伤患者 {patient_name} 的系统化评估",
            default_steps=[
                {"action": "primary_survey_abcd", "params": {}},
                {"action": "control_hemorrhage", "params": {}},
                {"action": "assess_neurological_status", "params": {}},
                {"action": "expose_and_examine", "params": {}},
                {"action": "secondary_survey", "params": {}},
                {"action": "order_emergency_imaging", "params": {}},
                {"action": "consult_surgery", "params": {}},
                {"action": "prepare_for_transfer", "params": {}}
            ],
            estimated_duration="15 分钟",
            required_skills=["创伤评估", "止血技术", "急救处理"]
        )
    ],
    
    # 9. 康复科医师任务模板 (新增)
    "rehabilitation_physician": [
        TaskTemplate(
            id="rehab_001",
            name="康复评估",
            profession="rehabilitation_physician",
            description="对患者进行全面的康复功能评估",
            goal_template="完成患者 {patient_name} 的康复功能评估",
            default_steps=[
                {"action": "collect_medical_history", "params": {}},
                {"action": "assess_motor_function", "params": {}},
                {"action": "evaluate_adl", "params": {}},
                {"action": "assess_cognitive_function", "params": {}},
                {"action": "evaluate_speech_language", "params": {}},
                {"action": "assess_swallowing", "params": {}},
                {"action": "generate_rehab_diagnosis", "params": {}},
                {"action": "create_rehab_plan", "params": {}}
            ],
            estimated_duration="40 分钟",
            required_skills=["康复评估", "功能评定", "康复诊断"]
        ),
        TaskTemplate(
            id="rehab_002",
            name="运动疗法",
            profession="rehabilitation_physician",
            description="为患者制定和实施运动疗法方案",
            goal_template="为患者 {patient_name} 实施运动疗法",
            default_steps=[
                {"action": "review_rehab_assessment", "params": {}},
                {"action": "set_rehab_goals", "params": {}},
                {"action": "design_exercise_program", "params": {}},
                {"action": "teach_exercise_techniques", "params": {}},
                {"action": "monitor_exercise_response", "params": {}},
                {"action": "adjust_exercise_intensity", "params": {}},
                {"action": "document_progress", "params": {}},
                {"action": "schedule_next_session", "params": {}}
            ],
            estimated_duration="30 分钟",
            required_skills=["运动疗法", "康复训练", "功能锻炼"]
        ),
        TaskTemplate(
            id="rehab_003",
            name="作业疗法",
            profession="rehabilitation_physician",
            description="为患者提供作业疗法训练，提高日常生活能力",
            goal_template="为患者 {patient_name} 实施作业疗法",
            default_steps=[
                {"action": "assess_adl_limitations", "params": {}},
                {"action": "identify_meaningful_activities", "params": {}},
                {"action": "design_adaptive_strategies", "params": {}},
                {"action": "train_adl_skills", "params": {}},
                {"action": "provide_assistive_devices", "params": {}},
                {"action": "evaluate_home_environment", "params": {}},
                {"action": "document_adl_improvement", "params": {}}
            ],
            estimated_duration="35 分钟",
            required_skills=["作业疗法", "ADL 训练", "辅助器具适配"]
        )
    ]
}


# ========== 任务执行引擎 ==========

class TaskExecutor:
    """任务执行引擎 - OpenClaw 风格"""
    
    def __init__(self):
        self.skills = {}  # 注册的技能
        self.task_queue = []
        self.completed_tasks = []
        
    def register_skill(self, skill_name: str, skill_func):
        """注册技能"""
        self.skills[skill_name] = skill_func
        
    def create_task(self, template_id: str, params: Dict[str, Any]) -> Task:
        """根据模板创建任务"""
        template = self.find_template(template_id)
        if not template:
            raise ValueError(f"Template {template_id} not found")
        
        # 填充参数
        goal = template.goal_template
        steps = []
        for step in template.default_steps:
            new_params = {}
            for k, v in step["params"].items():
                if isinstance(v, str) and v.startswith("{") and v.endswith("}"):
                    param_name = v[1:-1]
                    new_params[k] = params.get(param_name, "")
                else:
                    new_params[k] = v
            steps.append({"action": step["action"], "params": new_params})
        
        # 填充目标
        for k, v in params.items():
            goal = goal.replace("{" + k + "}", str(v))
        
        task = Task(
            id=f"task_{datetime.now().strftime('%Y%m%d%H%M%S')}",
            name=template.name,
            description=template.description,
            profession=template.profession,
            goal=goal,
            steps=steps,
            status="pending"
        )
        
        return task
    
    def find_template(self, template_id: str) -> Optional[TaskTemplate]:
        """查找模板"""
        for profession, templates in PROFESSION_TASK_TEMPLATES.items():
            for template in templates:
                if template.id == template_id:
                    return template
        return None
    
    async def execute_task(self, task: Task):
        """执行任务"""
        task.status = "running"
        
        for i, step in enumerate(task.steps):
            action = step["action"]
            params = step["params"]
            
            # 执行动作
            if action in self.skills:
                result = await self.skills[action](**params)
                # 保存结果
            else:
                # 模拟执行
                result = {"status": "completed", "action": action}
        
        task.status = "completed"
        task.completed_at = datetime.now().isoformat()
        self.completed_tasks.append(task)
        
        return task


# ========== 示例技能注册 ==========

async def sample_skill(**params):
    """示例技能"""
    return {"status": "completed", "params": params}


# 创建执行器实例
executor = TaskExecutor()

# 注册所有技能
for template_list in PROFESSION_TASK_TEMPLATES.values():
    for template in template_list:
        for step in template.default_steps:
            executor.register_skill(step["action"], sample_skill)


if __name__ == "__main__":
    # 示例：创建并执行任务
    import asyncio
    
    # 创建门诊接诊任务
    task = executor.create_task("clinician_001", {
        "patient_name": "张三",
        "patient_id": "123456"
    })
    
    print(f"创建任务：{task.name}")
    print(f"目标：{task.goal}")
    print(f"步骤数：{len(task.steps)}")
    
    # 执行任务
    result = asyncio.run(executor.execute_task(task))
    print(f"任务状态：{result.status}")
