"""
临床医疗预测模块
基于患者特征预测疾病风险或治疗结局
代码行数：约 240 行
"""

import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from datetime import datetime
import logging

from ..core import ModuleBase, MCPClient

logger = logging.getLogger(__name__)


class ClinicalPredictionModule(ModuleBase):
    """临床预测模块"""
    
    def __init__(self, config: Optional[Dict[str, Any]] = None, mcp_client: Optional[MCPClient] = None):
        super().__init__("clinical_prediction", config, mcp_client)
        self.model_dir = Path(config.get("model_dir", "./models/clinical"))
        self.models = {}
        self._init_models()
    
    def _init_models(self):
        """初始化预测模型"""
        self.model_dir.mkdir(parents=True, exist_ok=True)
        
        self.models = {
            "sepsis": {
                "name": "败血症风险预测",
                "factors": ["age", "temperature", "heart_rate", "respiratory_rate", "wbc"],
                "weights": [0.1, 0.2, 0.2, 0.2, 0.3],
                "threshold": 0.5
            },
            "complication": {
                "name": "术后并发症预测",
                "factors": ["age", "bmi", "diabetes", "hypertension", "smoking"],
                "weights": [0.15, 0.15, 0.25, 0.2, 0.25],
                "threshold": 0.4
            },
            "readmission": {
                "name": "再入院风险预测",
                "factors": ["age", "chronic_diseases", "previous_admissions", "los"],
                "weights": [0.2, 0.3, 0.3, 0.2],
                "threshold": 0.45
            }
        }
        
        self._save_model_configs()
    
    def _save_model_configs(self):
        """保存模型配置"""
        config_file = self.model_dir / "model_configs.json"
        with open(config_file, 'w', encoding='utf-8') as f:
            json.dump(self.models, f, ensure_ascii=False, indent=2)
    
    def _normalize_feature(self, feature: str, value: Any) -> float:
        """
        特征归一化（0-1 范围）
        
        Args:
            feature: 特征名称
            value: 特征值
            
        Returns:
            归一化后的值
        """
        if feature == "age":
            return min(max(float(value) / 100, 0), 1)
        elif feature == "temperature":
            temp = float(value) if value else 37
            return min(max((temp - 35) / 8, 0), 1)
        elif feature == "heart_rate":
            hr = float(value) if value else 80
            return min(max((hr - 50) / 150, 0), 1)
        elif feature == "respiratory_rate":
            rr = float(value) if value else 16
            return min(max((rr - 10) / 40, 0), 1)
        elif feature == "wbc":
            wbc = float(value) if value else 7
            return min(max((wbc - 3) / 27, 0), 1)
        elif feature == "bmi":
            bmi = float(value) if value else 22
            return min(max((bmi - 15) / 25, 0), 1)
        elif feature in ["diabetes", "hypertension", "smoking"]:
            return 1.0 if value else 0.0
        elif feature == "chronic_diseases":
            return min(float(value) / 5, 1) if value else 0.0
        elif feature == "previous_admissions":
            return min(float(value) / 10, 1) if value else 0.0
        elif feature == "los":
            return min(float(value) / 30, 1) if value else 0.0
        else:
            return 0.5
    
    def predict(self, model_name: str, patient_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        执行预测
        
        Args:
            model_name: 模型名称
            patient_data: 患者数据
            
        Returns:
            预测结果
        """
        if model_name not in self.models:
            raise ValueError(f"模型 {model_name} 不存在")
        
        model = self.models[model_name]
        factors = model["factors"]
        weights = model["weights"]
        
        risk_score = 0.0
        feature_contributions = []
        
        for factor, weight in zip(factors, weights):
            normalized_value = self._normalize_feature(factor, patient_data.get(factor))
            contribution = normalized_value * weight
            risk_score += contribution
            feature_contributions.append({
                "factor": factor,
                "value": patient_data.get(factor),
                "normalized": normalized_value,
                "contribution": contribution
            })
        
        risk_level = self._classify_risk(risk_score, model["threshold"])
        
        result = {
            "model": model_name,
            "model_name": model["name"],
            "risk_score": round(risk_score, 4),
            "risk_level": risk_level,
            "threshold": model["threshold"],
            "feature_contributions": feature_contributions,
            "timestamp": datetime.now().isoformat()
        }
        
        return result
    
    def _classify_risk(self, score: float, threshold: float) -> str:
        """
        风险分级
        
        Args:
            score: 风险评分
            threshold: 阈值
            
        Returns:
            风险等级
        """
        if score >= threshold * 1.5:
            return "high"
        elif score >= threshold:
            return "medium"
        else:
            return "low"
    
    def get_recommendation(self, model_name: str, risk_level: str, risk_score: float) -> str:
        """
        获取建议
        
        Args:
            model_name: 模型名称
            risk_level: 风险等级
            risk_score: 风险评分
            
        Returns:
            建议文本
        """
        recommendations = {
            "sepsis": {
                "high": "高风险：建议立即进行血培养，考虑经验性抗生素治疗，密切监测生命体征。",
                "medium": "中风险：建议完善相关检查，密切观察病情变化，必要时进行干预。",
                "low": "低风险：常规监测，继续当前治疗方案。"
            },
            "complication": {
                "high": "高风险：建议加强围手术期管理，预防性使用抗生素，密切监测并发症征象。",
                "medium": "中风险：注意术后护理，定期复查，早期发现并处理并发症。",
                "low": "低风险：按常规术后管理，注意观察。"
            },
            "readmission": {
                "high": "高风险：建议加强出院指导，安排早期随访，优化治疗方案。",
                "medium": "中风险：建议定期随访，加强患者教育，注意病情监测。",
                "low": "低风险：常规随访，按医嘱治疗。"
            }
        }
        
        model_recs = recommendations.get(model_name, {})
        return model_recs.get(risk_level, "建议结合临床实际情况综合判断。")
    
    async def execute(self, **kwargs) -> Any:
        """执行模块功能"""
        model_name = kwargs.get("model_name", "sepsis")
        patient_data = kwargs.get("patient_data", {})
        
        result = self.predict(model_name, patient_data)
        
        recommendation = self.get_recommendation(
            model_name,
            result["risk_level"],
            result["risk_score"]
        )
        result["recommendation"] = recommendation
        
        if self.mcp_client:
            mcp_interpretation = await self._mcp_interpret(result)
            if mcp_interpretation:
                result["mcp_interpretation"] = mcp_interpretation
        
        return result
    
    async def _mcp_interpret(self, result: Dict[str, Any]) -> str:
        """MCP 解读"""
        if not self.mcp_client:
            return ""
        
        prompt = f"""请解读以下临床预测结果：

预测模型：{result.get('model_name', '')}
风险评分：{result.get('risk_score', 0):.2%}
风险等级：{result.get('risk_level', '').upper()}

主要影响因素：
{json.dumps(result.get('feature_contributions', []), ensure_ascii=False, indent=2)}

请提供专业医学解读和临床建议。"""
        
        return await self.mcp_client.query(prompt)
    
    def format_output(self, result: Dict[str, Any]) -> str:
        """格式化输出"""
        output = f"""临床预测结果：
================

预测模型：{result.get('model_name', '')}
检查时间：{result.get('timestamp', '')}

风险评分：{result.get('risk_score', 0):.2%}
风险等级：{result.get('risk_level', '').upper()}

主要影响因素:
"""
        for fc in result.get("feature_contributions", []):
            output += f"  - {fc['factor']}: {fc['value']} (贡献度：{fc['contribution']:.3f})\n"
        
        output += f"\n临床建议:\n{result.get('recommendation', '')}\n"
        
        if result.get("mcp_interpretation"):
            output += f"\nAI 解读:\n{result.get('mcp_interpretation')}\n"
        
        return output
