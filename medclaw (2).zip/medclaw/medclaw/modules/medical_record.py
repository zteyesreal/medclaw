"""
病历书写模块
根据患者主诉、现病史等自动生成结构化病历，支持模板填充和智能补全
代码行数：约 180 行
"""

import json
from pathlib import Path
from typing import Any, Dict, List, Optional
from datetime import datetime

from ..core import ModuleBase, MCPClient


class MedicalRecordModule(ModuleBase):
    """病历书写模块"""
    
    def __init__(self, config: Optional[Dict[str, Any]] = None, mcp_client: Optional[MCPClient] = None):
        super().__init__("medical_record", config, mcp_client)
        self.template_dir = Path(config.get("template_dir", "./templates/medical_record"))
        self.templates = self._load_templates()
    
    def _load_templates(self) -> Dict[str, str]:
        """加载病历模板"""
        templates = {}
        if self.template_dir.exists():
            for template_file in self.template_dir.glob("*.txt"):
                with open(template_file, 'r', encoding='utf-8') as f:
                    templates[template_file.stem] = f.read()
        return templates
    
    def build_prompt(self, input_data: Dict[str, Any]) -> str:
        """
        构建 MCP 查询提示词
        
        Args:
            input_data: 输入数据（主诉、现病史等）
            
        Returns:
            提示词字符串
        """
        chief_complaint = input_data.get("chief_complaint", "")
        present_illness = input_data.get("present_illness", "")
        patient_info = input_data.get("patient_info", {})
        
        prompt = f"""请根据以下患者信息生成一份完整的结构化病历：

患者基本信息：
- 姓名：{patient_info.get('name', '未知')}
- 性别：{patient_info.get('gender', '未知')}
- 年龄：{patient_info.get('age', '未知')}

主诉：{chief_complaint}

现病史：{present_illness}

请生成包含以下部分的完整病历：
1. 主诉
2. 现病史
3. 既往史
4. 体格检查
5. 辅助检查
6. 初步诊断
7. 治疗建议

请使用专业医学术语，确保内容完整、准确。"""
        
        return prompt
    
    async def generate(self, input_data: Dict[str, Any]) -> str:
        """
        生成病历
        
        Args:
            input_data: 输入数据
            
        Returns:
            生成的病历文本
        """
        if not self.validate_input(input_data):
            raise ValueError("输入数据验证失败")
        
        template_name = input_data.get("template", "default")
        
        if template_name in self.templates:
            template = self.templates[template_name]
            filled_template = self._fill_template(template, input_data)
            
            if self.mcp_client:
                prompt = self.build_prompt(input_data)
                enhanced = await self.mcp_client.query(prompt)
                if enhanced:
                    return enhanced
            
            return filled_template
        else:
            if self.mcp_client:
                prompt = self.build_prompt(input_data)
                result = await self.mcp_client.query(prompt)
                return result if result else self._generate_basic(input_data)
            else:
                return self._generate_basic(input_data)
    
    def _fill_template(self, template: str, data: Dict[str, Any]) -> str:
        """填充模板"""
        patient_info = data.get("patient_info", {})
        
        replacements = {
            "{name}": patient_info.get("name", ""),
            "{gender}": patient_info.get("gender", ""),
            "{age}": str(patient_info.get("age", "")),
            "{chief_complaint}": data.get("chief_complaint", ""),
            "{present_illness}": data.get("present_illness", ""),
            "{date}": datetime.now().strftime("%Y-%m-%d"),
        }
        
        result = template
        for key, value in replacements.items():
            result = result.replace(key, value)
        
        return result
    
    def _generate_basic(self, input_data: Dict[str, Any]) -> str:
        """生成基础病历（无 MCP 时）"""
        patient_info = input_data.get("patient_info", {})
        
        record = f"""
病历记录
========

患者信息：
- 姓名：{patient_info.get('name', '未知')}
- 性别：{patient_info.get('gender', '未知')}
- 年龄：{patient_info.get('age', '未知')}
- 日期：{datetime.now().strftime('%Y-%m-%d')}

主诉：
{input_data.get('chief_complaint', '')}

现病史：
{input_data.get('present_illness', '')}

既往史：
待补充

体格检查：
待补充

辅助检查：
待补充

初步诊断：
待补充

治疗建议：
待补充
"""
        return record
    
    def validate_input(self, data: Dict[str, Any]) -> bool:
        """验证输入数据"""
        if not data.get("chief_complaint"):
            return False
        return True
    
    async def execute(self, **kwargs) -> Any:
        """执行模块功能"""
        action = kwargs.get("action", "generate")
        
        if action == "generate":
            input_data = kwargs.get("input_data", {})
            return await self.generate(input_data)
        elif action == "complete":
            text = kwargs.get("text", "")
            return await self.semantic_complete(text)
        else:
            raise ValueError(f"未知的操作：{action}")
    
    async def semantic_complete(self, text: str) -> str:
        """
        语义补全
        
        Args:
            text: 已输入的文本
            
        Returns:
            补全后的文本
        """
        if not self.mcp_client:
            return text
        
        prompt = f"""请补全以下病历内容，保持医学专业性：

{text}

请继续完成剩余部分。"""
        
        completion = await self.mcp_client.query(prompt)
        return text + "\n\n" + completion if completion else text
