"""MedClaw 功能模块"""

from .medical_record import MedicalRecordModule
from .medical_quality import MedicalQualityModule
from .insurance_analysis import InsuranceAnalysisModule
from .clinical_prediction import ClinicalPredictionModule
from .ai_reading import AIReadingModule
from .research_analysis import ResearchAnalysisModule
from .paper_analysis import PaperAnalysisModule

__all__ = [
    "MedicalRecordModule",
    "MedicalQualityModule",
    "InsuranceAnalysisModule",
    "ClinicalPredictionModule",
    "AIReadingModule",
    "ResearchAnalysisModule",
    "PaperAnalysisModule",
]
