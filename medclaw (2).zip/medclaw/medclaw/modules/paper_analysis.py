"""
论文分析模块
上传或输入论文 PDF/文本，提取摘要、方法、结论等关键信息
代码行数：约 230 行
"""

import json
from pathlib import Path
from typing import Any, Dict, List, Optional
from datetime import datetime
import logging

from ..core import ModuleBase, MCPClient

logger = logging.getLogger(__name__)


class PaperAnalysisModule(ModuleBase):
    """论文分析模块"""
    
    def __init__(self, config: Optional[Dict[str, Any]] = None, mcp_client: Optional[MCPClient] = None):
        super().__init__("paper_analysis", config, mcp_client)
        self.cache_dir = Path(config.get("cache_dir", "./cache/papers"))
        self.cache_dir.mkdir(parents=True, exist_ok=True)
    
    async def analyze_paper(self, paper_input: str, input_type: str = "text") -> Dict[str, Any]:
        """
        分析论文
        
        Args:
            paper_input: 论文内容或文件路径
            input_type: 输入类型（text, file, url）
            
        Returns:
            分析结果
        """
        result = {
            "input_type": input_type,
            "metadata": {},
            "abstract": "",
            "key_points": [],
            "methodology": "",
            "conclusions": [],
            "limitations": [],
            "timestamp": datetime.now().isoformat()
        }
        
        if input_type == "file":
            content = self._extract_text_from_file(paper_input)
        elif input_type == "url":
            content = await self._fetch_paper_from_url(paper_input)
        else:
            content = paper_input
        
        if not content:
            result["error"] = "无法获取论文内容"
            return result
        
        result["metadata"] = self._extract_metadata(content)
        
        if self.mcp_client:
            mcp_analysis = await self._mcp_analyze(content)
            if mcp_analysis:
                result.update(mcp_analysis)
        else:
            result = self._basic_analysis(result, content)
        
        return result
    
    def _extract_text_from_file(self, file_path: str) -> str:
        """从文件提取文本"""
        try:
            path = Path(file_path)
            
            if path.suffix.lower() == '.pdf':
                return self._extract_pdf_text(file_path)
            elif path.suffix.lower() in ['.txt', '.md']:
                with open(path, 'r', encoding='utf-8') as f:
                    return f.read()
            else:
                logger.warning(f"不支持的文件格式：{path.suffix}")
                return ""
        except Exception as e:
            logger.error(f"提取文件文本失败：{e}")
            return ""
    
    def _extract_pdf_text(self, pdf_path: str) -> str:
        """提取 PDF 文本"""
        try:
            import pdfplumber
            
            text = []
            with pdfplumber.open(pdf_path) as pdf:
                for page in pdf.pages[:10]:
                    page_text = page.extract_text()
                    if page_text:
                        text.append(page_text)
            
            return "\n".join(text)
        except ImportError:
            logger.warning("pdfplumber 未安装，无法解析 PDF")
            return ""
        except Exception as e:
            logger.error(f"解析 PDF 失败：{e}")
            return ""
    
    async def _fetch_paper_from_url(self, url: str) -> str:
        try:
            import httpx
            async with httpx.AsyncClient() as client:
                response = await client.get(url, timeout=30)
                response.raise_for_status()
                return response.text
        except Exception as e:
            logger.error(f"获取 URL 失败：{e}")
            return ""
    
    def _extract_metadata(self, content: str) -> Dict[str, Any]:
        metadata = {
            "title": "", "authors": [], "abstract": "",
            "keywords": [], "word_count": len(content.split())
        }
        lines = content.split('\n')
        for i, line in enumerate(lines[:20]):
            line = line.strip()
            if len(line) > 10 and len(line) < 200 and not metadata["title"]:
                if any(word in line.lower() for word in ["study", "research", "analysis", "effect", "治疗", "研究", "分析"]):
                    metadata["title"] = line
                elif i < 3:
                    metadata["title"] = line
            if "abstract" in line.lower() or "摘要" in line:
                if i + 1 < len(lines):
                    metadata["abstract"] = lines[i + 1].strip()
        return metadata
    
    def _basic_analysis(self, result: Dict[str, Any], content: str) -> Dict[str, Any]:
        """基础分析（无 MCP 时）"""
        sections = self._split_sections(content)
        
        result["abstract"] = result["metadata"].get("abstract", "")
        
        if "methods" in sections:
            result["methodology"] = sections["methods"][:500]
        
        if "conclusion" in sections or "discussion" in sections:
            conclusion_text = sections.get("conclusion", sections.get("discussion", ""))
            result["conclusions"] = self._extract_key_sentences(conclusion_text, 3)
        
        result["key_points"] = self._extract_key_sentences(content, 5)
        
        result["limitations"] = ["需要 AI 进一步分析"]
        
        return result
    
    def _split_sections(self, content: str) -> Dict[str, str]:
        sections = {}
        current_section = "introduction"
        current_content = []
        section_markers = [
            ("introduction", ["introduction", "背景", "引言"]),
            ("methods", ["methods", "方法", "材料与方法"]),
            ("results", ["results", "结果"]),
            ("discussion", ["discussion", "讨论"]),
            ("conclusion", ["conclusion", "结论"]),
        ]
        for line in content.split('\n'):
            line_lower = line.lower().strip()
            section_found = False
            for section_name, markers in section_markers:
                if any(marker in line_lower for marker in markers):
                    if current_content:
                        sections[current_section] = "\n".join(current_content)
                    current_section = section_name
                    current_content = []
                    section_found = True
                    break
            if not section_found:
                current_content.append(line)
        if current_content:
            sections[current_section] = "\n".join(current_content)
        return sections
    
    def _extract_key_sentences(self, text: str, max_sentences: int = 5) -> List[str]:
        sentences = text.replace('\n', ' ').split('.')
        key_sentences = []
        for sentence in sentences[:20]:
            sentence = sentence.strip()
            if len(sentence) > 30 and len(sentence) < 300:
                if any(word in sentence.lower() for word in ["significant", "important", "demonstrate", "suggest", "发现", "表明", "显著"]):
                    key_sentences.append(sentence + ".")
        return key_sentences[:max_sentences]
    
    async def _mcp_analyze(self, content: str) -> Optional[Dict[str, Any]]:
        """MCP 分析"""
        if not self.mcp_client:
            return None
        
        prompt = f"""请分析以下学术论文，提取关键信息：

论文内容（节选）:
{content[:5000]}

请提取以下信息:
1. 研究目的
2. 研究方法
3. 主要发现（3-5 点）
4. 结论
5. 研究局限性
6. 临床或科研意义

请以 JSON 格式返回结果。"""
        
        response = await self.mcp_client.query(prompt)
        
        if response:
            try:
                import re
                json_match = re.search(r'\{.*\}', response, re.DOTALL)
                if json_match:
                    analysis = json.loads(json_match.group())
                    return {
                        "abstract": analysis.get("研究目的", ""),
                        "key_points": analysis.get("主要发现", []),
                        "methodology": analysis.get("研究方法", ""),
                        "conclusions": analysis.get("结论", []),
                        "limitations": analysis.get("研究局限性", []),
                    }
            except Exception as e:
                logger.error(f"解析 MCP 响应失败：{e}")
        
        return None
    
    async def summarize(self, papers: List[str]) -> str:
        if self.mcp_client:
            prompt = f"""请对以下 {len(papers)} 篇论文进行综述分析：

{chr(10).join(papers[:3000])}

请总结:
1. 研究主题的共同点
2. 主要研究方法的异同
3. 关键发现的综合
4. 研究趋势和未来方向"""
            return await self.mcp_client.query(prompt)
        else:
            return f"共分析 {len(papers)} 篇论文，需要 MCP 支持生成综述。"
    
    async def execute(self, **kwargs) -> Any:
        """执行模块功能"""
        paper_input = kwargs.get("paper_input", "")
        input_type = kwargs.get("input_type", "text")
        
        return await self.analyze_paper(paper_input, input_type)
    
    def format_output(self, result: Dict[str, Any]) -> str:
        """格式化输出"""
        if "error" in result:
            return f"错误：{result['error']}"
        
        output = f"""论文分析结果
==============

分析时间：{result.get('timestamp', '')}

标题：{result.get('metadata', {}).get('title', 'N/A')}
字数：{result.get('metadata', {}).get('word_count', 0)}

摘要:
{result.get('abstract', 'N/A')}

关键要点:
"""
        for i, point in enumerate(result.get("key_points", []), 1):
            output += f"{i}. {point}\n"
        
        output += f"\n研究方法:\n{result.get('methodology', 'N/A')}\n"
        
        output += "\n主要结论:\n"
        for i, conc in enumerate(result.get("conclusions", []), 1):
            output += f"{i}. {conc}\n"
        
        if result.get("limitations"):
            output += "\n局限性:\n"
            for i, lim in enumerate(result.get("limitations", []), 1):
                output += f"{i}. {lim}\n"
        
        return output
