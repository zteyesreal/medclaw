"""
医保分析模块
分析病历费用结构、DRG/DIP 分组合理性、医保违规风险
代码行数：约 250 行
"""

import json
from pathlib import Path
from typing import Any, Dict, List, Optional
from datetime import datetime

from ..core import ModuleBase, MCPClient


class InsuranceAnalysisModule(ModuleBase):
    """医保分析模块"""
    
    def __init__(self, config: Optional[Dict[str, Any]] = None, mcp_client: Optional[MCPClient] = None):
        super().__init__("insurance_analysis", config, mcp_client)
        self.drg_dict_path = Path(config.get("drg_dict_path", "./data/drg_dict.json"))
        self.rule_dir = Path(config.get("rule_dir", "./rules/insurance"))
        self.drg_dict = self._load_drg_dict()
        self.insurance_rules = self._load_insurance_rules()
    
    def _load_drg_dict(self) -> Dict[str, Any]:
        """加载 DRG 分组字典"""
        if self.drg_dict_path.exists():
            with open(self.drg_dict_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        return self._create_default_drg_dict()
    
    def _create_default_drg_dict(self) -> Dict[str, Any]:
        """创建默认 DRG 字典"""
        default_drg = {
            "G10": {"name": "阑尾切除术，伴合并症", "weight": 1.2, "base_cost": 15000},
            "G11": {"name": "阑尾切除术，不伴合并症", "weight": 0.9, "base_cost": 10000},
            "I10": {"name": "肺炎，伴严重并发症", "weight": 2.5, "base_cost": 30000},
            "I11": {"name": "肺炎，伴一般并发症", "weight": 1.8, "base_cost": 20000},
            "I12": {"name": "肺炎，不伴并发症", "weight": 1.0, "base_cost": 12000},
        }
        
        self.drg_dict_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.drg_dict_path, 'w', encoding='utf-8') as f:
            json.dump(default_drg, f, ensure_ascii=False, indent=2)
        
        return default_drg
    
    def _load_insurance_rules(self) -> List[Dict[str, Any]]:
        """加载医保规则"""
        rules = [
            {
                "name": "过度诊疗检查",
                "type": "over_treatment",
                "description": "检查项目数量超过同类疾病平均水平",
                "threshold": 1.5
            },
            {
                "name": "分解住院检查",
                "type": "split_hospitalization",
                "description": "15 天内因同一疾病再次住院",
                "days": 15
            },
            {
                "name": "高值耗材使用",
                "type": "high_value_consumables",
                "description": "高值耗材费用占比过高",
                "threshold": 0.3
            },
            {
                "name": "药品比例检查",
                "type": "drug_ratio",
                "description": "药品费用占总费用比例",
                "threshold": 0.4
            }
        ]
        return rules
    
    async def analyze(self, medical_record: Dict[str, Any]) -> Dict[str, Any]:
        """
        执行医保分析
        
        Args:
            medical_record: 病历数据（包含费用明细）
            
        Returns:
            分析结果
        """
        result = {
            "drg_grouping": None,
            "estimated_cost": 0,
            "violations": [],
            "risk_level": "low",
            "timestamp": datetime.now().isoformat()
        }
        
        drg_code = self._group_drg(medical_record)
        if drg_code and drg_code in self.drg_dict:
            drg_info = self.drg_dict[drg_code]
            result["drg_grouping"] = {
                "code": drg_code,
                "name": drg_info["name"],
                "weight": drg_info["weight"]
            }
            result["estimated_cost"] = drg_info["base_cost"]
        
        violations = self._check_violations(medical_record)
        result["violations"] = violations
        
        if len(violations) > 0:
            result["risk_level"] = "high" if len(violations) > 2 else "medium"
        
        if self.mcp_client:
            mcp_analysis = await self._mcp_analysis(medical_record, result)
            if mcp_analysis:
                result["mcp_interpretation"] = mcp_analysis
        
        return result
    
    def _group_drg(self, medical_record: Dict[str, Any]) -> Optional[str]:
        """
        DRG 分组
        
        Args:
            medical_record: 病历数据
            
        Returns:
            DRG 分组代码
        """
        diagnosis = medical_record.get("diagnosis", "").lower()
        procedures = medical_record.get("procedures", [])
        complications = medical_record.get("complications", [])
        
        if "阑尾炎" in diagnosis or "阑尾" in diagnosis:
            if complications:
                return "G10"
            else:
                return "G11"
        elif "肺炎" in diagnosis:
            if len(complications) >= 2:
                return "I10"
            elif complications:
                return "I11"
            else:
                return "I12"
        
        return None
    
    def _check_violations(self, medical_record: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        检查违规行为
        
        Args:
            medical_record: 病历数据
            
        Returns:
            违规列表
        """
        violations = []
        cost_details = medical_record.get("cost_details", {})
        
        total_cost = cost_details.get("total", 0)
        drug_cost = cost_details.get("drugs", 0)
        consumables_cost = cost_details.get("consumables", 0)
        examination_cost = cost_details.get("examinations", 0)
        
        for rule in self.insurance_rules:
            violation = None
            
            if rule["type"] == "drug_ratio" and total_cost > 0:
                ratio = drug_cost / total_cost
                if ratio > rule["threshold"]:
                    violation = {
                        "rule": rule["name"],
                        "type": rule["type"],
                        "severity": "warning",
                        "description": f"药品比例 {ratio:.1%} 超过阈值 {rule['threshold']:.0%}",
                        "suggestion": "建议优化用药结构，减少辅助用药"
                    }
            
            elif rule["type"] == "high_value_consumables" and total_cost > 0:
                ratio = consumables_cost / total_cost
                if ratio > rule["threshold"]:
                    violation = {
                        "rule": rule["name"],
                        "type": rule["type"],
                        "severity": "warning",
                        "description": f"高值耗材占比 {ratio:.1%} 超过阈值 {rule['threshold']:.0%}",
                        "suggestion": "请确认高值耗材使用的必要性"
                    }
            
            elif rule["type"] == "over_treatment":
                exam_count = len(cost_details.get("examination_items", []))
                if exam_count > 10:
                    violation = {
                        "rule": rule["name"],
                        "type": rule["type"],
                        "severity": "warning",
                        "description": f"检查项目数量 ({exam_count}项) 过多",
                        "suggestion": "请确认所有检查项目的必要性"
                    }
            
            if violation:
                violations.append(violation)
        
        return violations
    
    async def _mcp_analysis(self, medical_record: Dict[str, Any], analysis_result: Dict[str, Any]) -> str:
        """MCP 智能分析"""
        if not self.mcp_client:
            return ""
        
        prompt = f"""请分析以下医保费用数据，评估合理性和风险：

DRG 分组：{analysis_result.get('drg_grouping', {})}
预估费用：¥{analysis_result.get('estimated_cost', 0):,.2f}
违规风险：{len(analysis_result.get('violations', []))} 项

请提供专业解读和建议。"""
        
        return await self.mcp_client.query(prompt)
    
    async def execute(self, **kwargs) -> Any:
        """执行模块功能"""
        medical_record = kwargs.get("medical_record", {})
        return await self.analyze(medical_record)
    
    def format_output(self, result: Dict[str, Any]) -> str:
        """格式化输出"""
        output = f"""医保分析结果：
================

分析时间：{result.get('timestamp', '')}

DRG 分组:
"""
        drg = result.get("drg_grouping")
        if drg:
            output += f"  编码：{drg.get('code', '')}\n"
            output += f"  名称：{drg.get('name', '')}\n"
            output += f"  权重：{drg.get('weight', 0)}\n"
        
        output += f"\n预计费用：¥{result.get('estimated_cost', 0):,.2f}\n"
        output += f"风险等级：{result.get('risk_level', 'unknown').upper()}\n"
        
        violations = result.get("violations", [])
        if violations:
            output += f"\n违规风险（{len(violations)}项）:\n"
            for v in violations:
                output += f"  ⚠️ {v.get('rule', '')}: {v.get('description', '')}\n"
                output += f"     建议：{v.get('suggestion', '')}\n"
        else:
            output += "\n✅ 未发现明显违规风险\n"
        
        if result.get("mcp_interpretation"):
            output += f"\nAI 解读:\n{result.get('mcp_interpretation')}\n"
        
        return output
