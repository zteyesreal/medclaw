"""
病历质控模块
对已生成的病历进行质量检查，包括完整性、合理性、编码一致性等
代码行数：约 220 行
"""

import yaml
from pathlib import Path
from typing import Any, Dict, List, Optional
from datetime import datetime

from ..core import ModuleBase, MCPClient


class QualityRule:
    """质控规则类"""
    
    def __init__(self, name: str, field: str, condition: str, severity: str):
        self.name = name
        self.field = field
        self.condition = condition
        self.severity = severity
    
    def check(self, data: Dict[str, Any]) -> Optional[str]:
        """
        执行规则检查
        
        Args:
            data: 病历数据
            
        Returns:
            如果违反规则，返回问题描述；否则返回 None
        """
        value = self._get_field_value(data, self.field)
        
        if self.condition == "exists":
            if value is None or value == "":
                return f"{self.name}：{self.field} 未填写"
        elif self.condition.startswith("0 <="):
            try:
                age = float(value) if value else 0
                if not (0 <= age <= 150):
                    return f"{self.name}：年龄（{age}岁）超出合理范围"
            except (ValueError, TypeError):
                pass
        
        return None
    
    def _get_field_value(self, data: Dict[str, Any], field: str) -> Any:
        """获取字段值"""
        return data.get(field)


class MedicalQualityModule(ModuleBase):
    """病历质控模块"""
    
    def __init__(self, config: Optional[Dict[str, Any]] = None, mcp_client: Optional[MCPClient] = None):
        super().__init__("medical_quality", config, mcp_client)
        self.rule_dir = Path(config.get("rule_dir", "./rules/medical_quality"))
        self.rules: List[QualityRule] = []
        self._load_rules()
    
    def _load_rules(self):
        """加载质控规则"""
        if not self.rule_dir.exists():
            self.rule_dir.mkdir(parents=True, exist_ok=True)
            self._create_default_rules()
        
        for rule_file in self.rule_dir.glob("*.yaml"):
            with open(rule_file, 'r', encoding='utf-8') as f:
                rule_data = yaml.safe_load(f)
                if rule_data and "rules" in rule_data:
                    for rule in rule_data["rules"]:
                        self.rules.append(QualityRule(
                            name=rule.get("name", "未知规则"),
                            field=rule.get("field", ""),
                            condition=rule.get("condition", "exists"),
                            severity=rule.get("severity", "warning")
                        ))
    
    def _create_default_rules(self):
        """创建默认规则"""
        default_rules = {
            "required_fields.yaml": {
                "rules": [
                    {"name": "主诉必填", "field": "chief_complaint", "condition": "exists", "severity": "error"},
                    {"name": "现病史必填", "field": "present_illness", "condition": "exists", "severity": "error"},
                    {"name": "初步诊断必填", "field": "diagnosis", "condition": "exists", "severity": "error"},
                ]
            },
            "reasonableness.yaml": {
                "rules": [
                    {"name": "年龄合理性", "field": "patient_age", "condition": "0 <= value <= 150", "severity": "warning"},
                ]
            }
        }
        
        for filename, content in default_rules.items():
            filepath = self.rule_dir / filename
            with open(filepath, 'w', encoding='utf-8') as f:
                yaml.dump(content, f, allow_unicode=True, default_flow_style=False)
    
    async def check(self, medical_record: Dict[str, Any]) -> Dict[str, Any]:
        """
        执行质控检查
        
        Args:
            medical_record: 病历数据
            
        Returns:
            质控结果
        """
        results = {
            "errors": [],
            "warnings": [],
            "info": [],
            "timestamp": datetime.now().isoformat()
        }
        
        for rule in self.rules:
            issue = rule.check(medical_record)
            if issue:
                if rule.severity == "error":
                    results["errors"].append(issue)
                elif rule.severity == "warning":
                    results["warnings"].append(issue)
                else:
                    results["info"].append(issue)
        
        if self.mcp_client:
            mcp_result = await self._mcp_semantic_check(medical_record)
            if mcp_result:
                results["mcp_suggestions"] = mcp_result
        
        results["total_issues"] = len(results["errors"]) + len(results["warnings"])
        results["passed"] = len(results["errors"]) == 0
        
        return results
    
    async def _mcp_semantic_check(self, medical_record: Dict[str, Any]) -> Optional[str]:
        """MCP 语义检查"""
        if not self.mcp_client:
            return None
        
        prompt = f"""请对以下病历进行质量检查，重点关注：
1. 诊断与症状的一致性
2. 检查结果的合理性
3. 治疗建议的适当性

病历内容：
{medical_record}

请指出存在的问题和改进建议。"""
        
        return await self.mcp_client.query(prompt)
    
    def check_icd10(self, diagnosis: str, icd10_code: str) -> bool:
        """
        检查 ICD-10 编码与诊断描述是否匹配
        
        Args:
            diagnosis: 诊断描述
            icd10_code: ICD-10 编码
            
        Returns:
            是否匹配
        """
        icd10_mapping = {
            "急性阑尾炎": ["K35", "K36", "K37"],
            "肺炎": ["J12", "J13", "J14", "J15", "J16", "J17", "J18"],
            "高血压": ["I10", "I11", "I12", "I13", "I15"],
            "糖尿病": ["E10", "E11", "E12", "E13", "E14"],
        }
        
        for diag_name, codes in icd10_mapping.items():
            if diag_name in diagnosis:
                for code in codes:
                    if icd10_code.upper().startswith(code):
                        return True
                return False
        
        return True
    
    async def execute(self, **kwargs) -> Any:
        """执行模块功能"""
        medical_record = kwargs.get("medical_record", {})
        return await self.check(medical_record)
    
    def format_output(self, result: Dict[str, Any]) -> str:
        """格式化输出"""
        output = f"""病历质控结果：
================

检查时间：{result.get('timestamp', '')}
总体通过：{'是' if result.get('passed', False) else '否'}
问题总数：{result.get('total_issues', 0)}

错误（{len(result.get('errors', []))}）:
"""
        for error in result.get("errors", []):
            output += f"  ❌ {error}\n"
        
        output += f"\n警告（{len(result.get('warnings', []))}）:\n"
        for warning in result.get("warnings", []):
            output += f"  ⚠️ {warning}\n"
        
        if result.get("info"):
            output += f"\n提示（{len(result.get('info', []))}）:\n"
            for info in result.get("info", []):
                output += f"  ℹ️ {info}\n"
        
        if result.get("mcp_suggestions"):
            output += f"\nAI 建议:\n{result.get('mcp_suggestions')}\n"
        
        return output
