"""
AI 阅片模块
医学影像分析、病灶检测、报告生成
代码行数：约 280 行
"""

import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from datetime import datetime
import logging

from ..core import ModuleBase, MCPClient

logger = logging.getLogger(__name__)


class AIReadingModule(ModuleBase):
    """AI 阅片模块"""
    
    def __init__(self, config: Optional[Dict[str, Any]] = None, mcp_client: Optional[MCPClient] = None):
        super().__init__("ai_reading", config, mcp_client)
        self.model_name = config.get("model_name", "resnet50")
        self.weights_path = Path(config.get("weights_path", "./models/ai_reading/model.pth"))
        self.device = config.get("device", "cuda")
        self.dicom_cache = Path(config.get("dicom_cache", "./cache/dicom"))
        
        self.dicom_cache.mkdir(parents=True, exist_ok=True)
        self.weights_path.parent.mkdir(parents=True, exist_ok=True)
        
        self._init_model()
    
    def _init_model(self):
        """初始化模型配置"""
        model_config = {
            "model_name": self.model_name,
            "device": self.device if self._check_cuda() else "cpu",
            "classes": [
                "normal",
                "nodule",
                "pneumonia",
                "fracture",
                "effusion",
                "mass"
            ],
            "input_size": 512,
            "confidence_threshold": 0.7
        }
        
        config_file = self.weights_path.parent / "model_config.json"
        with open(config_file, 'w', encoding='utf-8') as f:
            json.dump(model_config, f, ensure_ascii=False, indent=2)
    
    def _check_cuda(self) -> bool:
        """检查 CUDA 是否可用"""
        try:
            import torch
            return torch.cuda.is_available()
        except ImportError:
            return False
    
    async def analyze_image(self, image_path: str, image_type: str = "ct") -> Dict[str, Any]:
        """
        分析医学影像
        
        Args:
            image_path: 影像文件路径
            image_type: 影像类型（ct, xray, mri 等）
            
        Returns:
            分析结果
        """
        result = {
            "image_path": image_path,
            "image_type": image_type,
            "findings": [],
            "report": "",
            "confidence": 0.0,
            "timestamp": datetime.now().isoformat()
        }
        
        if self._is_dicom(image_path):
            image_data = self._load_dicom(image_path)
        else:
            image_data = self._load_image(image_path)
        
        if not image_data:
            result["error"] = "无法加载影像文件"
            return result
        
        detections = self._run_inference(image_data, image_type)
        result["findings"] = detections
        
        if detections:
            max_confidence = max([d.get("confidence", 0) for d in detections])
            result["confidence"] = max_confidence
            result["report"] = self._generate_report(detections, image_type)
        else:
            result["report"] = f"未明显异常发现。"
        
        if self.mcp_client:
            mcp_report = await self._mcp_enhance_report(result)
            if mcp_report:
                result["mcp_enhanced_report"] = mcp_report
        
        return result
    
    def _is_dicom(self, path: str) -> bool:
        """判断是否为 DICOM 文件"""
        return path.lower().endswith(('.dcm', '.dicom'))
    
    def _load_dicom(self, path: str) -> Optional[Any]:
        """加载 DICOM 文件"""
        try:
            import pydicom
            ds = pydicom.dcmread(path)
            return ds.pixel_array if hasattr(ds, 'pixel_array') else None
        except Exception as e:
            logger.error(f"加载 DICOM 文件失败：{e}")
            return None
    
    def _load_image(self, path: str) -> Optional[Any]:
        """加载普通图像"""
        try:
            from PIL import Image
            import numpy as np
            img = Image.open(path)
            return np.array(img)
        except Exception as e:
            logger.error(f"加载图像文件失败：{e}")
            return None
    
    def _run_inference(self, image_data: Any, image_type: str) -> List[Dict[str, Any]]:
        """
        运行推理（模拟）
        
        Args:
            image_data: 图像数据
            image_type: 影像类型
            
        Returns:
            检测结果列表
        """
        detections = []
        
        if image_type.lower() in ["ct", "xray"]:
            if image_type.lower() == "ct":
                detections = self._simulate_ct_detection()
            else:
                detections = self._simulate_xray_detection()
        
        return detections
    
    def _simulate_ct_detection(self) -> List[Dict[str, Any]]:
        """模拟 CT 检测（示例）"""
        import random
        random.seed()
        
        findings = []
        
        if random.random() > 0.5:
            findings.append({
                "type": "nodule",
                "location": "右肺上叶",
                "size_mm": round(random.uniform(5, 15), 1),
                "confidence": round(random.uniform(0.7, 0.95), 2),
                "description": "结节，形态不规则，建议进一步检查"
            })
        
        if random.random() > 0.7:
            findings.append({
                "type": "effusion",
                "location": "左侧胸腔",
                "size_mm": round(random.uniform(10, 30), 1),
                "confidence": round(random.uniform(0.65, 0.85), 2),
                "description": "少量胸腔积液"
            })
        
        return findings
    
    def _simulate_xray_detection(self) -> List[Dict[str, Any]]:
        """模拟 X 光检测（示例）"""
        import random
        random.seed()
        
        findings = []
        
        if random.random() > 0.6:
            findings.append({
                "type": "pneumonia",
                "location": "右下肺",
                "size_mm": round(random.uniform(20, 50), 1),
                "confidence": round(random.uniform(0.7, 0.9), 2),
                "description": "片状高密度影，考虑肺炎可能"
            })
        
        if random.random() > 0.8:
            findings.append({
                "type": "fracture",
                "location": "右侧肋骨",
                "size_mm": round(random.uniform(5, 20), 1),
                "confidence": round(random.uniform(0.75, 0.95), 2),
                "description": "骨皮质不连续，考虑骨折"
            })
        
        return findings
    
    def _generate_report(self, detections: List[Dict[str, Any]], image_type: str) -> str:
        """
        生成报告
        
        Args:
            detections: 检测结果
            image_type: 影像类型
            
        Returns:
            报告文本
        """
        report = f"{'CT' if image_type.lower() == 'ct' else 'X 光'}影像检查报告\n"
        report += "=" * 40 + "\n\n"
        
        if not detections:
            report += "影像学表现：\n"
            report += "未见明显异常。\n\n"
            report += "诊断意见：\n"
            report += "未见明显异常发现。\n"
        else:
            report += "影像学表现：\n"
            for i, detection in enumerate(detections, 1):
                report += f"{i}. {detection.get('location', '')}：{detection.get('description', '')}\n"
                report += f"   大小：{detection.get('size_mm', 0)}mm，置信度：{detection.get('confidence', 0):.0%}\n\n"
            
            report += "诊断意见：\n"
            report += self._generate_diagnosis_opinion(detections)
        
        report += f"\n检查时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
        
        return report
    
    def _generate_diagnosis_opinion(self, detections: List[Dict[str, Any]]) -> str:
        """生成诊断意见"""
        types = [d.get("type") for d in detections]
        
        if "nodule" in types:
            return "1. 肺部结节，建议进一步检查（增强 CT 或 PET-CT）\n2. 定期随访观察\n"
        elif "pneumonia" in types:
            return "1. 考虑肺炎，建议结合临床表现\n2. 抗感染治疗后复查\n"
        elif "fracture" in types:
            return "1. 骨折，建议骨科就诊\n2. 必要时行 CT 三维重建\n"
        else:
            return "建议结合临床及其他检查综合判断。\n"
    
    async def _mcp_enhance_report(self, result: Dict[str, Any]) -> str:
        """MCP 增强报告"""
        if not self.mcp_client:
            return ""
        
        prompt = f"""请优化以下影像报告，使其更加专业和规范：

影像类型：{result.get('image_type', '').upper()}
主要发现：{json.dumps(result.get('findings', []), ensure_ascii=False)}
初步报告：
{result.get('report', '')}

请提供更专业的诊断意见和随访建议。"""
        
        return await self.mcp_client.query(prompt)
    
    async def execute(self, **kwargs) -> Any:
        """执行模块功能"""
        image_path = kwargs.get("image_path", "")
        image_type = kwargs.get("image_type", "ct")
        
        if not image_path:
            return {"error": "未提供影像文件路径"}
        
        return await self.analyze_image(image_path, image_type)
    
    def format_output(self, result: Dict[str, Any]) -> str:
        """格式化输出"""
        if "error" in result:
            return f"错误：{result['error']}"
        
        output = result.get("mcp_enhanced_report") or result.get("report", "")
        
        if result.get("mcp_enhanced_report"):
            output = f"""AI 阅片结果（增强版）:
====================

{result.get('mcp_enhanced_report', '')}

原始检测结果:
"""
            for finding in result.get("findings", []):
                output += f"  - {finding.get('type', '')}: {finding.get('location', '')} "
                output += f"(置信度：{finding.get('confidence', 0):.0%})\n"
        
        return output
