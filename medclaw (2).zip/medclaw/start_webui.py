"""
启动 MedClaw Web UI
"""

import uvicorn
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

if __name__ == "__main__":
    print("=" * 60)
    print("MedClaw Web UI Starting...")
    print("=" * 60)
    print()
    print("Access:        http://localhost:8003")
    print("统一设置：      http://localhost:8003/api/settings/page")
    print("模块配置：      http://localhost:8003/api/module-config/page")
    print("Swagger Docs:  http://localhost:8003/docs")
    print()
    print("Press Ctrl+C to stop")
    print("=" * 60)

    uvicorn.run(
        "medclaw.core.medical_ui:app",
        host="0.0.0.0",
        port=8003,
        reload=False,
        log_level="info"
    )
