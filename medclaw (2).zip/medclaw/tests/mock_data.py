"""
Mock 数据文件 - 用于测试 MedClaw 功能
模拟真实的医疗数据
"""

from datetime import datetime, timedelta

# ========== 患者数据 ==========
MOCK_PATIENTS = [
    {
        "patient_id": "P001",
        "name": "张三",
        "age": 45,
        "gender": "男",
        "chief_complaint": "胸痛2小时",
        "present_illness": "患者2小时前无明显诱因出现胸痛，位于胸骨后，呈压榨性，伴大汗、恶心",
        "past_history": ["高血压5年", "糖尿病3年"],
        "allergies": ["青霉素过敏"],
        "vitals": {"bp": "140/90", "hr": 88, "rr": 20, "temp": 36.5, "spo2": 95},
        "ward": "心内科",
        "bed": "101"
    },
    {
        "patient_id": "P002",
        "name": "李四",
        "age": 32,
        "gender": "女",
        "chief_complaint": "发热3天",
        "present_illness": "患者3天前受凉后出现发热，最高体温39.2℃，伴咳嗽、咳痰",
        "past_history": [],
        "allergies": [],
        "vitals": {"bp": "120/80", "hr": 95, "rr": 22, "temp": 38.5, "spo2": 98},
        "ward": "呼吸科",
        "bed": "205"
    },
    {
        "patient_id": "P003",
        "name": "王五",
        "age": 68,
        "gender": "男",
        "chief_complaint": "头晕1周",
        "present_illness": "患者1周来反复出现头晕，伴视物旋转，恶心",
        "past_history": ["颈椎病", "脑动脉硬化"],
        "allergies": [],
        "vitals": {"bp": "150/95", "hr": 78, "rr": 18, "temp": 36.8, "spo2": 97},
        "ward": "神经内科",
        "bed": "308"
    }
]

# ========== 检验结果 ==========
MOCK_LAB_RESULTS = {
    "P001": [
        {"item": "血常规", "wbc": 7.5, "rbc": 4.5, "hgb": 140, "plt": 200, "time": datetime.now().isoformat()},
        {"item": "心肌酶", "ck_mb": 25, "troponin": 0.5, "bnp": 150, "time": datetime.now().isoformat()},
        {"item": "生化", "glucose": 7.2, "creatinine": 85, "urea": 5.2, "time": datetime.now().isoformat()}
    ],
    "P002": [
        {"item": "血常规", "wbc": 12.5, "rbc": 4.2, "hgb": 125, "plt": 220, "time": datetime.now().isoformat()},
        {"item": "C反应蛋白", "crp": 85, "time": datetime.now().isoformat()},
        {"item": "降钙素原", "pct": 0.5, "time": datetime.now().isoformat()}
    ]
}

# ========== 影像结果 ==========
MOCK_IMAGING_RESULTS = {
    "P001": [
        {
            "exam_type": "CT",
            "body_part": "胸部",
            "findings": "心影增大，肺纹理增粗，未见明显渗出影",
            "impression": "心影增大，考虑高血压性心脏病",
            "time": datetime.now().isoformat()
        }
    ],
    "P002": [
        {
            "exam_type": "X光",
            "body_part": "胸部",
            "findings": "双肺纹理增粗，右下肺可见斑片状阴影",
            "impression": "右下肺炎症",
            "time": datetime.now().isoformat()
        }
    ]
}

# ========== 病历数据 ==========
MOCK_MEDICAL_RECORDS = [
    {
        "record_id": "MR001",
        "patient_id": "P001",
        "type": "入院记录",
        "content": "患者张三，男，45岁，因胸痛2小时入院...",
        "doctor": "李医生",
        "create_time": datetime.now().isoformat(),
        "status": "completed"
    },
    {
        "record_id": "MR002",
        "patient_id": "P001",
        "type": "病程记录",
        "content": "今日查房，患者胸痛较前缓解...",
        "doctor": "李医生",
        "create_time": (datetime.now() - timedelta(days=1)).isoformat(),
        "status": "completed"
    },
    {
        "record_id": "MR003",
        "patient_id": "P002",
        "type": "入院记录",
        "content": "患者李四，女，32岁，因发热3天入院...",
        "doctor": "王医生",
        "create_time": datetime.now().isoformat(),
        "status": "completed"
    }
]

# ========== 医嘱数据 ==========
MOCK_ORDERS = {
    "P001": [
        {"order_id": "O001", "type": "长期医嘱", "content": "阿司匹林 100mg qd", "status": "active"},
        {"order_id": "O002", "type": "长期医嘱", "content": "阿托伐他汀 20mg qn", "status": "active"},
        {"order_id": "O003", "type": "临时医嘱", "content": "心电图", "status": "completed"}
    ],
    "P002": [
        {"order_id": "O004", "type": "长期医嘱", "content": "头孢呋辛 1.5g bid", "status": "active"},
        {"order_id": "O005", "type": "临时医嘱", "content": "血培养", "status": "pending"}
    ]
}

# ========== 医保数据 ==========
MOCK_INSURANCE_DATA = {
    "P001": {
        "insurance_type": "城镇职工医保",
        "insurance_id": "1234567890",
        "drg_group": "I21.9",
        "drg_name": "急性心肌梗死",
        "total_cost": 25000,
        "insurance_coverage": 20000,
        "self_pay": 5000
    },
    "P002": {
        "insurance_type": "城乡居民医保",
        "insurance_id": "0987654321",
        "drg_group": "J18.9",
        "drg_name": "肺炎",
        "total_cost": 8000,
        "insurance_coverage": 6000,
        "self_pay": 2000
    }
}

# ========== 药品数据 ==========
MOCK_DRUGS = [
    {"drug_id": "D001", "name": "阿司匹林", "spec": "100mg*30片", "price": 15.5, "stock": 100},
    {"drug_id": "D002", "name": "阿托伐他汀", "spec": "20mg*7片", "price": 45.0, "stock": 50},
    {"drug_id": "D003", "name": "头孢呋辛", "spec": "1.5g", "price": 25.0, "stock": 80},
    {"drug_id": "D004", "name": "肾上腺素", "spec": "1mg/ml", "price": 5.0, "stock": 200}
]

# ========== 质控规则 ==========
MOCK_QC_RULES = {
    "completeness": [
        {"item": "入院记录", "required": True, "weight": 10},
        {"item": "病程记录", "required": True, "weight": 10},
        {"item": "出院小结", "required": True, "weight": 10},
        {"item": "医嘱单", "required": True, "weight": 5}
    ],
    "rationality": [
        {"item": "诊断依据充分", "weight": 10},
        {"item": "治疗方案合理", "weight": 10},
        {"item": "用药规范", "weight": 10},
        {"item": "检查必要", "weight": 5}
    ]
}

# ========== 科研数据 ==========
MOCK_RESEARCH_DATA = {
    "study_id": "S001",
    "study_name": "高血压患者预后研究",
    "patients": ["P001", "P003"],
    "variables": ["age", "gender", "bp", "complications"],
    "data": [
        {"patient_id": "P001", "age": 45, "gender": "男", "bp": "140/90", "complications": 0},
        {"patient_id": "P003", "age": 68, "gender": "男", "bp": "150/95", "complications": 1}
    ]
}

# ========== 护理评估 ==========
MOCK_NURSING_ASSESSMENT = {
    "P001": {
        "adl_score": 85,
        "fall_risk": "中",
        "pressure_ulcer_risk": "低",
        "nutrition_status": "良好",
        "pain_score": 3
    },
    "P002": {
        "adl_score": 90,
        "fall_risk": "低",
        "pressure_ulcer_risk": "低",
        "nutrition_status": "一般",
        "pain_score": 1
    }
}

# ========== 康复评估 ==========
MOCK_REHAB_ASSESSMENT = {
    "P001": {
        "motor_function": {"upper_limb": 4, "lower_limb": 4, "total": 8},
        "adl_score": 85,
        "cognitive_function": "正常",
        "rehab_plan": ["肢体功能训练", "日常生活能力训练"]
    }
}

print("✅ Mock 数据加载完成")
print(f"   患者数量: {len(MOCK_PATIENTS)}")
print(f"   病历数量: {len(MOCK_MEDICAL_RECORDS)}")
print(f"   检验项目: {sum(len(v) for v in MOCK_LAB_RESULTS.values())}")
