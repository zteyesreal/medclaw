"""
MedClaw 工具编排端到端集成测试
测试完整编排流程、缓存集成、权限检查、审计日志
"""

import asyncio
import sys
import time
import pytest
from pathlib import Path
from datetime import datetime
from typing import Dict, Any
from unittest.mock import AsyncMock, MagicMock, patch

project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from medclaw.core.mcp_client import MCPClient, MCPError, MCPErrorCode
from medclaw.core.tool_orchestrator import ToolOrchestrator, ToolChain
from medclaw.core.tool_cache import MemoryToolCache
from medclaw.core.tool_permissions import ToolPermissionManager, ToolRole
from medclaw.core.tool_audit import ToolAuditLogger


class TestCompleteOrchestrationFlow:
    """完整编排流程测试"""

    @pytest.mark.asyncio
    async def test_create_mcp_client_and_register_tools(self):
        """
        测试创建 MCP 客户端并注册多个工具
        验证工具注册成功且可调用
        """
        client = MCPClient()
        await client.initialize()

        tool_handlers = {
            "read_file": lambda path: {"content": f"content of {path}", "size": 100},
            "parse_content": lambda content: {"word_count": len(content.split()), "char_count": len(content)},
            "analyze_data": lambda data: {"summary": f"analyzed {data}", "metrics": {"mean": 50, "std": 10}},
        }

        for name, handler in tool_handlers.items():
            client.register_tool(
                name=name,
                description=f"Test tool {name}",
                input_schema={
                    "type": "object",
                    "properties": {
                        "path" if name == "read_file" else "content" if name == "parse_content" else "data": {"type": "string"}
                    },
                    "required": ["path"] if name == "read_file" else ["content"] if name == "parse_content" else ["data"]
                },
                handler=handler
            )

        tools = client.list_tools()
        assert len(tools) >= 3, "应该成功注册至少3个工具"

        tool_names = [t["name"] for t in tools]
        assert "read_file" in tool_names, "read_file 工具应该已注册"
        assert "parse_content" in tool_names, "parse_content 工具应该已注册"
        assert "analyze_data" in tool_names, "analyze_data 工具应该已注册"

    @pytest.mark.asyncio
    async def test_execute_chain_with_multiple_tools(self):
        """
        测试使用 ToolOrchestrator 执行链式调用
        验证工具链正确执行并传递结果
        """
        client = MCPClient()
        await client.initialize()

        client.register_tool(
            name="step1_get_data",
            description="第一步：获取数据",
            input_schema={
                "type": "object",
                "properties": {"source": {"type": "string"}},
                "required": ["source"]
            },
            handler=lambda source: {"data": f"data from {source}", "id": 1}
        )

        client.register_tool(
            name="step2_transform",
            description="第二步：转换数据",
            input_schema={
                "type": "object",
                "properties": {"input_data": {"type": "object"}},
                "required": ["input_data"]
            },
            handler=lambda input_data: {"transformed": f"transformed: {input_data.get('data', '')}", "id": 2}
        )

        client.register_tool(
            name="step3_save",
            description="第三步：保存结果",
            input_schema={
                "type": "object",
                "properties": {"result_data": {"type": "object"}},
                "required": ["result_data"]
            },
            handler=lambda result_data: {"saved": True, "data": result_data, "id": 3}
        )

        orchestrator = ToolOrchestrator(
            mcp_client=client,
            cache_enabled=False,
            permission_enabled=False,
            audit_enabled=False
        )
        await orchestrator.initialize()

        chain = orchestrator.create_chain()
        chain.add_step("step1_get_data", {"source": "database"})
        chain.add_step("step2_transform", {}, output_mapping="input_data")
        chain.add_step("step3_save", {}, output_mapping="result_data")

        results = await orchestrator.execute_chain(chain)

        assert len(results) == 3, "应该返回3个步骤的结果"
        assert results[0]["id"] == 1, "第一步结果应该包含 id=1"
        assert results[1]["id"] == 2, "第二步结果应该包含 id=2"
        assert results[2]["id"] == 3, "第三步结果应该包含 id=3"
        assert "transformed" in results[1], "第二步应该返回转换后的数据"

    @pytest.mark.asyncio
    async def test_chain_with_conditional_execution(self):
        """
        测试工具链条件执行
        验证条件函数正确控制步骤执行
        """
        client = MCPClient()
        await client.initialize()

        client.register_tool(
            name="check_status",
            description="检查状态",
            input_schema={"type": "object", "properties": {}},
            handler=lambda: {"status": "active"}
        )

        client.register_tool(
            name="process_active",
            description="处理活跃状态",
            input_schema={"type": "object", "properties": {}},
            handler=lambda: {"result": "processing active"}
        )

        client.register_tool(
            name="process_inactive",
            description="处理非活跃状态",
            input_schema={"type": "object", "properties": {}},
            handler=lambda: {"result": "processing inactive"}
        )

        orchestrator = ToolOrchestrator(
            mcp_client=client,
            cache_enabled=False,
            permission_enabled=False,
            audit_enabled=False
        )
        await orchestrator.initialize()

        chain = orchestrator.create_chain()
        chain.add_step("check_status")
        chain.add_step(
            "process_active",
            condition=lambda prev: prev.get("status") == "active"
        )
        chain.add_step(
            "process_inactive",
            condition=lambda prev: prev.get("status") != "active"
        )

        results = await orchestrator.execute_chain(chain)

        assert len(results) == 3, "应该有3个步骤"
        assert results[0]["status"] == "active", "状态检查应该返回 active"
        assert results[1]["result"] == "processing active", "应该执行活跃处理"
        assert results[2]["result"] == "processing inactive", "两个条件互补，都应该执行"

    @pytest.mark.asyncio
    async def test_parallel_execution_multiple_tools(self):
        """
        测试并行执行多个工具
        验证并行执行比串行快
        """
        client = MCPClient()
        await client.initialize()

        for i in range(5):
            client.register_tool(
                name=f"parallel_tool_{i}",
                description=f"并行工具 {i}",
                input_schema={"type": "object", "properties": {}},
                handler=lambda idx=i: {"tool": f"parallel_tool_{idx}", "completed": True}
            )

        orchestrator = ToolOrchestrator(
            mcp_client=client,
            cache_enabled=False,
            permission_enabled=False,
            audit_enabled=False
        )
        await orchestrator.initialize()

        tool_calls = [(f"parallel_tool_{i}", {}) for i in range(5)]

        start_time = time.time()
        results = await orchestrator.execute_parallel(tool_calls)
        parallel_time = time.time() - start_time

        assert len(results) == 5, "应该返回5个结果"
        assert all(r.get("completed") for r in results if r), "所有工具应该完成"
        assert parallel_time < 0.2, f"并行执行应该快于0.2秒，实际: {parallel_time:.3f}"


class TestCacheIntegration:
    """缓存集成测试"""

    @pytest.mark.asyncio
    async def test_cache_hit_on_repeated_call(self):
        """
        测试缓存命中
        验证相同参数的重复调用直接返回缓存结果
        """
        client = MCPClient()
        await client.initialize()

        call_count = 0

        def expensive_handler(input: str):
            nonlocal call_count
            call_count += 1
            return {"result": f"processed: {input}", "call_number": call_count}

        client.register_tool(
            name="expensive_op",
            description="耗时操作",
            input_schema={
                "type": "object",
                "properties": {"input": {"type": "string"}},
                "required": ["input"]
            },
            handler=expensive_handler
        )

        orchestrator = ToolOrchestrator(
            mcp_client=client,
            cache_enabled=True,
            permission_enabled=False,
            audit_enabled=False,
            cache_config={"type": "memory", "max_size": 100, "default_ttl": 60}
        )
        await orchestrator.initialize()

        result1 = await orchestrator.execute("expensive_op", {"input": "test_data"})
        assert call_count == 1, "第一次调用应该执行真实操作"

        result2 = await orchestrator.execute("expensive_op", {"input": "test_data"})
        assert call_count == 1, "第二次调用应该命中缓存"
        assert result1["call_number"] == result2["call_number"], "缓存结果应该与第一次相同"

        stats = orchestrator.get_stats()
        assert stats["cache_hits"] == 1, "应该有1次缓存命中"
        assert stats["total_calls"] == 2, "总共应该有2次调用"

    @pytest.mark.asyncio
    async def test_cache_invalidation_on_clear(self):
        """
        测试缓存失效
        验证清空缓存后重新执行真实操作
        """
        client = MCPClient()
        await client.initialize()

        call_count = 0

        def tracked_handler(input: str):
            nonlocal call_count
            call_count += 1
            return {"result": input, "call_number": call_count}

        client.register_tool(
            name="tracked_op",
            description="跟踪操作",
            input_schema={
                "type": "object",
                "properties": {"input": {"type": "string"}},
                "required": ["input"]
            },
            handler=tracked_handler
        )

        orchestrator = ToolOrchestrator(
            mcp_client=client,
            cache_enabled=True,
            permission_enabled=False,
            audit_enabled=False
        )
        await orchestrator.initialize()

        result1 = await orchestrator.execute("tracked_op", {"input": "data"})
        assert call_count == 1, "第一次调用"

        result2 = await orchestrator.execute("tracked_op", {"input": "data"})
        assert call_count == 1, "应该命中缓存"

        await orchestrator.clear_cache()

        result3 = await orchestrator.execute("tracked_op", {"input": "data"})
        assert call_count == 2, "清空缓存后应该重新执行"

    @pytest.mark.asyncio
    async def test_cache_ttl_expiration(self):
        """
        测试 TTL 过期
        验证缓存过期后重新执行操作
        """
        client = MCPClient()
        await client.initialize()

        call_count = 0

        def ttl_handler(input: str):
            nonlocal call_count
            call_count += 1
            return {"result": input, "call_number": call_count}

        client.register_tool(
            name="ttl_op",
            description="TTL 操作",
            input_schema={
                "type": "object",
                "properties": {"input": {"type": "string"}},
                "required": ["input"]
            },
            handler=ttl_handler
        )

        orchestrator = ToolOrchestrator(
            mcp_client=client,
            cache_enabled=True,
            permission_enabled=False,
            audit_enabled=False,
            cache_config={"type": "memory", "max_size": 100, "default_ttl": 1}
        )
        await orchestrator.initialize()

        result1 = await orchestrator.execute("ttl_op", {"input": "ttl_test"})
        assert call_count == 1, "第一次调用"

        result2 = await orchestrator.execute("ttl_op", {"input": "ttl_test"})
        assert call_count == 1, "应该命中缓存"

        await asyncio.sleep(1.5)

        result3 = await orchestrator.execute("ttl_op", {"input": "ttl_test"})
        assert call_count == 2, "TTL 过期后应该重新执行"

    @pytest.mark.asyncio
    async def test_cache_bypass(self):
        """
        测试绕过缓存
        验证 bypass_cache 参数可以强制执行真实操作
        """
        client = MCPClient()
        await client.initialize()

        call_count = 0

        def bypass_handler(input: str):
            nonlocal call_count
            call_count += 1
            return {"result": input, "call_number": call_count}

        client.register_tool(
            name="bypass_op",
            description="绕过操作",
            input_schema={
                "type": "object",
                "properties": {"input": {"type": "string"}},
                "required": ["input"]
            },
            handler=bypass_handler
        )

        orchestrator = ToolOrchestrator(
            mcp_client=client,
            cache_enabled=True,
            permission_enabled=False,
            audit_enabled=False
        )
        await orchestrator.initialize()

        result1 = await orchestrator.execute("bypass_op", {"input": "test"})
        assert call_count == 1

        result2 = await orchestrator.execute("bypass_op", {"input": "test"}, bypass_cache=True)
        assert call_count == 2, "绕过缓存应该重新执行"

    @pytest.mark.asyncio
    async def test_different_params_different_cache(self):
        """
        测试不同参数产生不同缓存
        验证参数不同缓存键不同
        """
        client = MCPClient()
        await client.initialize()

        call_count = 0

        def params_handler(input: str):
            nonlocal call_count
            call_count += 1
            return {"result": input, "call_number": call_count}

        client.register_tool(
            name="params_op",
            description="参数操作",
            input_schema={
                "type": "object",
                "properties": {"input": {"type": "string"}},
                "required": ["input"]
            },
            handler=params_handler
        )

        orchestrator = ToolOrchestrator(
            mcp_client=client,
            cache_enabled=True,
            permission_enabled=False,
            audit_enabled=False
        )
        await orchestrator.initialize()

        await orchestrator.execute("params_op", {"input": "a"})
        assert call_count == 1

        await orchestrator.execute("params_op", {"input": "b"})
        assert call_count == 2, "不同参数应该产生不同缓存"

        await orchestrator.execute("params_op", {"input": "a"})
        assert call_count == 2, "相同参数应该命中缓存"


class TestPermissionCheck:
    """权限检查测试"""

    @pytest.mark.asyncio
    async def test_admin_has_full_permission(self):
        """
        测试管理员拥有全部权限
        验证 admin 角色可以调用所有工具
        """
        client = MCPClient()
        await client.initialize()

        client.register_tool(
            name="admin_tool",
            description="管理员工具",
            input_schema={"type": "object", "properties": {}},
            handler=lambda: {"access": "granted", "role": "admin"}
        )

        client.register_tool(
            name="user_tool",
            description="用户工具",
            input_schema={"type": "object", "properties": {}},
            handler=lambda: {"access": "granted", "role": "user"}
        )

        orchestrator = ToolOrchestrator(
            mcp_client=client,
            cache_enabled=False,
            permission_enabled=True,
            audit_enabled=False
        )
        await orchestrator.initialize()

        permission_manager = orchestrator.permission_manager
        permission_manager.add_user_role("admin_user", ToolRole.ADMIN)

        with patch.object(permission_manager, 'get_user_role', return_value=ToolRole.ADMIN):
            result = await orchestrator.execute("admin_tool", bypass_permission=False)
            assert result["access"] == "granted", "管理员应该有权限"

            result2 = await orchestrator.execute("user_tool", bypass_permission=False)
            assert result2["access"] == "granted", "管理员应该有权限"

    @pytest.mark.asyncio
    async def test_guest_denied_for_restricted_tool(self):
        """
        测试访客被拒绝访问受限工具
        验证无权限用户无法调用受限工具
        """
        client = MCPClient()
        await client.initialize()

        client.register_tool(
            name="restricted_tool",
            description="受限工具",
            input_schema={"type": "object", "properties": {}},
            handler=lambda: {"secret": "data"}
        )

        orchestrator = ToolOrchestrator(
            mcp_client=client,
            cache_enabled=False,
            permission_enabled=True,
            audit_enabled=False
        )
        await orchestrator.initialize()

        permission_manager = orchestrator.permission_manager
        permission_manager.set_role_tools(ToolRole.USER, ["restricted_tool"])
        permission_manager.set_role_tools(ToolRole.GUEST, [])

        with patch.object(permission_manager, 'has_permission', return_value=False):
            with pytest.raises(PermissionError) as exc_info:
                await orchestrator.execute("restricted_tool", bypass_permission=False)

            assert "没有权限" in str(exc_info.value), "应该抛出权限错误"

    @pytest.mark.asyncio
    async def test_bypass_permission_flag(self):
        """
        测试绕过权限标志
        验证 bypass_permission 可以跳过权限检查
        """
        client = MCPClient()
        await client.initialize()

        client.register_tool(
            name="secret_tool",
            description="秘密工具",
            input_schema={"type": "object", "properties": {}},
            handler=lambda: {"secret": "exposed"}
        )

        orchestrator = ToolOrchestrator(
            mcp_client=client,
            cache_enabled=False,
            permission_enabled=True,
            audit_enabled=False
        )
        await orchestrator.initialize()

        with patch.object(orchestrator.permission_manager, 'has_permission', return_value=False):
            result = await orchestrator.execute("secret_tool", bypass_permission=True)
            assert result["secret"] == "exposed", "绕过权限后应该能执行"


class TestAuditLogging:
    """审计日志测试"""

    @pytest.mark.asyncio
    async def test_audit_log_records_tool_calls(self):
        """
        测试审计日志记录工具调用
        验证每次调用都被正确记录
        """
        client = MCPClient()
        await client.initialize()

        client.register_tool(
            name="audit_tool",
            description="审计工具",
            input_schema={
                "type": "object",
                "properties": {"action": {"type": "string"}},
                "required": ["action"]
            },
            handler=lambda action: {"performed": action}
        )

        orchestrator = ToolOrchestrator(
            mcp_client=client,
            cache_enabled=False,
            permission_enabled=False,
            audit_enabled=True
        )
        await orchestrator.initialize()

        for i in range(3):
            await orchestrator.execute("audit_tool", {"action": f"action_{i}"})

        stats = orchestrator.get_stats()
        assert stats["total_calls"] == 3, "应该有3次调用记录"

        audit_stats = stats.get("audit", {})
        assert audit_stats.get("total_logs", 0) >= 3, "审计日志应该记录至少3条"

    @pytest.mark.asyncio
    async def test_audit_log_query_by_tool_name(self):
        """
        测试按工具名称查询审计日志
        验证可以过滤特定工具的日志
        """
        client = MCPClient()
        await client.initialize()

        client.register_tool(
            name="specific_tool",
            description="特定工具",
            input_schema={"type": "object", "properties": {}},
            handler=lambda: {"result": "specific"}
        )

        client.register_tool(
            name="other_tool",
            description="其他工具",
            input_schema={"type": "object", "properties": {}},
            handler=lambda: {"result": "other"}
        )

        orchestrator = ToolOrchestrator(
            mcp_client=client,
            cache_enabled=False,
            permission_enabled=False,
            audit_enabled=True
        )
        await orchestrator.initialize()

        await orchestrator.execute("specific_tool", {})
        await orchestrator.execute("other_tool", {})
        await orchestrator.execute("specific_tool", {})

        audit_logger = orchestrator.audit_logger
        specific_logs = audit_logger.query_logs(tool_name="specific_tool", limit=10)

        assert len(specific_logs) >= 2, "应该找到至少2条 specific_tool 的日志"
        assert all(log["tool_name"] == "specific_tool" for log in specific_logs), "所有日志应该是 specific_tool"

    @pytest.mark.asyncio
    async def test_audit_log_records_duration(self):
        """
        测试审计日志记录执行时长
        验证每个调用都记录了执行时间
        """
        client = MCPClient()
        await client.initialize()

        client.register_tool(
            name="timed_tool",
            description="计时工具",
            input_schema={"type": "object", "properties": {}},
            handler=lambda: time.sleep(0.01) or {"done": True}
        )

        orchestrator = ToolOrchestrator(
            mcp_client=client,
            cache_enabled=False,
            permission_enabled=False,
            audit_enabled=True
        )
        await orchestrator.initialize()

        await orchestrator.execute("timed_tool", {})

        audit_logger = orchestrator.audit_logger
        logs = audit_logger.query_logs(tool_name="timed_tool", limit=1)

        assert len(logs) > 0, "应该有日志记录"
        assert "duration" in logs[0], "日志应该包含 duration 字段"
        assert logs[0]["duration"] > 0, "执行时长应该大于0"

    @pytest.mark.asyncio
    async def test_audit_log_includes_params(self):
        """
        测试审计日志包含参数信息
        验证记录了调用参数
        """
        client = MCPClient()
        await client.initialize()

        client.register_tool(
            name="param_tool",
            description="参数工具",
            input_schema={
                "type": "object",
                "properties": {
                    "id": {"type": "integer"},
                    "name": {"type": "string"}
                },
                "required": ["id"]
            },
            handler=lambda id, name=None: {"id": id, "name": name}
        )

        orchestrator = ToolOrchestrator(
            mcp_client=client,
            cache_enabled=False,
            permission_enabled=False,
            audit_enabled=True
        )
        await orchestrator.initialize()

        await orchestrator.execute("param_tool", {"id": 123, "name": "test"})

        audit_logger = orchestrator.audit_logger
        logs = audit_logger.query_logs(tool_name="param_tool", limit=1)

        assert len(logs) > 0, "应该有日志"
        assert logs[0]["params"]["id"] == 123, "参数应该被记录"
        assert logs[0]["params"]["name"] == "test", "参数应该被记录"


class TestErrorHandling:
    """错误处理测试"""

    @pytest.mark.asyncio
    async def test_tool_not_found_error(self):
        """
        测试工具不存在错误
        验证调用不存在的工具时抛出正确错误
        """
        client = MCPClient()
        await client.initialize()

        orchestrator = ToolOrchestrator(
            mcp_client=client,
            cache_enabled=False,
            permission_enabled=False,
            audit_enabled=False
        )
        await orchestrator.initialize()

        with pytest.raises(MCPError) as exc_info:
            await orchestrator.execute("nonexistent_tool", {})

        assert exc_info.value.code == MCPErrorCode.TOOL_NOT_FOUND

    @pytest.mark.asyncio
    async def test_invalid_params_error(self):
        """
        测试参数错误
        验证参数不符合 schema 时抛出错误
        """
        client = MCPClient()
        await client.initialize()

        client.register_tool(
            name="strict_tool",
            description="严格工具",
            input_schema={
                "type": "object",
                "properties": {
                    "required_param": {"type": "string"}
                },
                "required": ["required_param"]
            },
            handler=lambda required_param: {"result": required_param}
        )

        orchestrator = ToolOrchestrator(
            mcp_client=client,
            cache_enabled=False,
            permission_enabled=False,
            audit_enabled=False
        )
        await orchestrator.initialize()

        with pytest.raises(MCPError) as exc_info:
            await orchestrator.execute("strict_tool", {})

        assert exc_info.value.code == MCPErrorCode.INVALID_PARAMS


class TestStatsAndMonitoring:
    """统计和监控测试"""

    @pytest.mark.asyncio
    async def test_orchestrator_stats_tracking(self):
        """
        测试编排器统计跟踪
        验证统计数据正确记录
        """
        client = MCPClient()
        await client.initialize()

        client.register_tool(
            name="stat_tool",
            description="统计工具",
            input_schema={"type": "object", "properties": {}},
            handler=lambda: {"result": "ok"}
        )

        orchestrator = ToolOrchestrator(
            mcp_client=client,
            cache_enabled=True,
            permission_enabled=True,
            audit_enabled=True
        )
        await orchestrator.initialize()

        await orchestrator.execute("stat_tool", {})
        await orchestrator.execute("stat_tool", {})

        stats = orchestrator.get_stats()

        assert stats["total_calls"] == 2, "总调用次数应为2"
        assert stats["cache_hits"] == 1, "应有1次缓存命中"

    @pytest.mark.asyncio
    async def test_chain_execution_stats(self):
        """
        测试工具链执行统计
        验证链执行后统计信息正确
        """
        client = MCPClient()
        await client.initialize()

        client.register_tool(
            name="stat_step_1",
            description="统计步骤1",
            input_schema={"type": "object", "properties": {}},
            handler=lambda: time.sleep(0.01) or {"step": 1}
        )

        client.register_tool(
            name="stat_step_2",
            description="统计步骤2",
            input_schema={"type": "object", "properties": {}},
            handler=lambda: time.sleep(0.01) or {"step": 2}
        )

        orchestrator = ToolOrchestrator(
            mcp_client=client,
            cache_enabled=False,
            permission_enabled=False,
            audit_enabled=False
        )
        await orchestrator.initialize()

        chain = orchestrator.create_chain()
        chain.add_step("stat_step_1")
        chain.add_step("stat_step_2")

        await orchestrator.execute_chain(chain)

        chain_stats = chain.get_stats()

        assert chain_stats["steps_count"] == 2, "步骤数应为2"
        assert chain_stats["results_count"] == 2, "结果数应为2"
        assert chain_stats["duration_seconds"] >= 0, "执行时间应大于等于0"
