"""
MedClaw 模块功能测试脚本
测试各个模块的基本功能
"""

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from medclaw.core import ConfigManager, MCPClient
from medclaw.modules import (
    MedicalRecordModule,
    MedicalQualityModule,
    InsuranceAnalysisModule,
    ClinicalPredictionModule,
    AIReadingModule,
    ResearchAnalysisModule,
    PaperAnalysisModule,
)


async def test_medical_record():
    """测试病历书写模块"""
    print("\n" + "=" * 60)
    print("测试病历书写模块")
    print("=" * 60)
    
    config = {
        "template_dir": "./templates/medical_record"
    }
    
    module = MedicalRecordModule(config=config, mcp_client=None)
    
    input_data = {
        "patient_info": {
            "name": "张三",
            "gender": "男",
            "age": 45
        },
        "chief_complaint": "头痛三天",
        "present_illness": "患者三天前无明显诱因出现头痛，以额部为主，呈胀痛...",
        "template": "default"
    }
    
    result = await module.execute(action="generate", input_data=input_data)
    
    print("病历生成结果:")
    print(result[:500] if len(result) > 500 else result)
    print("\n✅ 病历书写模块测试完成")


async def test_medical_quality():
    """测试病历质控模块"""
    print("\n" + "=" * 60)
    print("测试病历质控模块")
    print("=" * 60)
    
    config = {
        "rule_dir": "./rules/medical_quality"
    }
    
    module = MedicalQualityModule(config=config, mcp_client=None)
    
    medical_record = {
        "chief_complaint": "头痛三天",
        "present_illness": "患者三天前无明显诱因出现头痛...",
        "diagnosis": "紧张性头痛",
        "patient_age": 45
    }
    
    result = await module.execute(medical_record=medical_record)
    
    print("质控结果:")
    print(module.format_output(result))
    print("\n✅ 病历质控模块测试完成")


async def test_insurance_analysis():
    """测试医保分析模块"""
    print("\n" + "=" * 60)
    print("测试医保分析模块")
    print("=" * 60)
    
    config = {
        "drg_dict_path": "./data/drg_dict.json",
        "rule_dir": "./rules/insurance"
    }
    
    module = InsuranceAnalysisModule(config=config, mcp_client=None)
    
    medical_record = {
        "diagnosis": "急性阑尾炎",
        "procedures": ["阑尾切除术"],
        "complications": ["腹腔感染"],
        "cost_details": {
            "total": 18000,
            "drugs": 6000,
            "examinations": 5000,
            "consumables": 3000,
            "examination_items": ["血常规", "尿常规", "肝功能", "肾功能", "心电图", "胸片", "腹部 CT"]
        }
    }
    
    result = await module.execute(medical_record=medical_record)
    
    print("医保分析结果:")
    print(module.format_output(result))
    print("\n✅ 医保分析模块测试完成")


async def test_clinical_prediction():
    """测试临床预测模块"""
    print("\n" + "=" * 60)
    print("测试临床预测模块")
    print("=" * 60)
    
    config = {
        "model_dir": "./models/clinical"
    }
    
    module = ClinicalPredictionModule(config=config, mcp_client=None)
    
    patient_data = {
        "age": 70,
        "temperature": 39.5,
        "heart_rate": 110,
        "respiratory_rate": 28,
        "wbc": 18.5
    }
    
    result = await module.execute(model_name="sepsis", patient_data=patient_data)
    
    print("败血症风险预测结果:")
    print(module.format_output(result))
    print("\n✅ 临床预测模块测试完成")


async def test_ai_reading():
    """测试 AI 阅片模块"""
    print("\n" + "=" * 60)
    print("测试 AI 阅片模块")
    print("=" * 60)
    
    config = {
        "model_name": "resnet50",
        "weights_path": "./models/ai_reading/model.pth",
        "device": "cpu",
        "dicom_cache": "./cache/dicom"
    }
    
    module = AIReadingModule(config=config, mcp_client=None)
    
    result = await module.execute(image_path="./test_image.dcm", image_type="ct")
    
    print("AI 阅片结果:")
    print(module.format_output(result))
    print("\n✅ AI 阅片模块测试完成")


async def test_research_analysis():
    """测试科研分析模块"""
    print("\n" + "=" * 60)
    print("测试科研分析模块")
    print("=" * 60)
    
    config = {
        "data_dir": "./data/research"
    }
    
    module = ResearchAnalysisModule(config=config, mcp_client=None)
    
    data = {
        "blood_pressure": [120, 125, 130, 128, 135, 140, 138, 142, 145, 143],
        "heart_rate": [75, 78, 80, 82, 85, 83, 80, 78, 76, 75]
    }
    
    result = await module.execute(data=data, analysis_type="descriptive")
    
    print("科研分析结果:")
    print(module.format_output(result))
    print("\n✅ 科研分析模块测试完成")


async def test_paper_analysis():
    """测试论文分析模块"""
    print("\n" + "=" * 60)
    print("测试论文分析模块")
    print("=" * 60)
    
    config = {
        "cache_dir": "./cache/papers"
    }
    
    module = PaperAnalysisModule(config=config, mcp_client=None)
    
    sample_text = """
    Title: A Study on Machine Learning in Medical Diagnosis
    
    Abstract: This study investigates the application of machine learning 
    algorithms in medical diagnosis. We analyzed 1000 patient cases and 
    found that deep learning models achieved 95% accuracy in detecting 
    certain diseases.
    
    Methods: We used convolutional neural networks (CNN) and random forest 
    algorithms to analyze medical imaging data.
    
    Results: The CNN model showed superior performance with 95% accuracy, 
    93% sensitivity, and 96% specificity.
    
    Conclusion: Machine learning shows great potential in assisting medical 
    diagnosis, particularly in medical imaging analysis.
    """
    
    result = await module.execute(paper_input=sample_text, input_type="text")
    
    print("论文分析结果:")
    print(module.format_output(result))
    print("\n✅ 论文分析模块测试完成")


async def main():
    """主测试函数"""
    print("\n" + "=" * 60)
    print("MedClaw 模块功能测试")
    print("=" * 60)
    
    try:
        await test_medical_record()
        await test_medical_quality()
        await test_insurance_analysis()
        await test_clinical_prediction()
        await test_ai_reading()
        await test_research_analysis()
        await test_paper_analysis()
        
        print("\n" + "=" * 60)
        print("✅ 所有模块测试完成!")
        print("=" * 60)
        
    except Exception as e:
        print(f"\n❌ 测试失败：{e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    asyncio.run(main())
