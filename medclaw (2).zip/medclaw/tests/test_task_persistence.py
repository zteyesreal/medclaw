"""
MedClaw 任务持久化测试
测试 SQLite 和 MySQL 存储
"""

import asyncio
import sys
from pathlib import Path
from datetime import datetime
import logging

# 添加路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from medclaw.core.task_storage import (
    TaskRecord,
    TaskStorageFactory,
    SQLiteTaskStorage,
)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


async def test_sqlite_storage():
    """测试 SQLite 存储"""
    print("\n" + "="*70)
    print("测试 1: SQLite 任务存储")
    print("="*70)
    
    # 创建存储
    storage = SQLiteTaskStorage(db_path="test_tasks.db")
    await storage.initialize()
    
    try:
        # 创建任务
        print("\n创建任务...")
        task = TaskRecord(
            task_id="task_001",
            task_type="file_processing",
            task_data={"file": "test.txt", "action": "read"},
            status="pending",
            priority=8,
            metadata={"user": "test_user"}
        )
        
        result = await storage.save_task(task)
        print(f"  保存任务：{'✅' if result else '❌'}")
        
        # 获取任务
        print("\n获取任务...")
        retrieved = await storage.get_task("task_001")
        if retrieved:
            print(f"  任务 ID: {retrieved.task_id}")
            print(f"  任务类型：{retrieved.task_type}")
            print(f"  状态：{retrieved.status}")
            print(f"  优先级：{retrieved.priority}")
        
        # 更新任务
        print("\n更新任务状态...")
        await storage.update_task("task_001", {
            "status": "running",
            "started_at": datetime.now(),
            "worker_id": "worker_1"
        })
        
        retrieved = await storage.get_task("task_001")
        print(f"  新状态：{retrieved.status}")
        print(f"  Worker: {retrieved.worker_id}")
        
        # 创建更多任务
        print("\n创建更多任务...")
        for i in range(2, 6):
            task = TaskRecord(
                task_id=f"task_{i:03d}",
                task_type="data_analysis" if i % 2 == 0 else "file_processing",
                task_data={"index": i},
                status="pending" if i % 3 != 0 else "completed",
                priority=10 - i,
            )
            await storage.save_task(task)
        
        print(f"  已创建 5 个任务")
        
        # 查询任务
        print("\n查询任务...")
        
        # 按状态查询
        pending_tasks = await storage.query_tasks(status="pending", limit=10)
        print(f"  待处理任务：{len(pending_tasks)} 个")
        
        # 按类型查询
        file_tasks = await storage.query_tasks(task_type="file_processing", limit=10)
        print(f"  文件处理任务：{len(file_tasks)} 个")
        
        # 分页查询
        print("\n分页查询...")
        page1 = await storage.query_tasks(limit=2, offset=0)
        page2 = await storage.query_tasks(limit=2, offset=2)
        print(f"  第 1 页：{len(page1)} 个任务")
        print(f"  第 2 页：{len(page2)} 个任务")
        
        # 完成任务
        print("\n完成任务...")
        await storage.update_task("task_001", {
            "status": "completed",
            "completed_at": datetime.now(),
            "result": {"processed": True, "lines": 100}
        })
        
        retrieved = await storage.get_task("task_001")
        print(f"  最终状态：{retrieved.status}")
        print(f"  结果：{retrieved.result}")
        
        # 删除任务
        print("\n删除任务...")
        await storage.delete_task("task_005")
        deleted = await storage.get_task("task_005")
        print(f"  task_005 已删除：{'✅' if deleted is None else '❌'}")
        
        print("\n✅ SQLite 存储测试通过")
        
    except Exception as e:
        print(f"❌ 测试失败：{e}")
        import traceback
        traceback.print_exc()
    
    finally:
        await storage.cleanup()


async def test_storage_factory():
    """测试存储工厂"""
    print("\n" + "="*70)
    print("测试 2: 存储工厂")
    print("="*70)
    
    try:
        # 创建 SQLite 存储
        print("\n创建 SQLite 存储...")
        sqlite_storage = TaskStorageFactory.create_storage(
            "sqlite",
            db_path="factory_test.db"
        )
        await sqlite_storage.initialize()
        print(f"  存储类型：{type(sqlite_storage).__name__}")
        print(f"  数据库路径：factory_test.db")
        
        # 保存测试任务
        task = TaskRecord(
            task_id="factory_task_001",
            task_type="test",
            task_data={"test": "data"},
            status="pending"
        )
        await sqlite_storage.save_task(task)
        
        retrieved = await sqlite_storage.get_task("factory_task_001")
        print(f"  保存并获取任务：{'✅' if retrieved else '❌'}")
        
        await sqlite_storage.cleanup()
        
        # 测试 MySQL 工厂（需要 MySQL 服务）
        print("\n创建 MySQL 存储（跳过实际连接）...")
        try:
            mysql_storage = TaskStorageFactory.create_storage(
                "mysql",
                host="localhost",
                database="medclaw",
                user="root",
                password=""
            )
            print(f"  MySQL 存储已创建（未连接）")
        except Exception as e:
            print(f"  MySQL 存储创建跳过：{e}")
        
        print("\n✅ 存储工厂测试通过")
        
    except Exception as e:
        print(f"❌ 测试失败：{e}")
        import traceback
        traceback.print_exc()


async def test_task_history():
    """测试任务历史"""
    print("\n" + "="*70)
    print("测试 3: 任务历史记录")
    print("="*70)
    
    storage = SQLiteTaskStorage(db_path="test_history.db")
    await storage.initialize()
    
    try:
        # 创建任务
        print("\n创建任务...")
        task = TaskRecord(
            task_id="history_task_001",
            task_type="test",
            task_data={"test": "history"},
            status="pending"
        )
        await storage.save_task(task)
        
        # 模拟状态变更
        print("\n模拟状态变更...")
        from medclaw.core.task_storage import TaskHistoryRecord
        
        status_changes = [
            ("pending", "running"),
            ("running", "completed"),
        ]
        
        for old_status, new_status in status_changes:
            # 更新任务状态
            await storage.update_task("history_task_001", {
                "status": new_status,
                "updated_at": datetime.now()
            })
            
            # 保存历史记录
            history = TaskHistoryRecord(
                history_id=f"hist_{old_status}_{new_status}",
                task_id="history_task_001",
                old_status=old_status,
                new_status=new_status,
                changed_at=datetime.now(),
                reason="自动状态更新",
                operator="system"
            )
            await storage.save_history(history)
            print(f"  状态变更：{old_status} -> {new_status}")
        
        # 查询历史记录
        print("\n查询历史记录...")
        history_records = await storage.get_history("history_task_001", limit=10)
        
        print(f"  历史记录数：{len(history_records)}")
        for record in history_records:
            print(f"    [{record.changed_at.strftime('%H:%M:%S')}] "
                  f"{record.old_status} -> {record.new_status} "
                  f"(操作员：{record.operator})")
        
        print("\n✅ 任务历史测试通过")
        
    except Exception as e:
        print(f"❌ 测试失败：{e}")
        import traceback
        traceback.print_exc()
    
    finally:
        await storage.cleanup()


async def main():
    """运行所有测试"""
    print("\n" + "="*70)
    print("MedClaw 任务持久化测试")
    print("="*70)
    
    # 运行测试
    await test_sqlite_storage()
    await test_storage_factory()
    await test_task_history()
    
    print("\n" + "="*70)
    print("所有测试完成！")
    print("="*70)
    print("""
已测试的任务持久化功能:
  ✅ SQLite 存储（任务 CRUD 操作）
  ✅ 存储工厂（统一创建接口）
  ✅ 任务历史（状态变更跟踪）
  ✅ 查询功能（按状态、类型、分页）

支持的数据:
  ✅ SQLite（默认，使用 aiosqlite）
  ✅ MySQL（使用 aiomysql）
  ⏸️ PostgreSQL（暂未实现）

实际应用场景:
  1. 任务状态持久化（重启不丢失）
  2. 任务历史追溯（审计合规）
  3. 分布式任务协调（多 Worker 共享）
  4. 任务数据分析（统计报表）
""")
    print("="*70)


if __name__ == "__main__":
    asyncio.run(main())
