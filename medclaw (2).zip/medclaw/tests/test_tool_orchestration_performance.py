"""
MedClaw 工具编排性能测试
测试缓存命中率、并行执行性能、系统稳定性
"""

import asyncio
import time
import pytest
import sys
from pathlib import Path
from datetime import datetime

project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from medclaw.core.mcp_client import MCPClient
from medclaw.core.tool_orchestrator import ToolOrchestrator


class TestToolOrchestrationPerformance:
    """工具编排性能测试套件"""

    @pytest.fixture
    async def orchestrator(self):
        """创建工具编排器实例"""
        client = MCPClient()

        def slow_handler(input: str):
            time.sleep(0.05)
            return {"result": f"处理: {input}", "timestamp": datetime.now().isoformat()}

        client.register_tool(
            name="slow_task",
            description="慢速任务",
            input_schema={
                "type": "object",
                "properties": {
                    "input": {"type": "string"}
                },
                "required": ["input"]
            },
            handler=slow_handler
        )

        def fast_handler(input: str):
            return {"result": f"快速处理: {input}", "timestamp": datetime.now().isoformat()}

        for i in range(10):
            async def task_handler(value: int, idx: int = i):
                await asyncio.sleep(0.2)
                return {"task_id": idx, "result": value * 2}
            
            client.register_tool(
                name=f"task_{i}",
                description=f"任务 {i}",
                input_schema={
                    "type": "object",
                    "properties": {
                        "value": {"type": "integer"}
                    }
                },
                handler=task_handler
            )

        await client.initialize()

        orchestrator = ToolOrchestrator(
            mcp_client=client,
            cache_enabled=True,
            permission_enabled=False,
            audit_enabled=False,
            cache_config={"type": "memory", "max_size": 100, "ttl": 60}
        )
        await orchestrator.initialize()

        yield orchestrator

        await orchestrator.cleanup()

    @pytest.mark.asyncio
    async def test_cache_hit_rate(self, orchestrator):
        """
        缓存命中率测试
        验证：多次重复调用同一工具，缓存命中率 > 80%
        """
        test_input = "test_data"
        repeat_count = 20

        for i in range(repeat_count):
            await orchestrator.execute("slow_task", {"input": test_input})

        stats = orchestrator.get_stats()
        total_calls = stats["total_calls"]
        cache_hits = stats["cache_hits"]

        hit_rate = (cache_hits / total_calls * 100) if total_calls > 0 else 0

        print(f"\n缓存命中率测试结果:")
        print(f"  总调用次数: {total_calls}")
        print(f"  缓存命中次数: {cache_hits}")
        print(f"  缓存命中率: {hit_rate:.2f}%")

        assert hit_rate > 80, f"缓存命中率 {hit_rate:.2f}% 未达到 80% 要求"

    @pytest.mark.asyncio
    async def test_parallel_vs_sequential(self, orchestrator):
        """
        并行执行性能测试
        验证：并行执行比顺序执行快 50%+
        """
        tool_calls = [
            (f"task_{i}", {"value": i}) for i in range(8)
        ]

        await orchestrator.clear_cache()

        start_time = time.time()
        for tool_name, params in tool_calls:
            await orchestrator.execute(tool_name, params, bypass_cache=True)
        sequential_time = time.time() - start_time

        await orchestrator.clear_cache()
        await asyncio.sleep(0.1)

        start_time = time.time()
        parallel_results = await orchestrator.execute_parallel(tool_calls)
        parallel_time = time.time() - start_time

        speedup_ratio = (sequential_time - parallel_time) / sequential_time * 100 if sequential_time > 0 else 0

        print(f"\n并行执行性能测试结果:")
        print(f"  顺序执行时间: {sequential_time:.3f} 秒")
        print(f"  并行执行时间: {parallel_time:.3f} 秒")
        print(f"  性能提升: {speedup_ratio:.1f}%")
        print(f"  并行结果数: {len(parallel_results)}")

        assert speedup_ratio > 50, f"并行执行性能提升 {speedup_ratio:.1f}% 未达到 50% 要求"

    @pytest.mark.asyncio
    async def test_parallel_execution_correctness(self, orchestrator):
        """
        并行执行正确性测试
        验证：并行执行结果与顺序执行结果一致
        """
        tool_calls = [
            (f"task_{i}", {"value": i}) for i in range(5)
        ]

        sequential_results = []
        for tool_name, params in tool_calls:
            result = await orchestrator.execute(tool_name, params)
            sequential_results.append(result)

        await orchestrator.clear_cache()

        parallel_results = await orchestrator.execute_parallel(tool_calls)

        print(f"\n并行执行正确性测试结果:")
        print(f"  顺序执行结果: {sequential_results}")
        print(f"  并行执行结果: {parallel_results}")

        assert len(sequential_results) == len(parallel_results), "结果数量不一致"

        for seq_res, par_res in zip(sequential_results, parallel_results):
            assert seq_res["task_id"] == par_res["task_id"], "任务ID不匹配"
            assert seq_res["result"] == par_res["result"], "任务结果不匹配"

    @pytest.mark.asyncio
    async def test_stress_concurrent_calls(self, orchestrator):
        """
        压力测试：并发调用多个工具
        验证：系统在高并发下保持稳定
        """
        concurrent_count = 50
        tasks = []

        for i in range(concurrent_count):
            tool_name = f"task_{i % 10}"
            params = {"value": i}
            tasks.append(orchestrator.execute(tool_name, params))

        start_time = time.time()
        results = await asyncio.gather(*tasks, return_exceptions=True)
        elapsed_time = time.time() - start_time

        success_count = sum(1 for r in results if not isinstance(r, Exception))
        error_count = sum(1 for r in results if isinstance(r, Exception))

        print(f"\n压力测试结果:")
        print(f"  并发请求数: {concurrent_count}")
        print(f"  成功数: {success_count}")
        print(f"  失败数: {error_count}")
        print(f"  总耗时: {elapsed_time:.3f} 秒")
        print(f"  平均响应时间: {elapsed_time/concurrent_count*1000:.2f} ms")

        assert success_count >= concurrent_count * 0.95, f"成功率 {success_count/concurrent_count*100:.1f}% 低于 95%"

    @pytest.mark.asyncio
    async def test_cache_stress(self, orchestrator):
        """
        缓存压力测试
        验证：大量不同参数的缓存操作
        """
        test_inputs = [f"data_{i % 10}" for i in range(100)]

        for input_val in test_inputs:
            await orchestrator.execute("slow_task", {"input": input_val})

        stats = orchestrator.get_stats()
        total_calls = stats["total_calls"]
        cache_hits = stats["cache_hits"]

        hit_rate = (cache_hits / total_calls * 100) if total_calls > 0 else 0

        print(f"\n缓存压力测试结果:")
        print(f"  测试输入数: {len(test_inputs)}")
        print(f"  总调用次数: {total_calls}")
        print(f"  缓存命中次数: {cache_hits}")
        print(f"  缓存命中率: {hit_rate:.2f}%")

        assert hit_rate > 80, f"缓存命中率 {hit_rate:.2f}% 未达到 80% 要求"

    @pytest.mark.asyncio
    async def test_burst_traffic(self, orchestrator):
        """
        突发流量测试
        验证：短时间内大量请求系统仍能正常响应
        """
        burst_size = 30

        async def burst_request(idx: int):
            tool_name = f"task_{idx % 10}"
            return await orchestrator.execute(tool_name, {"value": idx})

        start_time = time.time()
        results = await asyncio.gather(*[burst_request(i) for i in range(burst_size)], return_exceptions=True)
        elapsed_time = time.time() - start_time

        success_count = sum(1 for r in results if not isinstance(r, Exception))

        print(f"\n突发流量测试结果:")
        print(f"  突发请求数: {burst_size}")
        print(f"  成功数: {success_count}")
        print(f"  总耗时: {elapsed_time:.3f} 秒")
        print(f"  QPS: {burst_size/elapsed_time:.2f}")

        assert success_count == burst_size, "突发流量测试有失败请求"


class TestPerformanceBenchmarks:
    """性能基准测试"""

    @pytest.fixture
    async def simple_orchestrator(self):
        """创建简单工具编排器"""
        client = MCPClient()

        def compute_task(value: int):
            result = sum(i * i for i in range(value * 100))
            return {"result": result, "input": value}

        client.register_tool(
            name="compute",
            description="计算任务",
            input_schema={
                "type": "object",
                "properties": {
                    "value": {"type": "integer"}
                }
            },
            handler=compute_task
        )

        await client.initialize()

        orchestrator = ToolOrchestrator(
            mcp_client=client,
            cache_enabled=True,
            permission_enabled=False,
            audit_enabled=False
        )
        await orchestrator.initialize()

        yield orchestrator

        await orchestrator.cleanup()

    @pytest.mark.asyncio
    async def test_cache_response_time(self, simple_orchestrator):
        """
        缓存响应时间测试
        验证：缓存命中时响应时间显著减少
        """
        params = {"value": 1000}

        start_time = time.time()
        await simple_orchestrator.execute("compute", params)
        first_call_time = time.time() - start_time

        start_time = time.time()
        await simple_orchestrator.execute("compute", params)
        cached_call_time = time.time() - start_time

        if first_call_time > 0 and cached_call_time > 0:
            time_reduction = (1 - cached_call_time / first_call_time) * 100
        else:
            time_reduction = 0

        print(f"\n缓存响应时间测试结果:")
        print(f"  首次调用时间: {first_call_time*1000:.2f} ms")
        print(f"  缓存调用时间: {cached_call_time*1000:.2f} ms")
        print(f"  时间减少: {time_reduction:.1f}%")

        assert cached_call_time < first_call_time * 0.5 or time_reduction > 30, "缓存响应时间未达到预期优化"

    @pytest.mark.asyncio
    async def test_high_concurrency_stability(self):
        """
        高并发稳定性测试
        验证：100 并发下系统稳定
        """
        client = MCPClient()

        def simple_handler(id: int):
            return {"success": True, "data": id}

        client.register_tool(
            name="simple",
            description="简单任务",
            input_schema={
                "type": "object",
                "properties": {
                    "id": {"type": "integer"}
                }
            },
            handler=simple_handler
        )

        await client.initialize()

        orchestrator = ToolOrchestrator(
            mcp_client=client,
            cache_enabled=False,
            permission_enabled=False,
            audit_enabled=False
        )
        await orchestrator.initialize()

        concurrency = 100
        iterations = 5

        for iteration in range(iterations):
            tasks = [orchestrator.execute("simple", {"id": i}) for i in range(concurrency)]
            results = await asyncio.gather(*tasks, return_exceptions=True)

            success = sum(1 for r in results if not isinstance(r, Exception))
            assert success == concurrency, f"迭代 {iteration+1} 失败"

        await orchestrator.cleanup()

        print(f"\n高并发稳定性测试结果:")
        print(f"  并发数: {concurrency}")
        print(f"  迭代次数: {iterations}")
        print(f"  总请求数: {concurrency * iterations}")
        print(f"  全部成功 ✓")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])
