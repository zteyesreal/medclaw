"""
Mock 任务执行器 - 用于测试 MedClaw 功能
模拟真实的医疗操作
"""

import asyncio
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from medclaw.task_framework import Task, PROFESSION_TASK_TEMPLATES
from mock_data import (
    MOCK_PATIENTS, MOCK_LAB_RESULTS, MOCK_IMAGING_RESULTS,
    MOCK_MEDICAL_RECORDS, MOCK_ORDERS, MOCK_INSURANCE_DATA,
    MOCK_DRUGS, MOCK_QC_RULES, MOCK_RESEARCH_DATA,
    MOCK_NURSING_ASSESSMENT, MOCK_REHAB_ASSESSMENT
)


class MockTaskExecutor:
    """模拟任务执行器 - 用于测试"""
    
    def __init__(self):
        self.action_handlers = {
            # 临床医生操作
            "get_patient_info": self._mock_get_patient,
            "collect_chief_complaint": self._mock_collect_complaint,
            "analyze_present_illness": self._mock_analyze_illness,
            "review_past_history": self._mock_review_history,
            "perform_physical_exam": self._mock_physical_exam,
            "order_labs": self._mock_order_labs,
            "make_diagnosis": self._mock_make_diagnosis,
            "create_treatment_plan": self._mock_treatment_plan,
            "generate_medical_record": self._mock_generate_record,
            
            # 病历质控操作
            "get_ward_patients": self._mock_get_ward_patients,
            "check_completeness": self._mock_check_completeness,
            "check_rationality": self._mock_check_rationality,
            "check_icd10": self._mock_check_icd10,
            "generate_qc_report": self._mock_generate_qc_report,
            
            # 医保审核操作
            "review_drg_grouping": self._mock_review_drg,
            "check_fee_compliance": self._mock_check_fee,
            "identify_violations": self._mock_identify_violations,
            "generate_audit_report": self._mock_generate_audit_report,
            
            # 放射科操作
            "analyze_ct_images": self._mock_analyze_ct,
            "detect_lesions": self._mock_detect_lesions,
            "generate_radiology_report": self._mock_generate_radiology_report,
            "emergency_consultation": self._mock_emergency_consult,
            
            # 临床药师操作
            "review_prescription": self._mock_review_prescription,
            "check_drug_interactions": self._mock_check_interactions,
            "verify_dosage": self._mock_verify_dosage,
            "review_antibiotics": self._mock_review_antibiotics,
            
            # 科研人员操作
            "extract_clinical_data": self._mock_extract_data,
            "perform_statistical_analysis": self._mock_statistical_analysis,
            "generate_charts": self._mock_generate_charts,
            "export_results": self._mock_export_results,
            
            # 护士操作
            "admission_assessment": self._mock_admission_assessment,
            "execute_doctor_orders": self._mock_execute_orders,
            "monitor_vital_signs": self._mock_monitor_vitals,
            "patient_education": self._mock_patient_education,
            
            # 急诊科操作
            "primary_survey": self._mock_primary_survey,
            "assess_vital_signs": self._mock_assess_vitals,
            "collect_chief_complaint": self._mock_collect_complaint,
            "triage_level_assessment": self._mock_triage_assessment,
            "assign_treatment_area": self._mock_assign_area,
            "notify_team": self._mock_notify_team,
            "initiate_monitoring": self._mock_initiate_monitoring,
            "assess_responsiveness": self._mock_assess_responsiveness,
            "call_for_help": self._mock_call_for_help,
            "check_pulse": self._mock_check_pulse,
            "start_chest_compressions": self._mock_start_cpr,
            "manage_airway": self._mock_manage_airway,
            "provide_ventilation": self._mock_provide_ventilation,
            "attach_defibrillator": self._mock_attach_defibrillator,
            "administer_emergency_drugs": self._mock_administer_drugs,
            "document_resuscitation": self._mock_document_resuscitation,
            "primary_survey_abcd": self._mock_primary_survey_abcd,
            "control_hemorrhage": self._mock_control_hemorrhage,
            "assess_neurological_status": self._mock_assess_neuro,
            "expose_and_examine": self._mock_expose_examine,
            "secondary_survey": self._mock_secondary_survey,
            "order_emergency_imaging": self._mock_order_emergency_imaging,
            "consult_surgery": self._mock_consult_surgery,
            "prepare_for_transfer": self._mock_prepare_transfer,
            
            # 康复科操作
            "collect_medical_history": self._mock_collect_medical_history,
            "assess_motor_function": self._mock_assess_motor,
            "evaluate_adl": self._mock_evaluate_adl,
            "assess_cognitive_function": self._mock_assess_cognitive,
            "evaluate_speech_language": self._mock_evaluate_speech,
            "assess_swallowing": self._mock_assess_swallowing,
            "generate_rehab_diagnosis": self._mock_generate_rehab_diagnosis,
            "create_rehab_plan": self._mock_create_rehab_plan,
            "implement_exercise_therapy": self._mock_exercise_therapy,
            "implement_occupational_therapy": self._mock_occupational_therapy,
            
            # 通用操作
            "report_result": self._mock_report_result,
        }
        self.execution_log = []
    
    # ========== 临床医生操作 ==========
    
    def _mock_get_patient(self, patient_id):
        """模拟获取患者信息"""
        patient = next((p for p in MOCK_PATIENTS if p["patient_id"] == patient_id), None)
        if patient:
            print(f"  ✅ 获取患者信息: {patient['name']}, {patient['age']}岁, {patient['gender']}")
            return patient
        return {"error": "患者不存在"}
    
    def _mock_collect_complaint(self, **kwargs):
        """模拟收集主诉"""
        print(f"  ✅ 收集主诉: 胸痛2小时")
        return {"chief_complaint": "胸痛2小时", "present_illness": "患者2小时前出现胸痛..."}
    
    def _mock_analyze_illness(self, **kwargs):
        """模拟分析现病史"""
        print(f"  ✅ 分析现病史: 起病急，症状典型")
        return {"analysis": "急性起病，胸痛位于胸骨后，呈压榨性"}
    
    def _mock_review_history(self, **kwargs):
        """模拟回顾既往史"""
        print(f"  ✅ 回顾既往史: 高血压5年，糖尿病3年")
        return {"past_history": ["高血压5年", "糖尿病3年"], "allergies": ["青霉素过敏"]}
    
    def _mock_physical_exam(self, **kwargs):
        """模拟体格检查"""
        vitals = {"bp": "140/90", "hr": 88, "rr": 20, "temp": 36.5}
        print(f"  ✅ 体格检查: BP {vitals['bp']}, HR {vitals['hr']}")
        return {"vitals": vitals, "physical_exam": "心肺听诊未见明显异常"}
    
    def _mock_order_labs(self, urgency="routine"):
        """模拟开检验单"""
        print(f"  ✅ 开具{urgency}检验单: 血常规、心肌酶、生化")
        return {"order_id": f"LAB_{datetime.now().strftime('%Y%m%d%H%M%S')}", "items": ["血常规", "心肌酶", "生化"]}
    
    def _mock_make_diagnosis(self, use_icd10=True):
        """模拟诊断"""
        diagnosis = "急性心肌梗死"
        icd10 = "I21.9"
        print(f"  ✅ 生成诊断: {diagnosis} (ICD-10: {icd10})")
        return {"diagnosis": diagnosis, "icd10": icd10 if use_icd10 else None}
    
    def _mock_treatment_plan(self, **kwargs):
        """模拟治疗方案"""
        print(f"  ✅ 制定治疗方案: 抗血小板、抗凝、调脂")
        return {"treatment": ["阿司匹林", "氯吡格雷", "阿托伐他汀"], "plan": "药物治疗+介入治疗"}
    
    def _mock_generate_record(self, template="outpatient"):
        """模拟生成病历"""
        print(f"  ✅ 生成{template}病历")
        return {"record_id": f"MR_{datetime.now().strftime('%Y%m%d%H%M%S')}", "template": template}
    
    # ========== 病历质控操作 ==========
    
    def _mock_get_ward_patients(self, ward, date="today"):
        """模拟获取病区患者"""
        patients = [p for p in MOCK_PATIENTS if p.get("ward") == ward]
        print(f"  ✅ 获取{ward}病区患者: {len(patients)}人")
        return {"ward": ward, "patients": patients, "count": len(patients)}
    
    def _mock_check_completeness(self, checklist):
        """模拟检查完整性"""
        print(f"  ✅ 检查病历完整性: {len(checklist)}项")
        return {"checked_items": checklist, "missing_items": [], "score": 95}
    
    def _mock_check_rationality(self, rules):
        """模拟检查合理性"""
        print(f"  ✅ 检查诊疗合理性: {len(rules)}项")
        return {"checked_rules": rules, "violations": [], "score": 92}
    
    def _mock_check_icd10(self, version="ICD-10-2019"):
        """模拟检查 ICD-10 编码"""
        print(f"  ✅ 检查ICD-10编码: 版本{version}")
        return {"version": version, "errors": [], "score": 98}
    
    def _mock_generate_qc_report(self, format="pdf"):
        """模拟生成质控报告"""
        print(f"  ✅ 生成{format}质控报告")
        return {"report_id": f"QC_{datetime.now().strftime('%Y%m%d%H%M%S')}", "format": format}
    
    # ========== 医保审核操作 ==========
    
    def _mock_review_drg(self, **kwargs):
        """模拟审核 DRG 分组"""
        print(f"  ✅ 审核DRG分组: I21.9 急性心肌梗死")
        return {"drg_group": "I21.9", "weight": 1.5, "payment": 20000}
    
    def _mock_check_fee(self, **kwargs):
        """模拟检查费用合规性"""
        print(f"  ✅ 检查费用合规性: 总费用25000，医保报销20000")
        return {"total_cost": 25000, "coverage": 20000, "self_pay": 5000, "violations": []}
    
    def _mock_identify_violations(self, **kwargs):
        """模拟识别违规行为"""
        print(f"  ✅ 识别违规行为: 未发现违规")
        return {"violations": [], "risk_level": "low"}
    
    def _mock_generate_audit_report(self, **kwargs):
        """模拟生成审核报告"""
        print(f"  ✅ 生成医保审核报告")
        return {"report_id": f"AUDIT_{datetime.now().strftime('%Y%m%d%H%M%S')}"}
    
    # ========== 放射科操作 ==========
    
    def _mock_analyze_ct(self, **kwargs):
        """模拟分析 CT 影像"""
        print(f"  ✅ 分析CT影像: 心影增大，肺纹理增粗")
        return {"findings": "心影增大，肺纹理增粗", "impression": "高血压性心脏病"}
    
    def _mock_detect_lesions(self, **kwargs):
        """模拟检测病灶"""
        print(f"  ✅ 检测病灶: 未发现明显病灶")
        return {"lesions": [], "confidence": 0.95}
    
    def _mock_generate_radiology_report(self, **kwargs):
        """模拟生成影像报告"""
        print(f"  ✅ 生成影像报告")
        return {"report_id": f"RAD_{datetime.now().strftime('%Y%m%d%H%M%S')}"}
    
    def _mock_emergency_consult(self, **kwargs):
        """模拟急诊影像会诊"""
        print(f"  ✅ 急诊影像会诊: 30分钟内完成")
        return {"consultation_time": "30分钟", "findings": "紧急发现"}
    
    # ========== 临床药师操作 ==========
    
    def _mock_review_prescription(self, **kwargs):
        """模拟审核处方"""
        print(f"  ✅ 审核处方: 阿司匹林、阿托伐他汀")
        return {"approved": True, "issues": []}
    
    def _mock_check_interactions(self, **kwargs):
        """模拟检查药物相互作用"""
        print(f"  ✅ 检查药物相互作用: 未发现明显相互作用")
        return {"interactions": [], "severity": "none"}
    
    def _mock_verify_dosage(self, **kwargs):
        """模拟验证剂量"""
        print(f"  ✅ 验证剂量: 阿司匹林100mg qd - 正确")
        return {"dosage_correct": True, "recommendations": []}
    
    def _mock_review_antibiotics(self, **kwargs):
        """模拟点评抗菌药物"""
        print(f"  ✅ 点评抗菌药物: 头孢呋辛使用合理")
        return {"appropriateness": "合理", "score": 95}
    
    # ========== 科研人员操作 ==========
    
    def _mock_extract_data(self, **kwargs):
        """模拟提取临床数据"""
        print(f"  ✅ 提取临床数据: 2例患者")
        return {"extracted_records": 2, "variables": ["age", "gender", "bp"]}
    
    def _mock_statistical_analysis(self, **kwargs):
        """模拟统计分析"""
        print(f"  ✅ 统计分析: 描述性统计完成")
        return {"mean_age": 56.5, "male_ratio": 1.0}
    
    def _mock_generate_charts(self, **kwargs):
        """模拟生成图表"""
        print(f"  ✅ 生成图表: 柱状图、折线图")
        return {"charts": ["bar_chart.png", "line_chart.png"]}
    
    def _mock_export_results(self, **kwargs):
        """模拟导出结果"""
        print(f"  ✅ 导出结果: Excel格式")
        return {"file": "research_results.xlsx"}
    
    # ========== 护士操作 ==========
    
    def _mock_admission_assessment(self, **kwargs):
        """模拟入院评估"""
        print(f"  ✅ 入院评估: ADL评分85分")
        return {"adl_score": 85, "fall_risk": "中", "nutrition": "良好"}
    
    def _mock_execute_orders(self, **kwargs):
        """模拟执行医嘱"""
        print(f"  ✅ 执行医嘱: 3条医嘱")
        return {"executed_orders": 3, "pending_orders": 0}
    
    def _mock_monitor_vitals(self, **kwargs):
        """模拟监测生命体征"""
        print(f"  ✅ 监测生命体征: BP 140/90, HR 88")
        return {"vitals": {"bp": "140/90", "hr": 88}, "frequency": "q4h"}
    
    def _mock_patient_education(self, **kwargs):
        """模拟患者教育"""
        print(f"  ✅ 患者教育: 用药指导、饮食指导")
        return {"education_topics": ["用药", "饮食"], "understanding": "良好"}
    
    # ========== 急诊科操作 ==========
    
    def _mock_primary_survey(self, protocol="ABCDE"):
        """模拟初级评估"""
        print(f"  ✅ 初级评估 ({protocol}): 气道通畅，呼吸正常")
        return {"airway": "通畅", "breathing": "正常", "circulation": "稳定"}
    
    def _mock_assess_vitals(self, **kwargs):
        """模拟评估生命体征"""
        print(f"  ✅ 评估生命体征: BP 140/90, HR 88")
        return {"vitals": {"bp": "140/90", "hr": 88}, "stability": "稳定"}
    
    def _mock_triage_assessment(self, **kwargs):
        """模拟分诊评估"""
        print(f"  ✅ 分诊评估: 二级（危重）")
        return {"triage_level": "二级", "priority": "危重", "wait_time": "立即"}
    
    def _mock_assign_area(self, **kwargs):
        """模拟分配治疗区域"""
        print(f"  ✅ 分配治疗区域: 抢救室")
        return {"area": "抢救室", "bed": "抢救床1"}
    
    def _mock_notify_team(self, **kwargs):
        """模拟通知团队"""
        print(f"  ✅ 通知团队: 心内科会诊医师")
        return {"notified": ["心内科", "ICU"], "response_time": "5分钟"}
    
    def _mock_initiate_monitoring(self, **kwargs):
        """模拟启动监测"""
        print(f"  ✅ 启动监测: 心电监护、血氧监测")
        return {"monitors": ["心电", "血氧"], "frequency": "continuous"}
    
    def _mock_assess_responsiveness(self, **kwargs):
        """模拟评估反应性"""
        print(f"  ✅ 评估反应性: 患者无反应")
        return {"responsive": False, "gcs": 3}
    
    def _mock_call_for_help(self, **kwargs):
        """模拟呼叫帮助"""
        print(f"  ✅ 呼叫帮助: 启动急救团队")
        return {"team": "急救团队", "eta": "2分钟"}
    
    def _mock_check_pulse(self, **kwargs):
        """模拟检查脉搏"""
        print(f"  ✅ 检查脉搏: 颈动脉搏动消失")
        return {"pulse_present": False, "location": "颈动脉"}
    
    def _mock_start_cpr(self, rate="100-120次/分", depth="5-6cm", ratio="30:2"):
        """模拟开始心肺复苏"""
        print(f"  ✅ 开始CPR: 频率{rate}, 深度{depth}")
        return {"cpr_started": True, "compressions": 30, "ventilations": 2}
    
    def _mock_manage_airway(self, **kwargs):
        """模拟气道管理"""
        print(f"  ✅ 气道管理: 开放气道，准备插管")
        return {"airway_open": True, "device": "气管插管"}
    
    def _mock_provide_ventilation(self, **kwargs):
        """模拟提供通气"""
        print(f"  ✅ 提供通气: 球囊面罩通气")
        return {"ventilation": "球囊面罩", "rate": "10-12次/分"}
    
    def _mock_attach_defibrillator(self, **kwargs):
        """模拟连接除颤器"""
        print(f"  ✅ 连接除颤器: 准备除颤")
        return {"defibrillator_attached": True, "rhythm": "室颤"}
    
    def _mock_administer_drugs(self, drug, dose, interval):
        """模拟给药"""
        print(f"  ✅ 给药: {drug} {dose} (每{interval})")
        return {"drug": drug, "dose": dose, "route": "静脉"}
    
    def _mock_document_resuscitation(self, **kwargs):
        """模拟记录复苏过程"""
        print(f"  ✅ 记录复苏过程")
        return {"record_id": f"CPR_{datetime.now().strftime('%Y%m%d%H%M%S')}"}
    
    def _mock_primary_survey_abcd(self, **kwargs):
        """模拟创伤初级评估"""
        print(f"  ✅ 创伤初级评估 (ABCD)")
        return {"airway": "通畅", "breathing": "正常", "circulation": "出血控制", "disability": "GCS 15"}
    
    def _mock_control_hemorrhage(self, **kwargs):
        """模拟控制出血"""
        print(f"  ✅ 控制出血: 加压包扎")
        return {"hemorrhage_controlled": True, "method": "加压包扎"}
    
    def _mock_assess_neuro(self, **kwargs):
        """模拟神经系统评估"""
        print(f"  ✅ 神经系统评估: GCS 15分")
        return {"gcs": 15, "pupils": "等大等圆"}
    
    def _mock_expose_examine(self, **kwargs):
        """模拟暴露检查"""
        print(f"  ✅ 暴露检查: 全身检查完成")
        return {"injuries": ["左前臂擦伤"], "fractures": []}
    
    def _mock_secondary_survey(self, **kwargs):
        """模拟二次评估"""
        print(f"  ✅ 二次评估: 从头到脚评估")
        return {"complete": True, "findings": []}
    
    def _mock_order_emergency_imaging(self, **kwargs):
        """模拟开具急诊影像"""
        print(f"  ✅ 开具急诊影像: CT头部、胸部X光")
        return {"orders": ["CT头部", "胸部X光"], "priority": "紧急"}
    
    def _mock_consult_surgery(self, **kwargs):
        """模拟会诊外科"""
        print(f"  ✅ 会诊外科: 创伤外科会诊")
        return {"consultation": "创伤外科", "response_time": "10分钟"}
    
    def _mock_prepare_transfer(self, **kwargs):
        """模拟准备转运"""
        print(f"  ✅ 准备转运: ICU")
        return {"destination": "ICU", "transport_ready": True}
    
    # ========== 康复科操作 ==========
    
    def _mock_collect_medical_history(self, **kwargs):
        """模拟收集病史"""
        print(f"  ✅ 收集病史: 脑卒中后3个月")
        return {"history": "脑卒中", "duration": "3个月"}
    
    def _mock_assess_motor(self, **kwargs):
        """模拟评估运动功能"""
        print(f"  ✅ 评估运动功能: 上肢4级，下肢4级")
        return {"upper_limb": 4, "lower_limb": 4, "total": 8}
    
    def _mock_evaluate_adl(self, **kwargs):
        """模拟评估 ADL"""
        print(f"  ✅ 评估ADL: 85分")
        return {"adl_score": 85, "independence": "轻度依赖"}
    
    def _mock_assess_cognitive(self, **kwargs):
        """模拟评估认知功能"""
        print(f"  ✅ 评估认知功能: 正常")
        return {"cognitive": "正常", "mmse": 28}
    
    def _mock_evaluate_speech(self, **kwargs):
        """模拟评估言语"""
        print(f"  ✅ 评估言语: 轻度构音障碍")
        return {"speech": "轻度构音障碍", "comprehension": "正常"}
    
    def _mock_assess_swallowing(self, **kwargs):
        """模拟评估吞咽"""
        print(f"  ✅ 评估吞咽: 洼田饮水试验2级")
        return {"swallowing": "轻度障碍", "test": "洼田2级"}
    
    def _mock_generate_rehab_diagnosis(self, **kwargs):
        """模拟生成康复诊断"""
        print(f"  ✅ 生成康复诊断: 脑卒中后偏瘫")
        return {"diagnosis": "脑卒中后偏瘫", "severity": "中度"}
    
    def _mock_create_rehab_plan(self, **kwargs):
        """模拟制定康复计划"""
        print(f"  ✅ 制定康复计划: 运动疗法+作业疗法")
        return {"plan": ["运动疗法", "作业疗法", "言语训练"], "duration": "3个月"}
    
    def _mock_exercise_therapy(self, **kwargs):
        """模拟实施运动疗法"""
        print(f"  ✅ 实施运动疗法: 肢体功能训练")
        return {"therapy": "运动疗法", "exercises": ["肢体功能训练", "平衡训练"]}
    
    def _mock_occupational_therapy(self, **kwargs):
        """模拟实施作业疗法"""
        print(f"  ✅ 实施作业疗法: ADL训练")
        return {"therapy": "作业疗法", "activities": ["ADL训练", "辅助器具适配"]}
    
    # ========== 通用操作 ==========
    
    def _mock_report_result(self, message=""):
        """模拟报告结果"""
        print(f"  ✅ 报告结果: {message}")
        return {"message": message, "timestamp": datetime.now().isoformat()}
    
    # ========== 主执行方法 ==========
    
    async def execute_task(self, task: Task):
        """执行任务"""
        print(f"\n{'='*70}")
        print(f"执行任务: {task.name}")
        print(f"职业: {task.profession}")
        print(f"目标: {task.goal}")
        print(f"{'='*70}")
        
        results = []
        start_time = datetime.now()
        
        for i, step in enumerate(task.steps):
            action = step.get("action")
            params = step.get("params", {})
            
            print(f"\n步骤 {i+1}/{len(task.steps)}: {action}")
            
            handler = self.action_handlers.get(action)
            if handler:
                try:
                    if asyncio.iscoroutinefunction(handler):
                        result = await handler(**params)
                    else:
                        result = handler(**params)
                    
                    results.append({
                        "step": i,
                        "action": action,
                        "result": result,
                        "status": "success",
                        "timestamp": datetime.now().isoformat()
                    })
                    print(f"  ✅ 完成")
                    
                except Exception as e:
                    print(f"  ❌ 失败: {e}")
                    results.append({
                        "step": i,
                        "action": action,
                        "error": str(e),
                        "status": "failed",
                        "timestamp": datetime.now().isoformat()
                    })
            else:
                print(f"  ⚠️ 未知操作: {action}")
                results.append({
                    "step": i,
                    "action": action,
                    "status": "skipped",
                    "timestamp": datetime.now().isoformat()
                })
            
            # 步骤间短暂等待（模拟真实执行）
            await asyncio.sleep(0.1)
        
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds()
        
        success_count = sum(1 for r in results if r.get("status") == "success")
        
        print(f"\n{'='*70}")
        print("执行结果:")
        print(f"  任务状态: completed")
        print(f"  总步骤: {len(task.steps)}")
        print(f"  成功: {success_count}")
        print(f"  失败: {len(results) - success_count}")
        print(f"  执行时间: {duration:.2f}秒")
        print(f"{'='*70}")
        
        return {
            "task_id": task.id,
            "task_name": task.name,
            "profession": task.profession,
            "status": "completed",
            "total_steps": len(task.steps),
            "success_steps": success_count,
            "failed_steps": len(results) - success_count,
            "duration": duration,
            "results": results,
            "completed_at": datetime.now().isoformat()
        }


# 全局实例
mock_executor = MockTaskExecutor()


def get_mock_executor():
    """获取 Mock 执行器实例"""
    return mock_executor


if __name__ == "__main__":
    # 测试执行器
    print("Mock 执行器加载完成")
    print(f"可用操作: {len(mock_executor.action_handlers)} 个")
