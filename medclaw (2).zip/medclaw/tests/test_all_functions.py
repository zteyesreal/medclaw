"""
MedClaw 完整功能测试套件
测试所有 9 个医疗职业的任务模板和动态调整功能
"""

import asyncio
import sys
import json
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any

sys.path.insert(0, str(Path(__file__).parent.parent))

from medclaw.task_framework import Task, PROFESSION_TASK_TEMPLATES
from mock_executor import MockTaskExecutor


class TestResult:
    """测试结果类"""
    def __init__(self, test_name: str, status: str = "pending", 
                 message: str = "", duration: float = 0.0, details: Dict = None):
        self.test_name = test_name
        self.status = status  # passed, failed, pending
        self.message = message
        self.duration = duration
        self.details = details or {}
        self.timestamp = datetime.now().isoformat()
    
    def to_dict(self) -> Dict:
        return {
            "test_name": self.test_name,
            "status": self.status,
            "message": self.message,
            "duration": self.duration,
            "timestamp": self.timestamp,
            "details": self.details
        }


class MedClawTestSuite:
    """MedClaw 测试套件"""
    
    def __init__(self):
        self.executor = MockTaskExecutor()
        self.results: List[TestResult] = []
        self.start_time = None
        self.end_time = None
    
    async def run_all_tests(self):
        """运行所有测试"""
        self.start_time = datetime.now()
        
        print("=" * 80)
        print(" " * 25 + "MedClaw 完整功能测试")
        print("=" * 80)
        
        # 测试 1: 职业模板加载
        await self.test_profession_templates_loading()
        
        # 测试 2-10: 各个职业的任务执行
        await self.test_clinician_tasks()
        await self.test_quality_controller_tasks()
        await self.test_insurance_auditor_tasks()
        await self.test_radiologist_tasks()
        await self.test_clinical_pharmacist_tasks()
        await self.test_researcher_tasks()
        await self.test_nurse_tasks()
        await self.test_emergency_physician_tasks()
        await self.test_rehabilitation_physician_tasks()
        
        # 测试 11-13: 动态调整功能
        await self.test_skip_step()
        await self.test_insert_step()
        await self.test_modify_step()
        
        self.end_time = datetime.now()
        
        # 生成报告
        self.generate_report()
    
    async def test_profession_templates_loading(self):
        """测试 1: 职业模板加载"""
        test_name = "职业模板加载测试"
        start = datetime.now()
        
        try:
            print(f"\n{'='*80}")
            print(f"测试: {test_name}")
            print(f"{'='*80}")
            
            professions = list(PROFESSION_TASK_TEMPLATES.keys())
            print(f"发现 {len(professions)} 个职业:")
            
            total_templates = 0
            for profession in professions:
                templates = PROFESSION_TASK_TEMPLATES[profession]
                print(f"  ✅ {profession}: {len(templates)} 个模板")
                total_templates += len(templates)
            
            duration = (datetime.now() - start).total_seconds()
            
            result = TestResult(
                test_name=test_name,
                status="passed",
                message=f"成功加载 {len(professions)} 个职业，共 {total_templates} 个模板",
                duration=duration,
                details={"professions": professions, "total_templates": total_templates}
            )
            self.results.append(result)
            print(f"✅ 测试通过 ({duration:.2f}s)")
            
        except Exception as e:
            duration = (datetime.now() - start).total_seconds()
            result = TestResult(
                test_name=test_name,
                status="failed",
                message=str(e),
                duration=duration
            )
            self.results.append(result)
            print(f"❌ 测试失败: {e}")
    
    async def test_clinician_tasks(self):
        """测试 2: 临床医生任务"""
        await self._test_profession_tasks("clinician", "临床医生", {
            "patient_name": "张三",
            "patient_id": "P001"
        })
    
    async def test_quality_controller_tasks(self):
        """测试 3: 病历质控员任务"""
        # 病历质控员需要 department 和 record_count 参数
        # 真实场景：质控员按科室进行运行病历质控
        await self._test_profession_tasks("quality_controller", "病历质控员", {
            "department": "心内科",
            "record_count": 15
        })
    
    async def test_insurance_auditor_tasks(self):
        """测试 4: 医保审核员任务"""
        # 医保审核员需要 month 和 case_count 参数
        # 真实场景：按月审核病例的 DRG 分组
        await self._test_profession_tasks("insurance_auditor", "医保审核员", {
            "month": "2026-03",
            "case_count": 50
        })
    
    async def test_radiologist_tasks(self):
        """测试 5: 放射科医师任务"""
        # 放射科医师需要 body_part、count 和 study_id 参数
        # 真实场景：按部位完成 CT 报告书写
        await self._test_profession_tasks("radiologist", "放射科医师", {
            "body_part": "胸部",
            "count": 10,
            "study_id": "CT20260313001"
        })
    
    async def test_clinical_pharmacist_tasks(self):
        """测试 6: 临床药师任务"""
        # 临床药师需要 department 和 prescription_count 参数
        # 真实场景：按科室审核处方
        await self._test_profession_tasks("clinical_pharmacist", "临床药师", {
            "department": "呼吸科",
            "prescription_count": 30
        })
    
    async def test_researcher_tasks(self):
        """测试 7: 科研人员任务"""
        # 科研人员需要 disease、sample_size 和 date_range 参数
        # 真实场景：按病种提取临床数据
        await self._test_profession_tasks("researcher", "科研人员", {
            "disease": "高血压",
            "sample_size": 100,
            "date_range": "2025-01-01 至 2025-12-31"
        })
    
    async def test_nurse_tasks(self):
        """测试 8: 护士任务"""
        # 护士需要 patient_name 参数
        # 真实场景：完成指定患者的入院护理评估
        await self._test_profession_tasks("nurse", "护士", {
            "patient_name": "张三"
        })
    
    async def test_emergency_physician_tasks(self):
        """测试 9: 急诊科医师任务"""
        await self._test_profession_tasks("emergency_physician", "急诊科医师", {
            "patient_name": "急诊患者"
        })
    
    async def test_rehabilitation_physician_tasks(self):
        """测试 10: 康复科医师任务"""
        await self._test_profession_tasks("rehabilitation_physician", "康复科医师", {
            "patient_name": "康复患者"
        })
    
    async def _test_profession_tasks(self, profession: str, profession_name: str, 
                                     params: Dict[str, Any]):
        """通用职业任务测试"""
        test_name = f"{profession_name}任务测试"
        start = datetime.now()
        
        try:
            print(f"\n{'='*80}")
            print(f"测试: {test_name}")
            print(f"{'='*80}")
            
            templates = PROFESSION_TASK_TEMPLATES.get(profession, [])
            if not templates:
                raise ValueError(f"职业 {profession} 没有任务模板")
            
            # 测试第一个模板
            template = templates[0]
            print(f"测试模板: {template.name}")
            print(f"步骤数: {len(template.default_steps)}")
            
            # 创建任务
            goal = template.goal_template.format(**params)
            task = Task(
                id=f"{template.id}_{datetime.now().strftime('%Y%m%d%H%M%S')}",
                name=template.name,
                profession=profession,
                description=template.description,
                goal=goal,
                steps=template.default_steps.copy()
            )
            
            # 执行任务
            result = await self.executor.execute_task(task)
            
            duration = (datetime.now() - start).total_seconds()
            
            test_result = TestResult(
                test_name=test_name,
                status="passed" if result['status'] == 'completed' else 'failed',
                message=f"执行了 {result['total_steps']} 个步骤，成功 {result['success_steps']} 个",
                duration=duration,
                details={
                    "template_name": template.name,
                    "total_steps": result['total_steps'],
                    "success_steps": result['success_steps'],
                    "failed_steps": result['failed_steps']
                }
            )
            self.results.append(test_result)
            print(f"✅ 测试通过 ({duration:.2f}s)")
            
        except Exception as e:
            duration = (datetime.now() - start).total_seconds()
            result = TestResult(
                test_name=test_name,
                status="failed",
                message=str(e),
                duration=duration
            )
            self.results.append(result)
            print(f"❌ 测试失败: {e}")
    
    async def test_skip_step(self):
        """测试 11: 跳过步骤功能"""
        test_name = "动态调整 - 跳过步骤"
        start = datetime.now()
        
        try:
            print(f"\n{'='*80}")
            print(f"测试: {test_name}")
            print(f"{'='*80}")
            
            # 获取临床医生模板
            template = PROFESSION_TASK_TEMPLATES["clinician"][0]
            task = Task(
                id=f"skip_test_{datetime.now().strftime('%Y%m%d%H%M%S')}",
                name=template.name,
                profession="clinician",
                description=template.description,
                goal="测试跳过步骤",
                steps=template.default_steps.copy()
            )
            
            # 模拟跳过第 3 步
            original_steps = len(task.steps)
            task.steps[2]['skipped'] = True
            
            print(f"原始步骤数: {original_steps}")
            print(f"跳过步骤: 第 3 步")
            
            # 执行（跳过标记的步骤）
            executed_steps = 0
            for i, step in enumerate(task.steps):
                if not step.get('skipped', False):
                    executed_steps += 1
            
            duration = (datetime.now() - start).total_seconds()
            
            result = TestResult(
                test_name=test_name,
                status="passed",
                message=f"成功跳过步骤，实际执行 {executed_steps}/{original_steps} 步",
                duration=duration,
                details={"original_steps": original_steps, "executed_steps": executed_steps}
            )
            self.results.append(result)
            print(f"✅ 测试通过 ({duration:.2f}s)")
            
        except Exception as e:
            duration = (datetime.now() - start).total_seconds()
            result = TestResult(
                test_name=test_name,
                status="failed",
                message=str(e),
                duration=duration
            )
            self.results.append(result)
            print(f"❌ 测试失败: {e}")
    
    async def test_insert_step(self):
        """测试 12: 插入步骤功能"""
        test_name = "动态调整 - 插入步骤"
        start = datetime.now()
        
        try:
            print(f"\n{'='*80}")
            print(f"测试: {test_name}")
            print(f"{'='*80}")
            
            template = PROFESSION_TASK_TEMPLATES["clinician"][0]
            task = Task(
                id=f"insert_test_{datetime.now().strftime('%Y%m%d%H%M%S')}",
                name=template.name,
                profession="clinician",
                description=template.description,
                goal="测试插入步骤",
                steps=template.default_steps.copy()
            )
            
            original_steps = len(task.steps)
            
            # 在第 2 步后插入新步骤
            new_step = {"action": "extra_assessment", "params": {"type": "详细评估"}}
            task.steps.insert(2, new_step)
            
            print(f"原始步骤数: {original_steps}")
            print(f"插入后步骤数: {len(task.steps)}")
            print(f"在第 2 步后插入: {new_step['action']}")
            
            duration = (datetime.now() - start).total_seconds()
            
            result = TestResult(
                test_name=test_name,
                status="passed",
                message=f"成功插入步骤，步骤数从 {original_steps} 增加到 {len(task.steps)}",
                duration=duration,
                details={"original_steps": original_steps, "new_steps": len(task.steps)}
            )
            self.results.append(result)
            print(f"✅ 测试通过 ({duration:.2f}s)")
            
        except Exception as e:
            duration = (datetime.now() - start).total_seconds()
            result = TestResult(
                test_name=test_name,
                status="failed",
                message=str(e),
                duration=duration
            )
            self.results.append(result)
            print(f"❌ 测试失败: {e}")
    
    async def test_modify_step(self):
        """测试 13: 修改步骤功能"""
        test_name = "动态调整 - 修改步骤"
        start = datetime.now()
        
        try:
            print(f"\n{'='*80}")
            print(f"测试: {test_name}")
            print(f"{'='*80}")
            
            template = PROFESSION_TASK_TEMPLATES["clinician"][0]
            task = Task(
                id=f"modify_test_{datetime.now().strftime('%Y%m%d%H%M%S')}",
                name=template.name,
                profession="clinician",
                description=template.description,
                goal="测试修改步骤",
                steps=template.default_steps.copy()
            )
            
            # 修改第 1 步的参数
            original_action = task.steps[0]['action']
            task.steps[0]['params']['patient_id'] = 'P999'
            
            print(f"修改步骤: 第 1 步")
            print(f"原始 action: {original_action}")
            print(f"修改参数: patient_id = P999")
            
            duration = (datetime.now() - start).total_seconds()
            
            result = TestResult(
                test_name=test_name,
                status="passed",
                message=f"成功修改步骤参数",
                duration=duration,
                details={"modified_step": 1, "action": original_action}
            )
            self.results.append(result)
            print(f"✅ 测试通过 ({duration:.2f}s)")
            
        except Exception as e:
            duration = (datetime.now() - start).total_seconds()
            result = TestResult(
                test_name=test_name,
                status="failed",
                message=str(e),
                duration=duration
            )
            self.results.append(result)
            print(f"❌ 测试失败: {e}")
    
    def generate_report(self):
        """生成测试报告"""
        print(f"\n{'='*80}")
        print(" " * 30 + "测试报告")
        print(f"{'='*80}")
        
        total_tests = len(self.results)
        passed_tests = sum(1 for r in self.results if r.status == "passed")
        failed_tests = sum(1 for r in self.results if r.status == "failed")
        
        total_duration = (self.end_time - self.start_time).total_seconds()
        
        print(f"\n测试汇总:")
        print(f"  总测试数: {total_tests}")
        print(f"  通过: {passed_tests} ({passed_tests/total_tests*100:.1f}%)")
        print(f"  失败: {failed_tests} ({failed_tests/total_tests*100:.1f}%)")
        print(f"  总耗时: {total_duration:.2f} 秒")
        
        print(f"\n详细结果:")
        for i, result in enumerate(self.results, 1):
            status_icon = "✅" if result.status == "passed" else "❌"
            print(f"  {i}. {status_icon} {result.test_name}")
            print(f"     状态: {result.status}")
            print(f"     消息: {result.message}")
            print(f"     耗时: {result.duration:.2f}s")
            print()
        
        # 保存报告到文件
        report_path = Path(__file__).parent / "test_report.md"
        self._save_markdown_report(report_path, total_tests, passed_tests, 
                                   failed_tests, total_duration)
        
        print(f"✅ 测试报告已保存: {report_path}")
    
    def _save_markdown_report(self, path: Path, total: int, passed: int, 
                             failed: int, duration: float):
        """保存 Markdown 格式报告"""
        with open(path, 'w', encoding='utf-8') as f:
            f.write("# MedClaw 功能测试报告\n\n")
            f.write(f"**测试时间**: {self.start_time.strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            
            f.write("## 测试汇总\n\n")
            f.write(f"| 指标 | 数值 |\n")
            f.write(f"|------|------|\n")
            f.write(f"| 总测试数 | {total} |\n")
            f.write(f"| 通过 | {passed} ({passed/total*100:.1f}%) |\n")
            f.write(f"| 失败 | {failed} ({failed/total*100:.1f}%) |\n")
            f.write(f"| 总耗时 | {duration:.2f} 秒 |\n\n")
            
            f.write("## 详细结果\n\n")
            for i, result in enumerate(self.results, 1):
                status_icon = "✅" if result.status == "passed" else "❌"
                f.write(f"### {i}. {status_icon} {result.test_name}\n\n")
                f.write(f"- **状态**: {result.status}\n")
                f.write(f"- **消息**: {result.message}\n")
                f.write(f"- **耗时**: {result.duration:.2f} 秒\n")
                if result.details:
                    f.write(f"- **详情**: {json.dumps(result.details, ensure_ascii=False)}\n")
                f.write("\n")


async def main():
    """主函数"""
    suite = MedClawTestSuite()
    await suite.run_all_tests()


if __name__ == "__main__":
    asyncio.run(main())
