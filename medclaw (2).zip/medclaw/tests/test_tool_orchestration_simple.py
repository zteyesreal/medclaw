"""
MedClaw 工具编排简化测试
"""

import asyncio
import sys
from pathlib import Path
from datetime import datetime

# 添加路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from medclaw.core.mcp_client import MCPClient
from medclaw.core.tool_orchestrator import ToolOrchestrator, ToolChain

print("\n" + "="*70)
print("MedClaw 工具编排测试")
print("="*70)


async def test_basic():
    """基础测试"""
    print("\n【测试】工具注册和调用")
    
    # 创建客户端
    client = MCPClient()
    await client.initialize()
    
    # 注册工具
    def echo_handler(message: str):
        return {"echo": message, "timestamp": datetime.now().isoformat()}
    
    client.register_tool(
        name="echo",
        description="回显工具",
        input_schema={
            "type": "object",
            "properties": {
                "message": {"type": "string"}
            },
            "required": ["message"]
        },
        handler=echo_handler
    )
    
    # 注册第二个工具
    def uppercase_handler(text: str):
        return {"uppercase": text.upper()}
    
    client.register_tool(
        name="uppercase",
        description="转大写工具",
        input_schema={
            "type": "object",
            "properties": {
                "text": {"type": "string"}
            },
            "required": ["text"]
        },
        handler=uppercase_handler
    )
    
    print(f"  已注册工具：{len(client.tools)} 个")
    
    # 调用工具
    result = await client.call_tool("echo", message="Hello, World!")
    print(f"  echo 工具调用：{result}")
    
    result = await client.call_tool("uppercase", text="hello")
    print(f"  uppercase 工具调用：{result}")
    
    print("\n✅ 基础测试通过")


async def test_chain():
    """工具链测试"""
    print("\n【测试】工具链执行")
    
    client = MCPClient()
    
    # 注册工具
    client.register_tool(
        name="step1",
        description="步骤 1",
        input_schema={"type": "object", "properties": {}},
        handler=lambda: {"step": 1, "data": "initial"}
    )
    
    client.register_tool(
        name="step2",
        description="步骤 2",
        input_schema={"type": "object", "properties": {"input": {"type": "object"}}},
        handler=lambda input: {"step": 2, "processed": input}
    )
    
    # 创建编排器
    orchestrator = ToolOrchestrator(
        mcp_client=client,
        cache_enabled=False,
        permission_enabled=False,
        audit_enabled=False,
    )
    await orchestrator.initialize()
    
    # 创建链
    chain = orchestrator.create_chain()
    chain.add_step("step1", params={})
    chain.add_step("step2", params={}, output_mapping="input")
    
    # 执行链
    results = await orchestrator.execute_chain(chain)
    print(f"  工具链执行完成：{len(results)} 个步骤")
    print(f"  结果：{results}")
    
    print("\n✅ 工具链测试通过")


async def test_parallel():
    """并行执行测试"""
    print("\n【测试】并行执行")
    
    client = MCPClient()
    
    # 注册工具
    for i in range(3):
        def handler(value, idx=i):
            return {"task": idx, "value": value * 2}
        
        client.register_tool(
            name=f"task_{i}",
            description=f"任务{i}",
            input_schema={"type": "object", "properties": {"value": {"type": "int"}}},
            handler=handler
        )
    
    orchestrator = ToolOrchestrator(
        mcp_client=client,
        cache_enabled=False,
        permission_enabled=False,
        audit_enabled=False,
    )
    await orchestrator.initialize()
    
    # 并行调用
    tool_calls = [
        ("task_0", {"value": 1}),
        ("task_1", {"value": 2}),
        ("task_2", {"value": 3}),
    ]
    
    results = await orchestrator.execute_parallel(tool_calls)
    print(f"  并行执行：{len(results)} 个任务")
    for result in results:
        print(f"    {result}")
    
    print("\n✅ 并行执行测试通过")


async def main():
    """主函数"""
    await test_basic()
    await test_chain()
    await test_parallel()
    
    print("\n" + "="*70)
    print("所有测试完成！")
    print("="*70)
    print("""
已验证的功能:
  ✅ 工具注册和调用
  ✅ 工具链执行
  ✅ 并行执行
  
实际应用场景:
  1. 多工具协作
  2. 数据处理流水线
  3. 并行数据收集
""")
    print("="*70)


if __name__ == "__main__":
    asyncio.run(main())
